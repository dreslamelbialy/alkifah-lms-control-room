@echo off
rem Waits until the app answers, then opens the browser (minimized helper window)
for /l %%i in (1,1,30) do (
  curl -s -o nul http://127.0.0.1:3000 && (start "" "http://127.0.0.1:3000" & exit /b 0)
  timeout /t 1 /nobreak >nul
)
rem fallback: open anyway after 30s
start "" "http://127.0.0.1:3000"
