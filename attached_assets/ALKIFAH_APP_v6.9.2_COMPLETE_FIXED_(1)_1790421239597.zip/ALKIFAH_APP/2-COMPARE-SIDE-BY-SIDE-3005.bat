@echo off
chcp 65001 >nul 2>&1
title Alkifah LMS Studio v6.9.2 (Comparison Mode - Port 3005)
cd /d "%~dp0"

if not exist "Alkifah_LMS_App\app\webapi.py" (
  echo.
  echo [!] Please Extract All first before running.
  pause
  exit /b 1
)

set "LMS_PACK_DIR=%~dp0Alkifah_LMS_App"
set "HOSTNAME=127.0.0.1"
set "PORT=3005"

echo ======================================================================
echo  Running on Port 3005 so you can compare side-by-side with Port 3000!
echo  - Other App : http://127.0.0.1:3000
echo  - This App  : http://127.0.0.1:3005
echo ======================================================================

start "" /min cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:3005"

cd /d "%~dp0webapp"
node server.js
pause
