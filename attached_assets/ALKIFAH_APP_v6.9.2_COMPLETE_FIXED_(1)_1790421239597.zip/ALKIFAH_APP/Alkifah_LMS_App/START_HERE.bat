@echo off
title Alkifah LMS Automation
color 0B
cd /d "%~dp0"

echo ============================================================
echo    Alkifah Academy LMS  -  Automation
echo ============================================================
echo.
echo  This window must stay open while you use the app.
echo.

REM ---------- 1. find Python ----------
set "PY="
where py >nul 2>nul && set "PY=py"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
     if exist "%%D\python.exe" set "PY=%%D\python.exe"
  )
)
if not defined PY (
  for /d %%D in ("C:\Program Files\Python3*") do (
     if exist "%%D\python.exe" set "PY=%%D\python.exe"
  )
)

if not defined PY (
  echo  ------------------------------------------------------------
  echo   PYTHON IS NOT INSTALLED - one time setup, 3 minutes:
  echo  ------------------------------------------------------------
  echo   1. The download page will open in your browser now.
  echo   2. Download the big yellow "Download Python" button.
  echo   3. IMPORTANT: on the first screen tick
  echo        [x] Add python.exe to PATH
  echo      then press "Install Now".
  echo   4. When it finishes, close this window and
  echo      double-click START_HERE.bat again.
  echo  ------------------------------------------------------------
  echo.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)

echo  Python found: %PY%
%PY% --version

REM ---------- 2. install the app's needs (once) ----------
echo.
echo  Checking the app requirements (flask, cryptography, playwright) ...
%PY% -c "import flask" 1>nul 2>nul
if errorlevel 1 (
  echo  Installing flask ... one time, please wait.
  %PY% -m pip install --quiet --upgrade pip
  %PY% -m pip install --quiet flask
)
%PY% -c "import cryptography" 1>nul 2>nul
if errorlevel 1 %PY% -m pip install --quiet cryptography
%PY% -c "import playwright" 1>nul 2>nul
if errorlevel 1 %PY% -m pip install --quiet playwright

REM ---------- 3. install the browser the automation drives (once) ----------
%PY% -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); p.chromium.launch(); p.stop()" 1>nul 2>nul
if errorlevel 1 (
  echo  Installing the automation browser ... one time, about 1 minute.
  %PY% -m playwright install chromium
)

REM ---------- 4. start the app ----------
echo.
echo  Starting the app - your browser will open in a moment.
echo.
echo   1. Enter your email and password once.
echo   2. Click the big green button.
echo.
%PY% "app\app.py" --port 8770 --open --host 127.0.0.1

echo.
echo  The app stopped. You can close this window.
pause
