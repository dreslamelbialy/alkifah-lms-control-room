"""
Alkifah LMS — Weekly Booklet Uploader (v6, PDF-only + LMS duplicate check)
================================================================
v6 changes (pack rules):
  * PDF ONLY — only real PDF files are accepted. Anything that is not a PDF (checked by
    the %PDF header, not just the file name) is ignored and reported.
  * Booklets and their model answers are uploaded to the SAME place as lesson materials:
    Course Management -> Materials.
  * DUPLICATE CHECK before uploading — the script reads the full Materials list from the
    LMS (all pages) and skips any booklet/model answer that is already there, even when
    booklet_log.json lost its entry.
================================================================
Fixes over the original v1:
  * Login uses #Input_Password via fill_first() (the original used
    page.fill("#passwordInput", ...) which doesn't exist on the form).
  * `--show` flag forces a visible browser for debugging.
  * Env-var overrides for credentials / paths.
  * `--limit N` controls how many booklets to upload per run.
  * The misleading "Week 3 not uploaded until its Sunday" rule from
    SKILL.md was NEVER enforced in code. We now provide a
    `--respect-sunday-rule` flag (off by default) that, when on, refuses
    to upload week N's booklet if today is before its Sunday.
  * attach_file wait timeout made explicit per-file.

Usage:
    python upload_booklet.py auto          # upload next un-uploaded booklet
    python upload_booklet.py answer        # upload next missing model answer
    python upload_booklet.py status        # print what's uploaded/missing
    python upload_booklet.py file "<pdf>" "<title>"   # one-off manual upload
    python upload_booklet.py auto --show
    python upload_booklet.py auto --only "Week 3 Booklet Assessment" --only "Week 5 booklet.pdf"
        # v6.5: upload exactly the selected items (matches title, file name or
        # file name without extension; spaces/case are ignored). With --only,
        # ALL matched pending items are uploaded, not just one.
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os, re, sys, json, time, argparse
from pathlib import Path
from datetime import datetime, timedelta
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

## ============ SETTINGS — EDIT ONLY THESE LINES ============
FOLDER   = r"D:\Alkifah academy\2026-2027\First Term\Booklet"
COURSE   = "Science 3 - Grade 9"
CLASSES  = "ALL"
USERNAME = os.environ.get("LMS_USERNAME", "")
PASSWORD = os.environ.get("LMS_PASSWORD", "")
MINUTES_AHEAD = 5     # publish time = now + N minutes (LMS_MINUTES_AHEAD overrides)
RETRIES  = 2

def settle(page, timeout_ms=8000):
    """v6.6: BOUNDED network settle — the old bare networkidle waits could add
    up to 30s of silence after every file on a chatty LMS page."""
    try:
        page.wait_for_load_state("networkidle", timeout=timeout_ms)
    except Exception:
        pass

def title_on_lms(page, title, max_pages=6):
    """v6.6: is this title already in the LMS Materials list? Used after an
    unclear save so we never re-upload (duplicate) or loop for minutes."""
    try:
        page.goto(f"{BASE_URL}/CourseManagement/Materials",
                  wait_until="domcontentloaded", timeout=30000)
        page.wait_for_selector("table", timeout=10000)
        for _ in range(max_pages):
            page_titles = page.evaluate("""() => {
                const t = document.querySelector('table');
                if (!t) return [];
                return Array.from(t.querySelectorAll('tbody tr')).map(r => {
                    const c = r.querySelectorAll('td');
                    return c.length > 1 ? c[1].innerText.replace(/\\s+/g, ' ').trim() : '';
                }).filter(Boolean);
            }""")
            if title in page_titles:
                return True
            clicked = page.evaluate("""() => {
                const next = Array.from(document.querySelectorAll('a'))
                    .find(a => a.innerText.trim().toLowerCase() === 'next');
                if (next && !next.closest('li').classList.contains('disabled')) {
                    next.click(); return true;
                }
                const active = document.querySelector('.pagination .active');
                if (active) {
                    let el = active.nextElementSibling;
                    if (el) { const a = el.querySelector('a') || el; a.click(); return true; }
                }
                return false;
            }""")
            if not clicked:
                return False
            page.wait_for_load_state("domcontentloaded")
            page.wait_for_timeout(600)
    except Exception:
        return False
    return False
MAX_MB   = 25
## ==========================================================

FOLDER   = os.environ.get("LMS_FOLDER",   FOLDER)
COURSE   = os.environ.get("LMS_COURSE",   COURSE)
CLASSES  = os.environ.get("LMS_CLASSES",  CLASSES)
USERNAME = os.environ.get("LMS_USERNAME", USERNAME)
PASSWORD = os.environ.get("LMS_PASSWORD", PASSWORD)
_env_minutes = os.environ.get("LMS_MINUTES_AHEAD", "").strip()
if _env_minutes.isdigit():
    MINUTES_AHEAD = int(_env_minutes)

BASE_URL = "https://lms.alkifah.edu.sa"
SCRIPT_DIR = Path(__file__).resolve().parent
LOG_PATH   = SCRIPT_DIR / "booklet_log.json"

ap = argparse.ArgumentParser(description="Alkifah LMS Weekly Booklet Uploader")
ap.add_argument("mode", nargs="?", default="auto",
                choices=["auto", "answer", "status", "file", "cleanup"],
                help="auto (default) | answer | status | file <path> <title> | cleanup")
ap.add_argument("rest", nargs="*", help="positional args for 'file' mode")
ap.add_argument("--show", action="store_true", help="Show the browser window.")
ap.add_argument("--limit", type=int, default=None,
                help="Max items to upload in this run (default: 1 normally, "
                     "or all matched items when --only is used).")
ap.add_argument("--respect-sunday-rule", action="store_true",
                help="Refuse week-N booklet upload if today is before its Sunday.")
ap.add_argument("--only", action="append", default=[],
                help="Upload only these items. Repeat the flag or separate entries "
                     "with commas. Matches the platform title, the file name, or "
                     "the file name without extension (spaces/case ignored).")
# v6.9: cleanup of OLD materials directly on the LMS (teacher picks them in the app)
ap.add_argument("--list", action="store_true",
                help="cleanup: save the full Materials list to cleanup_report.json (dry-run, deletes nothing)")
ap.add_argument("--delete-indices", default="",
                help="cleanup: comma-separated row numbers from cleanup_report.json to DELETE")
ARGS = ap.parse_args()

CLEANUP_REPORT = SCRIPT_DIR / "cleanup_report.json"

def _norm(value):
    return re.sub(r"\s+", " ", str(value).strip()).casefold()

ONLY = []
for _arg in ARGS.only:
    for _part in _arg.split(","):
        _part = _part.strip()
        if _part and _norm(_part) not in ONLY:
            ONLY.append(_norm(_part))

def matches_only(item):
    """v6.5: exact selection — True when no --only list, or when the item's
    title / file name / bare stem is on it. Space count is ignored, so
    'Week 5 booklet .pdf' matches 'week 5 booklet.pdf' too."""
    if not ONLY:
        return True
    path = str(item.get("path", ""))
    base = os.path.basename(path.replace("\\", "/"))  # Windows-safe everywhere
    stem = os.path.splitext(base)[0]
    title = str(item.get("title", ""))
    hay = {_norm(title), _norm(base), _norm(stem)}
    hay |= {re.sub(r"\s+", "", h) for h in hay}  # space-free twins
    for want in ONLY:
        want_sq = re.sub(r"\s+", "", want)
        if want in hay or want_sq in hay:
            return True
    return False

def load_log():
    if LOG_PATH.exists():
        try:
            return json.loads(LOG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_log(log):
    LOG_PATH.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")

def scan_booklets():
    """Find the booklet PDFs. PDF-only rule: the file content must really be a PDF
    (header %PDF), not just carry a .pdf name."""
    folder = Path(FOLDER)
    if not folder.exists():
        sys.exit(f"Cannot find the booklet folder: {FOLDER}")
    items = []
    ignored = 0
    files = []
    for p in sorted(folder.iterdir()):
        if p.is_dir() or p.suffix.lower() != ".pdf":
            continue
        try:
            with p.open("rb") as fh:
                header = fh.read(5)
        except OSError:
            header = b""
        if header.startswith(b"%PDF"):
            files.append(p)
        else:
            ignored += 1
            print(f"   (ignored: '{p.name}' is not a real PDF file)")
    if ignored:
        print(f"   PDF-only rule: {ignored} file(s) ignored because their content is "
              f"not a PDF.")
    for p in files:
        # v6.4: tolerate stray spaces ("Week 5 booklet .pdf"), doubled spaces
        # and letter case — same booklet, just a messy file name.
        name = re.sub(r"\s+", " ", p.stem.strip())
        m = re.match(r"^week\s*(\d+)\s*booklet$", name, re.I)
        m2 = re.match(r"^week\s*(\d+)\s*booklet\s*\(model\s*answer\)$", name, re.I)
        if m:
            week = int(m.group(1)); kind = "booklet"
            title = f"Week {week} Booklet Assessment"
        elif m2:
            week = int(m2.group(1)); kind = "answer"
            title = f"Week {week} Booklet Model Answer"
        elif name.casefold() == "orientation booklet":
            week = 0; kind = "booklet"; title = "Orientation Booklet Assessment"
        elif name.casefold() == "orientation booklet (model answer)":
            week = 0; kind = "answer"; title = "Orientation Booklet Model Answer"
        else:
            continue
        items.append({"week": week, "kind": kind, "path": str(p), "title": title})
    items.sort(key=lambda x: (x["week"], 0 if x["kind"] == "booklet" else 1))
    return items

def fill_first(page, selectors, value):
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return True
        except Exception:
            continue
    return False

def click_first(page, selectors, timeout=6000):
    for sel in selectors:
        try:
            page.click(sel, timeout=timeout)
            return True
        except Exception:
            continue
    return False

def login(page):
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    last_err = None
    for attempt in range(2):
        try:
            page.goto(f"{BASE_URL}/Identity/Account/LogIn",
                      wait_until="domcontentloaded", timeout=60000)
            last_err = None
            break
        except Exception as e:
            last_err = e
            print("   (login page load timed out — trying again...)")
    if last_err:
        sys.exit(f"Could not open the LMS login page: {last_err}")
    if not fill_first(page, ["input[name='Input.Email']", "#Input_Email"], USERNAME):
        sys.exit("Could not find the email box on the login page.")
    # v6.2: the login page currently uses id="passwordInput" (name="Input.Password");
    # keep the name-based selector first and cover both ID layouts.
    if not fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                             "#Input_Password", "input[type='password']"], PASSWORD):
        sys.exit("Could not find the password box on the login page.")
    click_first(page, ["button[type='submit']", "input[type='submit']"])
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=15000)
    except PWTimeout:
        sys.exit("Login failed — check email/password in the SETTINGS.")

def open_create_form(page):
    page.goto(f"{BASE_URL}/CourseManagement/Materials/Create",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#general_form", timeout=15000)

def select_course(page):
    res = page.evaluate("""() => {
        const el = document.getElementById('CourseId');
        const base = 'science 3';
        for (const o of el.options) {
            if (o.value && o.text.trim().toLowerCase().startsWith(base)) {
                el.value = o.value;
                el.dispatchEvent(new Event('change', {bubbles:true}));
                return o.text.trim();
            }
        }
        return null;
    }""")
    if not res:
        raise RuntimeError("No course starting with 'Science 3' found in the dropdown.")

def wait_for_classes_loaded(page, timeout_ms=20000):
    """v6.2: the Classes dropdown stays EMPTY and DISABLED until the course selection
    triggers its AJAX load. Selecting too early saved booklets with NO classes. Wait
    until the list is enabled and populated."""
    try:
        page.wait_for_function(
            """() => { const el = document.getElementById('classesSelectList');
                       return el && !el.disabled && el.options.length > 0; }""",
            timeout=timeout_ms)
        return True
    except Exception:
        return False

def select_classes(page):
    page.evaluate("""() => {
        const el = document.getElementById('classesSelectList');
        if (el) { for (const o of el.options) o.selected = true;
                  el.dispatchEvent(new Event('change', {bubbles:true})); }
    }""")
    chosen = page.evaluate(
        """() => document.getElementById('classesSelectList')
              ? document.getElementById('classesSelectList').selectedOptions.length : 0""")
    if not chosen:
        raise RuntimeError(
            "No classes could be selected in #classesSelectList — the list was empty. "
            "The booklet would be invisible to students, so the upload was stopped. "
            "(v6.2 safety guard)")

def set_publish_date(page, minutes=None):
    """Set Publish Date = now + MINUTES_AHEAD (default 5 minutes).

    v6.1: the old code wrote to #PublishDate only, and when the field stayed empty the
    Save button never became active. This tries the field by id, by name, by any input
    whose id/name/placeholder contains 'publish', then reads the value back and tells you
    if it could not be filled.
    """
    minutes = MINUTES_AHEAD if minutes is None else minutes
    value = (datetime.now() + timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M")

    for sel in ["#PublishDate", "input[name='PublishDate']", "input[id*='ublish']",
                "input[name*='ublish']", "input[type='datetime-local']"]:
        try:
            page.fill(sel, value, timeout=4000)
            break
        except Exception:
            continue

    found = page.evaluate("""(v) => {
        const els = Array.from(document.querySelectorAll('input'))
            .filter(i => /publish/i.test((i.id||'') + (i.name||'') + (i.placeholder||'')));
        for (const el of els) {
            el.value = v;
            el.dispatchEvent(new Event('input',  {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
            el.dispatchEvent(new Event('blur',   {bubbles:true}));
        }
        return els.length;
    }""", value)

    got = page.evaluate("""() => {
        const el = Array.from(document.querySelectorAll('input'))
            .find(i => /publish/i.test((i.id||'') + (i.name||'') + (i.placeholder||'')));
        return el ? el.value : '';
    }""")
    if got:
        print(f"     (publish date: {got} - {minutes} minute(s) from now)")
    else:
        print(f"     (warning: could not fill the Publish Date automatically "
              f"[{found} field(s) found]. Type it by hand in the browser window if the "
              f"Save button stays grey.)")
    return value

def _file_input_selectors():
    """Every place the LMS has been seen to keep the hidden <input type=file>."""
    return ["#MaterialDropZoneCreate input[type='file']",
            "input[type='file'][name*='ttachment']",
            "input[type='file'][name*='ile']",
            "#MaterialDropZoneCreate input",
            "input[type='file']"]


def attach_file(page, path):
    """Attach a file to the "Drop files here or click to upload" box.

    v6.1: the original code knew only two ways of finding the upload box and stopped with
    "Timeout 30000ms exceeded" when the layout did not match. It now:
      1. waits for the dropzone script to build itself,
      2. sets the hidden <input type=file> directly (Playwright can fill hidden inputs),
      3. otherwise clicks the dropzone / its text and uses the file chooser,
      4. warns instead of failing when the page does not confirm the upload by itself.
    """
    name = os.path.basename(path)

    for sel in ["#MaterialDropZoneCreate", ".dropzone", "input[type='file']",
                "text=Drop files here"]:
        try:
            page.wait_for_selector(sel, timeout=15000)
            break
        except PWTimeout:
            continue
    page.wait_for_timeout(800)

    sent = False
    last_err = None
    for sel in _file_input_selectors():
        try:
            loc = page.locator(sel).first
            if loc.count():
                loc.set_input_files(path, timeout=30000)
                sent = True
                print(f"     (attached through {sel})")
                break
        except Exception as e:
            last_err = e
            continue

    if not sent:
        for sel in ["#MaterialDropZoneCreate .dropzone-select",
                    "#MaterialDropZoneCreate .dz-clickable",
                    "#MaterialDropZoneCreate",
                    ".dropzone-select", ".dz-clickable",
                    "text=Drop files here or click to upload"]:
            try:
                with page.expect_file_chooser(timeout=8000) as fc:
                    page.click(sel, timeout=8000)
                fc.value.set_files(path)
                sent = True
                print(f"     (attached by clicking {sel})")
                break
            except Exception as e:
                last_err = e
                continue

    if not sent:
        raise RuntimeError(
            "could not find the upload box ('Drop files here or click to upload') on the "
            f"Materials/Create page ({last_err}). If the page looks different, send a "
            "screenshot of it to your admin.")

    confirmed = False
    for sel in [f'.dropzone-item.dz-complete:has(span[data-dz-name]:text-is("{name}"))',
                ".dropzone-item.dz-complete", ".dz-complete", ".dz-success"]:
        try:
            page.wait_for_selector(sel, timeout=180000)
            confirmed = True
            break
        except PWTimeout:
            continue
    if not confirmed:
        try:
            confirmed = name in page.inner_text("body")
        except Exception:
            confirmed = False
    settle(page)                      # v6.6: bounded (was up to 30s of silence)
    if not confirmed:
        raise RuntimeError(
            f"'{name}' was sent but the page never showed it - the LMS did not accept the "
            f"file (check the size, 25 MB maximum).")

def upload_one(page, path, title, description):
    open_create_form(page)
    page.fill("#Name", title)
    page.fill("#Description", description)
    select_course(page)
    if not wait_for_classes_loaded(page):          # v6.2: classes load via AJAX
        print("   (classes list still empty — waiting a little more...)")
        if not wait_for_classes_loaded(page, timeout_ms=15000):
            raise RuntimeError("Classes dropdown never loaded after selecting the "
                               "course (v6.2 guard) — nothing was saved.")
    attach_file(page, path)
    select_classes(page)
    set_publish_date(page)
    # v6.4: removed the stale re-fill block that used an undefined `publish`
    # variable (crashed every upload right after the publish date).
    # set_publish_date() above already fills the field and verifies it.
    try:
        page.wait_for_selector("#saveButton:not([disabled])", timeout=15000)
    except PWTimeout:
        raise RuntimeError("Save button never became active.")
    page.click("#saveButton")
    # v6.6: poll up to 60s for the form to go away (slow LMS servers) and decide
    # with evidence instead of one fixed 30s wait.
    saved = False
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            if page.locator("#general_form").count() == 0:
                saved = True
                break
        except Exception:
            saved = True
            break
        try:
            body = page.inner_text("body")
            if "successfully" in body.lower() or "تم " in body or "تمت" in body:
                saved = True
                break
        except Exception:
            pass
        page.wait_for_timeout(500)
    if not saved:
        if title in page.inner_text("body"):
            return True
        errs = page.locator(".field-validation-error:visible, .validation-summary-errors li:visible")
        msg = " | ".join(errs.all_inner_texts()[:3]) if errs.count() else ""
        raise RuntimeError(("Site said: " + msg) if msg else "Save did not finish.")
    settle(page)                      # v6.6: bounded
    try:
        return title in page.inner_text("body")
    except Exception:
        return False

def lms_material_titles(headless=True):
    """DUPLICATE CHECK (v6): read every title from Course Management -> Materials,
    following pagination, and return the set. Lesson materials, booklets and model
    answers all live in that one list, so this catches anything already uploaded."""
    titles = set()
    # login details are checked before the browser starts
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        page = browser.new_context(locale="en-US").new_page()
        try:
            login(page)
            page.goto(f"{BASE_URL}/CourseManagement/Materials",
                      wait_until="domcontentloaded", timeout=60000)
            try:
                page.wait_for_selector("table", timeout=20000)
            except PWTimeout:
                return titles
            for _ in range(40):
                page_titles = page.evaluate("""() => {
                    const t = document.querySelector('table');
                    if (!t) return [];
                    return Array.from(t.querySelectorAll('tbody tr')).map(r => {
                        const c = r.querySelectorAll('td');
                        return c.length > 1 ? c[1].innerText.replace(/\\s+/g, ' ').trim() : '';
                    }).filter(Boolean);
                }""")
                titles.update(page_titles)
                clicked = page.evaluate("""() => {
                    const next = Array.from(document.querySelectorAll('a'))
                        .find(a => a.innerText.trim().toLowerCase() === 'next');
                    if (next && !next.closest('li').classList.contains('disabled')) {
                        next.click(); return true;
                    }
                    const active = document.querySelector('.pagination .active');
                    if (active) {
                        let el = active.nextElementSibling;
                        if (el) { const a = el.querySelector('a') || el; a.click(); return true; }
                    }
                    return false;
                }""")
                if not clicked:
                    break
                page.wait_for_load_state("domcontentloaded")
                page.wait_for_timeout(1200)
        finally:
            try:
                browser.close()
            except Exception:
                pass
    return titles


def reconcile_with_lms(items, log, headless=True):
    """Mark items that are already on the LMS so they are never uploaded twice.
    Returns the number of items reconciled."""
    pending = [it for it in items if it["title"] not in log]
    if not pending:
        return 0
    print(f"   Checking the LMS for what is already there "
          f"({len(pending)} item(s) to test) ...")
    try:
        existing = lms_material_titles(headless=headless)
    except Exception as e:
        print(f"   (duplicate check skipped: {e})")
        return 0
    reconciled = 0
    for it in pending:
        if it["title"] in existing:
            log[it["title"]] = (f"already on LMS "
                                f"(reconciled {datetime.now():%Y-%m-%d %H:%M})")
            reconciled += 1
    if reconciled:
        save_log(log)
        print(f"   {reconciled} item(s) were already on the LMS — skipped, not repeated.")
    return reconciled


def do_upload(item, description, headless=True):
    log = load_log()
    if item["title"] in log:
        print(f"   SKIPPED (already uploaded: {item['title']})")
        return False
    mb = os.path.getsize(item["path"]) / 1024 / 1024
    if mb > MAX_MB:
        print(f"   SKIPPED — file is {mb:.1f} MB (site limit is {MAX_MB} MB)")
        return False
    results = "saved"
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        context = browser.new_context(locale="en-US")
        page = context.new_page()
        login(page)
        print(f"   Uploading: {item['title']}  ({mb:.1f} MB)")
        for attempt in range(1, RETRIES + 1):
            try:
                confirmed = upload_one(page, item["path"], item["title"], description)
                log[item["title"]] = datetime.now().strftime("%Y-%m-%d %H:%M")
                save_log(log)
                results = "OK" + (" (seen in list)" if confirmed else "")
                break
            except Exception as e:
                results = f"FAILED — {e}"
                # v6.6: the save may have landed even without a clean page
                # confirmation — verify on the LMS before retrying (no
                # duplicates, no wasted minutes looping on the same file).
                try:
                    if title_on_lms(page, item["title"]):
                        log[item["title"]] = datetime.now().strftime("%Y-%m-%d %H:%M")
                        save_log(log)
                        results = "OK (confirmed in the materials list after an unclear save)"
                        break
                except Exception:
                    pass
                if attempt < RETRIES:
                    print(f"   attempt {attempt} failed ({e}) — retrying...")
                    try:
                        page.goto(BASE_URL, wait_until="domcontentloaded")
                    except Exception:
                        pass
        browser.close()
    print(f"   -> {results}")
    if results.startswith("FAILED"):
        sys.exit(1)
    return True

def mode_auto():
    log = load_log()
    items = scan_booklets()
    if ONLY:
        items = [it for it in items if matches_only(it)]
        if not items:
            sys.exit("--only: no booklet matched the selected titles. Open the app's "
                     "booklets tab and pick from the list shown there.")
        print(f"--only: {len(items)} selected file(s) matched.")
    today = datetime.now()
    pending_before = [it for it in items if it["kind"] == "booklet" and it["title"] not in log]
    if pending_before:
        reconcile_with_lms(items, log, headless=not ARGS.show)
    # v6.5: with --only, upload every selected pending booklet (not just one)
    limit = ARGS.limit if ARGS.limit is not None else (len(pending_before) if ONLY else 1)
    uploaded_count = 0
    for it in items:
        if uploaded_count >= limit:
            print(f"Reached --limit {limit}. Stopping.")
            return
        if it["kind"] != "booklet" or it["title"] in log:
            continue
        if ARGS.respect_sunday_rule and it["week"] > 0:
            if today.weekday() != 6:
                print(f"   Week {it['week']} booklet: --respect-sunday-rule is on, "
                      f"today is not Sunday. Skipping.")
                continue
        week = "Orientation" if it["week"] == 0 else f"Week {it['week']}"
        if do_upload(it, f"Weekly booklet assessment — {week}", headless=not ARGS.show):
            uploaded_count += 1
    if uploaded_count == 0:
        print("All booklets are already uploaded. Nothing to do.")

def mode_answer():
    log = load_log()
    all_items = scan_booklets()
    # v6.9 BUGFIX: the uploaded-booklets guard used to read the FILTERED list,
    # so when the teacher selected model answers only (booklets already uploaded
    # and unticked), the script wrongly claimed "the booklet must be uploaded
    # first" and refused to upload anything. The guard now reads the FULL scan.
    items = [it for it in all_items if matches_only(it)] if ONLY else all_items
    if ONLY:
        if not items:
            sys.exit("--only: no model answer matched the selected titles. Open the "
                     "app's booklets tab and pick from the list shown there.")
        print(f"--only: {len(items)} selected file(s) matched.")
    pending_answers = [it for it in items if it["kind"] == "answer" and it["title"] not in log]
    if pending_answers:
        reconcile_with_lms(all_items, log, headless=not ARGS.show)
    uploaded_booklet_weeks = [it["week"] for it in all_items
                              if it["kind"] == "booklet" and it["title"] in log]
    if not uploaded_booklet_weeks:
        if ONLY:
            sys.exit("--only: the booklet of that week must be uploaded before its "
                     "model answer — nothing was uploaded.")
        sys.exit("No booklet has been uploaded yet — nothing to attach an answer to.")
    # v6.5: with --only, upload every selected pending answer (not just one)
    limit = ARGS.limit if ARGS.limit is not None else (len(pending_answers) if ONLY else 1)
    uploaded_count = 0
    for week in sorted(set(uploaded_booklet_weeks), reverse=True):
        if uploaded_count >= limit:
            break
        target = next((it for it in items if it["kind"] == "answer" and it["week"] == week), None)
        if not target:
            print(f"No model answer file found for week {week}.")
            continue
        if target["title"] in log:
            continue
        week_lbl = "Orientation" if target["week"] == 0 else f"Week {target['week']}"
        if do_upload(target, f"Weekly booklet model answer — {week_lbl}",
                     headless=not ARGS.show):
            uploaded_count += 1
    if uploaded_count == 0:
        print("All model answers are already uploaded. Nothing to do.")

def mode_status():
    log = load_log()
    items = scan_booklets()
    print("Booklet folder status:")
    for it in items:
        state = "UPLOADED" if it["title"] in log else "not uploaded"
        print(f"  [Week {it['week']:>2}] {it['kind']:<7} {it['title']:<40} -> {state}")
    missing_b = [it["title"] for it in items if it["kind"] == "booklet" and it["title"] not in log]
    missing_a = [it["title"] for it in items if it["kind"] == "answer"  and it["title"] not in log]
    print(f"\nBooklets not uploaded yet       : {missing_b or 'none'}")
    print(f"Model answers not uploaded yet   : {missing_a or 'none'}")
    print("Only real PDF files are accepted; every upload goes to Course Management -> "
          "Materials, and anything already on the LMS is skipped.")


# ============================================================ v6.9: cleanup
def _collect_material_rows(page, max_pages=40):
    """Read ALL Materials rows (following pagination) as {title, row_index}.
    Column layout seen on the live site: # | Material Name | Course | Grade ..."""
    rows = []
    for _ in range(max_pages):
        page_rows = page.evaluate("""() => {
            const tables = Array.from(document.querySelectorAll('table'));
            const out = [];
            for (const t of tables) {
                for (const tr of Array.from(t.querySelectorAll('tbody tr'))) {
                    const tds = Array.from(tr.querySelectorAll('td'));
                    if (!tds.length) continue;
                    out.push({
                        texts: tds.map(td => td.innerText.replace(/\\s+/g, ' ').trim()),
                        html: tr.innerHTML.length
                    });
                }
            }
            return out;
        }""")
        for r in page_rows:
            texts = r.get("texts") or []
            if not texts:
                continue
            # the '#' column is a small number; the title is the longest text cell
            non_num = [x for x in texts if x and not re.fullmatch(r"\d+", x)]
            title = max(non_num, key=len) if non_num else ""
            if title:
                rows.append({"index": len(rows) + 1, "title": title})
        clicked = page.evaluate("""() => {
            const next = Array.from(document.querySelectorAll('a'))
                .find(a => a.innerText.trim().toLowerCase() === 'next');
            if (next && next.closest('li') && !next.closest('li').classList.contains('disabled')) {
                next.click(); return true;
            }
            const active = document.querySelector('.pagination .active');
            if (active) {
                let el = active.nextElementSibling;
                if (el) { const a = el.querySelector('a') || el; a.click(); return true; }
            }
            return false;
        }""")
        if not clicked:
            break
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(700)
    return rows


def _open_materials(page):
    page.goto(f"{BASE_URL}/CourseManagement/Materials",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("table", timeout=20000)


def _delete_row_by_title(page, title):
    """Delete the Materials row whose title matches. Returns
    'deleted' | 'not-found' | 'failed: <why>'. Defensive selectors because the
    action column layout may change; every step is retried per selector."""
    # find the page containing the title, navigating if needed
    for _ in range(40):
        found = page.evaluate("""(title) => {
            const want = title.replace(/\\s+/g, ' ').trim().toLowerCase();
            const tables = Array.from(document.querySelectorAll('table'));
            for (const t of tables) {
                for (const tr of Array.from(t.querySelectorAll('tbody tr'))) {
                    const tds = Array.from(tr.querySelectorAll('td'));
                    for (const td of tds) {
                        if (td.innerText.replace(/\\s+/g, ' ').trim().toLowerCase() === want) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }""", title)
        if found:
            break
        clicked = page.evaluate("""() => {
            const next = Array.from(document.querySelectorAll('a'))
                .find(a => a.innerText.trim().toLowerCase() === 'next');
            if (next && next.closest('li') && !next.closest('li').classList.contains('disabled')) {
                next.click(); return true;
            }
            const active = document.querySelector('.pagination .active');
            if (active) {
                let el = active.nextElementSibling;
                if (el) { const a = el.querySelector('a') || el; a.click(); return true; }
            }
            return false;
        }""")
        if not clicked:
            return "not-found"
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(700)

    # dialog auto-accept (some rows confirm via a JS confirm())
    dialogs = []

    def _on_dialog(d):
        dialogs.append(d)
        try:
            d.accept()
        except Exception:
            pass

    page.on("dialog", _on_dialog)
    try:
        clicked_sel = None
        for sel in [
            f'tr:has(td:text-is("{title}")) a[href*="Delete"]',
            f'tr:has(td:text-is("{title}")) button[title*="Delete"]',
            f'tr:has(td:text-is("{title}")) a[title*="Delete"]',
            f'tr:has(td:text-is("{title}")) .btn-danger',
            f'tr:has(td:text-is("{title}")) a .fa-trash',
            f'tr:has(td:text-is("{title}")) i.fa-trash',
        ]:
            try:
                loc = page.locator(sel).first
                if loc.count():
                    loc.click(timeout=5000)
                    clicked_sel = sel
                    break
            except Exception:
                continue
        if not clicked_sel:
            return "failed: مفيش زرار حذف واضح في الصف (ابعت صورة من صفحة Materials)"

        # wait for any confirmation UI and press it
        page.wait_for_timeout(1200)
        for sel in [
            ".modal.show .btn-danger", ".modal.show button:has-text('Delete')",
            ".modal.show a:has-text('Delete')", ".modal .btn-danger",
            ".swal-button--confirm", ".btn-confirm",
            "button:has-text('Yes')", "a:has-text('Yes')",
            "button:has-text('تأكيد')", "button:has-text('حذف')",
        ]:
            try:
                loc = page.locator(sel).first
                if loc.count() and loc.is_visible():
                    loc.click(timeout=4000)
                    break
            except Exception:
                continue

        # verify it is gone (give the server a moment)
        deadline = time.time() + 12
        while time.time() < deadline:
            page.wait_for_timeout(1000)
            still = False
            try:
                still = page.evaluate("""(title) => {
                    const want = title.replace(/\\s+/g, ' ').trim().toLowerCase();
                    const tables = Array.from(document.querySelectorAll('table'));
                    for (const t of tables) {
                        for (const tr of Array.from(t.querySelectorAll('tbody tr'))) {
                            const tds = Array.from(tr.querySelectorAll('td'));
                            for (const td of tds) {
                                if (td.innerText.replace(/\\s+/g, ' ').trim().toLowerCase() === want) {
                                    return true;
                                }
                            }
                        }
                    }
                    return false;
                }""", title)
            except Exception:
                still = False
            if not still:
                return "deleted"
            _open_materials(page)
        return "failed: الصف لسه ظاهر بعد الحذف (ممكن المنصة رفضت الحذف)"
    finally:
        try:
            page.remove_listener("dialog", _on_dialog)
        except Exception:
            pass


def mode_cleanup():
    """v6.9: clean OLD files out of Course Management -> Materials.
    --list            : dry-run, writes cleanup_report.json for the app to show
    --delete-indices  : deletes the chosen rows (1-based) from that report"""
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the app, add your teacher account in "
                 "SETTINGS, then run this again from the app.")
    targets = []
    if ARGS.delete_indices:
        try:
            report = json.loads(CLEANUP_REPORT.read_text(encoding="utf-8"))
        except Exception:
            sys.exit("مفيش تقرير فحص محفوظ — اعمل «فحص الماتريال القديمة» الأول.")
        want = {int(x) for x in re.split(r"[,\s]+", ARGS.delete_indices.strip()) if x.strip().isdigit()}
        targets = [r["title"] for r in report.get("rows", []) if r.get("index") in want]
        if not targets:
            sys.exit("الأرقام المختارة مش موجودة في آخر تقرير فحص — اعمل الفحص من جديد.")
        print(f"هتمسح {len(targets)} مادة من المنصة:")
        for t in targets:
            print(f"   ✗ {t}")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not ARGS.show)
        page = browser.new_context(locale="en-US").new_page()
        try:
            login(page)
            _open_materials(page)
            rows = _collect_material_rows(page)
            if ARGS.delete_indices:
                results = {"deleted": [], "failed": [], "not_found": []}
                for title in targets:
                    print(f"   بيمسح: {title} ...")
                    outcome = _delete_row_by_title(page, title)
                    print(f"   -> {outcome}")
                    if outcome == "deleted":
                        results["deleted"].append(title)
                    elif outcome == "not-found":
                        results["not_found"].append(title)
                    else:
                        results["failed"].append({"title": title, "why": outcome})
                    try:
                        _open_materials(page)
                    except Exception:
                        pass
                CLEANUP_REPORT.write_text(json.dumps({
                    "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "last_delete": results,
                }, indent=2, ensure_ascii=False), encoding="utf-8")
                print(f"###CLEANUP_RESULT### {json.dumps(results, ensure_ascii=False)}")
                if results["failed"]:
                    sys.exit(1)
            else:
                log = load_log()
                rows_view = []
                for r in rows:
                    t = r["title"]
                    looks_old = bool(re.search(r"booklet|model answer|week\s*\d+", t, re.I)) or t in log
                    rows_view.append({"index": r["index"], "title": t,
                                      "known_to_app": t in log,
                                      "looks_like_booklet": looks_old})
                CLEANUP_REPORT.write_text(json.dumps({
                    "ts": datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "rows": rows_view,
                }, indent=2, ensure_ascii=False), encoding="utf-8")
                print(f"لقيت {len(rows)} مادة على المنصة — التقرير اتحفظ للتطبيق.")
                print("مفيش حاجة اتمسحت — ده كان فحص بس.")
        finally:
            try:
                browser.close()
            except Exception:
                pass

def main():
    if ARGS.mode == "auto":
        mode_auto()
    elif ARGS.mode == "answer":
        mode_answer()
    elif ARGS.mode == "status":
        mode_status()
    elif ARGS.mode == "cleanup":
        mode_cleanup()
    elif ARGS.mode == "file":
        if len(ARGS.rest) < 2:
            sys.exit('Usage: upload_booklet.py file "<pdf path>" "<material title>"')
        path, title = ARGS.rest[0], ARGS.rest[1]
        if not Path(path).exists():
            sys.exit(f"File not found: {path}")
        do_upload({"path": path, "title": title}, title, headless=not ARGS.show)

if __name__ == "__main__":
    main()
