"""
Alkifah LMS — Login check (READ-ONLY)
================================================================
Verifies that LMS_USERNAME / LMS_PASSWORD can sign in to lms.alkifah.edu.sa and that
the Materials page opens. It creates nothing, uploads nothing and changes nothing on
the LMS — it only signs in and reads two pages.

Use it to test a teacher's email + password before running any upload.

Usage:
    python check_login.py
    python check_login.py --show        (watch the browser)

Exit codes:
    0 = login OK
    1 = login failed (reason is printed)

Env vars (or edit SETTINGS):
    LMS_USERNAME, LMS_PASSWORD
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os
import sys
import argparse

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# ============ SETTINGS — EDIT ONLY THESE LINES ============
USERNAME = ""
PASSWORD = ""
# ==========================================================

USERNAME = os.environ.get("LMS_USERNAME", USERNAME)
PASSWORD = os.environ.get("LMS_PASSWORD", PASSWORD)

BASE_URL = "https://lms.alkifah.edu.sa"


def fill_first(page, selectors, value):
    """Fill the first selector that exists. Returns the selector used, or None."""
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return sel
        except Exception:
            continue
    return None


def main():
    ap = argparse.ArgumentParser(description="Alkifah LMS login check (read-only)")
    ap.add_argument("--show", action="store_true", help="Show the browser window.")
    args = ap.parse_args()

    print("Alkifah LMS — login check (read-only: signs in, reads the Materials page, "
          "changes nothing)")
    if not USERNAME:
        sys.exit("FAILED — no email given. Set LMS_USERNAME (in the app: teacher "
                 "profile / Setup tab).")
    if not PASSWORD:
        sys.exit("FAILED — no password given. Set LMS_PASSWORD (in the app: teacher "
                 "profile). It is never sent anywhere except lms.alkifah.edu.sa.")
    print(f"  email: {USERNAME}")

    try:
        with sync_playwright() as p:
            try:
                browser = p.chromium.launch(headless=not args.show)
            except Exception as e:
                detail = str(e)
                if "Executable doesn't exist" in detail or "playwright install" in detail:
                    sys.exit("FAILED — the Chromium browser is not installed for Playwright.\n"
                             "  Fix:  playwright install chromium")
                if "shared libraries" in detail or "cannot open shared object" in detail:
                    sys.exit("FAILED — Chromium is installed but this machine is missing its "
                             "system libraries.\n"
                             "  On Linux:  playwright install-deps\n"
                             "  On Windows this does not normally happen — send this line to "
                             "your admin if it does.")
                sys.exit(f"FAILED — could not start Chromium: {detail.splitlines()[0]}")
            context = browser.new_context(locale="en-US")
            page = context.new_page()

            # ---- open the login page (2 attempts, the page can be slow) ----
            last = None
            for _ in range(2):
                try:
                    page.goto(f"{BASE_URL}/Identity/Account/LogIn",
                              wait_until="domcontentloaded", timeout=60000)
                    last = None
                    break
                except Exception as e:
                    last = e
            if last:
                browser.close()
                sys.exit(f"FAILED — could not open {BASE_URL} (network?): {last}")

            try:
                page.wait_for_selector("#Input_Email", timeout=15000)
            except PWTimeout:
                browser.close()
                sys.exit(f"FAILED — the login form did not appear. Landed on: {page.url}")

            # ---- diagnostics: which selectors does this LMS really use? ----
            found = page.evaluate("""() => ({
                email:    !!document.querySelector('#Input_Email'),
                password: !!document.querySelector('#Input_Password'),
                legacy:   !!document.querySelector('#passwordInput')
            })""")
            print(f"  login form: email={found.get('email')} "
                  f"password=#Input_Password:{found.get('password')} "
                  f"old-#passwordInput:{found.get('legacy')}")
            if not found.get("password"):
                print("  WARNING: #Input_Password is missing on this page — the pack's "
                      "login fix may need a new selector. Send this line to your admin.")

            used_email = fill_first(page, ["input[name='Input.Email']", "#Input_Email"], USERNAME)
            used_pw = fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                                        "#Input_Password", "input[type='password']"],
                                 PASSWORD)
            if not used_email or not used_pw:
                browser.close()
                sys.exit("FAILED — could not find the email/password boxes on the login page.")
            print(f"  filled: {used_email} / {used_pw}")

            for sel in ["button[type='submit']", "button:has-text('Log in')",
                        "input[type='submit']"]:
                try:
                    page.click(sel, timeout=6000)
                    break
                except Exception:
                    continue

            try:
                page.wait_for_url(lambda u: "login" not in u.lower(), timeout=25000)
            except PWTimeout:
                browser.close()
                sys.exit("FAILED — still on the login page after submitting. "
                         "The email or the password is wrong (or the account is locked).")

            # ---- real authentication check: read the Materials page ----
            page.goto(f"{BASE_URL}/CourseManagement/Materials",
                      wait_until="domcontentloaded", timeout=60000)
            if "login" in page.url.lower():
                browser.close()
                sys.exit("FAILED — the LMS bounced us back to the login page; "
                         "the account has no access to Course Management.")
            rows = 0
            try:
                page.wait_for_selector("table", timeout=20000)
                rows = page.evaluate("""() => {
                    const t = document.querySelector('table');
                    return t ? t.querySelectorAll('tbody tr').length : 0;
                }""")
            except PWTimeout:
                pass
            browser.close()

        print(f"LOGIN OK — {USERNAME}")
        print(f"  Materials page reachable, rows visible on page 1: {rows}")
        print("  Nothing was created, uploaded or changed.")
    except Exception as e:
        sys.exit(f"FAILED — unexpected error: {type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
