"""
Alkifah LMS — Exam Assigner (v2, fixed)
================================================================
Fixes over the original v1:
  * Login uses #Input_Password (the original used #passwordInput).
  * `--show` flag forces a visible browser.
  * Env-var credential overrides.
  * Better success/failure reporting per exam.
  * Verifies the assignment toast more strictly.

Usage:
    python assign_exam.py <examId> [<examId> ...]
    python assign_exam.py 16144 --show

Toggles:
  Active ON | Show Exam Result ON | Shuffle Question ON | Shuffle Answer ON
  | Allow Practice ON | Mobile-only OFF | Others-edit OFF | Public OFF
Start: now + 3 minutes. End: now + 2 weeks.
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os, sys, argparse
from datetime import datetime, timedelta
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

USERNAME = os.environ.get("LMS_USERNAME", "")
PASSWORD = os.environ.get("LMS_PASSWORD", "")
BASE_URL = "https://lms.alkifah.edu.sa"

USERNAME = os.environ.get("LMS_USERNAME", USERNAME)
PASSWORD = os.environ.get("LMS_PASSWORD", PASSWORD)

TOGGLES_ON  = ["btnChangeStatus", "btnDisplayResult", "btnShuffleQuestions",
               "btnShuffleAnswers", "btnAllowPractice"]
TOGGLES_OFF = ["btnForceMobile", "btnCanEditQuestion", "btn-public-for-other-teachers"]

ap = argparse.ArgumentParser(description="Alkifah LMS Exam Assigner")
ap.add_argument("ids", nargs="+", help="One or more exam IDs to process.")
ap.add_argument("--show", action="store_true",
                help="Show the browser window (default: headless).")
ARGS = ap.parse_args()

# --- ALKIFAH-FIX-CONVENTIONS begin --------------------------------------------
# When an assessment opens and when it closes on the platform.
#   LMS_OPEN_MINUTES (or LMS_MINUTES_AHEAD) : open N minutes after creation - default 5
#   LMS_CLOSE_MONTHS                       : stay open that many calendar months - default 2
#   LMS_CLOSE_DAYS                         : exact day count instead, if you prefer
def _alk_open_minutes():
    for key in ("LMS_OPEN_MINUTES", "LMS_MINUTES_AHEAD"):
        try:
            v = int(os.environ.get(key) or 0)
            if v > 0:
                return v
        except Exception:
            continue
    return 5


def _alk_close_date():
    import calendar
    now = datetime.now()
    try:
        days = int(os.environ.get("LMS_CLOSE_DAYS") or 0)
    except Exception:
        days = 0
    if days > 0:
        return now + timedelta(days=days)
    try:
        months = int(os.environ.get("LMS_CLOSE_MONTHS") or 2)
    except Exception:
        months = 2
    y = now.year + (now.month - 1 + months) // 12
    m = (now.month - 1 + months) % 12 + 1
    return now.replace(year=y, month=m, day=min(now.day, calendar.monthrange(y, m)[1]))
# --- ALKIFAH-FIX-CONVENTIONS end ----------------------------------------------


def fill_first(page, selectors, value):
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return True
        except Exception:
            continue
    return False

def click_first(page, selectors, timeout=6000):
    for sel in selectors:
        try:
            page.click(sel, timeout=timeout)
            return True
        except Exception:
            continue
    return False

def login(page):
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    last = None
    for _ in range(2):
        try:
            page.goto(f"{BASE_URL}/Identity/Account/LogIn",
                      wait_until="domcontentloaded", timeout=60000)
            last = None
            break
        except Exception as e:
            last = e
    if last:
        sys.exit(f"Could not open LMS login page: {last}")
    page.wait_for_selector("#Input_Email", timeout=15000)
    if not fill_first(page, ["input[name='Input.Email']", "#Input_Email"], USERNAME):
        sys.exit("Could not find the email box on the login page.")
    # v6.2: cover both ID layouts (current #passwordInput, legacy #Input_Password)
    if not fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                             "#Input_Password", "input[type='password']"], PASSWORD):
        sys.exit("Could not find the password box on the login page.")
    click_first(page, ["button[type='submit']", "input[type='submit']"])
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=20000)
    except PWTimeout:
        sys.exit("Login failed — check USERNAME/PASSWORD.")

def dtl(d):
    return f"{d.year}-{d.month:02d}-{d.day:02d}T{d.hour:02d}:{d.minute:02d}"

def process(page, exam_id):
    page.goto(f"{BASE_URL}/Assessments/Exams/Details?Id={exam_id}",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#btnAssignClass", timeout=15000)
    changed = page.evaluate("""(want) => {
        const changed = [];
        for (const [id, desired] of Object.entries(want)) {
            const el = document.getElementById(id);
            if (!el) { changed.push(id + ':missing'); continue; }
            if (el.checked !== desired) { el.click(); changed.push(id); }
        }
        return changed;
    }""", {**{t: True for t in TOGGLES_ON}, **{t: False for t in TOGGLES_OFF}})
    page.wait_for_timeout(2000)
    page.evaluate("""() => {
        const r = document.getElementById('allStudentsRadioBtn'); if (r) r.click();
        const sel = document.getElementById('ClassId');
        if (sel) { for (const o of sel.options) o.selected = true;
                   sel.dispatchEvent(new Event('change', {bubbles:true})); }
    }""")
    try:
        page.fill("#ExamStartDate", dtl(datetime.now() + timedelta(minutes=_alk_open_minutes())))
    except Exception:
        pass
    try:
        page.fill("#ExamEndDate", dtl(_alk_close_date()))
    except Exception:
        pass
    page.evaluate("""() => {
        const btn = document.getElementById('btnAssignClass');
        if (btn) { btn.disabled = false; btn.click(); }
    }""")
    page.wait_for_timeout(4000)
    toasts = page.evaluate("""() => Array.from(document.querySelectorAll('.toast, .swal2-popup'))
        .map(t => t.innerText.trim())
        .filter(t => /assign|success|saved/i.test(t)).length""")
    print(f"  exam {exam_id}: toggles={changed or 'none needed'}, assign_success={toasts > 0}")
    return toasts > 0

def main():
    # login details are checked before the browser starts
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not ARGS.show)
        context = browser.new_context(locale="en-US")
        page = context.new_page()
        login(page)
        all_ok = True
        for exam_id in ARGS.ids:
            try:
                ok = process(page, exam_id)
                all_ok = all_ok and ok
            except Exception as e:
                print(f"  exam {exam_id}: FAILED — {e}")
                all_ok = False
        browser.close()
    print("DONE" if all_ok else "FINISHED WITH ERRORS — check the output above")
    sys.exit(0 if all_ok else 1)

if __name__ == "__main__":
    main()
