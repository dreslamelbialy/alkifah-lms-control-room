"""
Alkifah LMS — List the teacher's courses (grades) + classes (READ-ONLY)
================================================================
v6.6: solves the multi-grade problem. A teacher who teaches more than one grade
picks the grade in the app, and every upload (materials / booklets /
assessments) then targets exactly that course — nothing ever lands in the
wrong grade.

This script signs in, opens Course Management -> Materials/Create and reads:
  * every option of the Course dropdown (#CourseId)  -> the courses/grades
  * for each course, the Classes multi-select (#classesSelectList)
    (classes load by AJAX after a course is chosen)
It creates nothing and changes nothing (the course selection is reverted and
the form is never saved).

Output: ONE JSON line on stdout:
  {"ok": true, "courses": [{"name": "Science 3 - Grade 9",
                            "classes": ["G9A", "G9B"]}, ...]}
All progress/human text goes to stderr.

Env vars:
    LMS_USERNAME, LMS_PASSWORD
Exit codes: 0 = ok (JSON on stdout)   1 = failed (reason on stderr)
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os
import sys

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

USERNAME = os.environ.get("LMS_USERNAME", "")
PASSWORD = os.environ.get("LMS_PASSWORD", "")
BASE_URL = "https://lms.alkifah.edu.sa"


def log(msg):
    sys.stderr.write(str(msg) + "\n")
    sys.stderr.flush()


def fill_first(page, selectors, value):
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return sel
        except Exception:
            continue
    return None


def login(page):
    page.goto(f"{BASE_URL}/Identity/Account/LogIn",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#Input_Email", timeout=15000)
    if not fill_first(page, ["input[name='Input.Email']", "#Input_Email",
                             "input[type='email']"], USERNAME):
        raise RuntimeError("could not find the email box on the login page")
    if not fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                             "#Input_Password", "input[type='password']"], PASSWORD):
        raise RuntimeError("could not find the password box on the login page")
    for sel in ["button[type='submit']", "button:has-text('Log in')",
                "input[type='submit']"]:
        try:
            page.click(sel, timeout=6000)
            break
        except Exception:
            continue
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=25000)
    except PWTimeout:
        raise RuntimeError("login failed — check the email/password in the app settings")
    try:
        page.wait_for_load_state("networkidle", timeout=8000)
    except Exception:
        pass


def main():
    if not USERNAME or not PASSWORD:
        log("FAILED — no teacher account. Open the app -> SETTINGS and save the "
            "LMS email/password first.")
        sys.exit(1)

    log("Alkifah LMS — reading your courses/grades (read-only, takes ~30-60s)...")
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_context(locale="en-US").new_page()
            login(page)
            log("  logged in — opening the Materials/Create page...")

            page.goto(f"{BASE_URL}/CourseManagement/Materials/Create",
                      wait_until="domcontentloaded", timeout=60000)
            page.wait_for_selector("#general_form", timeout=20000)
            page.wait_for_selector("#CourseId", timeout=20000)

            courses_raw = page.evaluate("""() => {
                const el = document.getElementById('CourseId');
                if (!el) return [];
                return Array.from(el.options)
                    .filter(o => (o.value || '').trim() !== '')
                    .map(o => ({ value: o.value, name: o.text.trim() }));
            }""")
            if not courses_raw:
                raise RuntimeError("the course dropdown was empty — send a "
                                   "screenshot of the Materials/Create page to "
                                   "your admin")
            log(f"  found {len(courses_raw)} course(s) — reading classes for "
                f"each one...")

            courses = []
            for i, c in enumerate(courses_raw, 1):
                classes = []
                try:
                    page.select_option("#CourseId", value=c["value"])
                    # classes load by AJAX after the course is chosen
                    page.wait_for_function(
                        """() => { const el =
                                   document.getElementById('classesSelectList');
                               return el && !el.disabled &&
                                      el.options.length > 0; }""",
                        timeout=10000)
                    classes = page.evaluate(
                        """() => Array.from(
                               document.getElementById('classesSelectList').options)
                               .map(o => o.text.trim()).filter(Boolean)""")
                except Exception:
                    classes = []
                courses.append({"name": c["name"], "classes": classes})
                log(f"   [{i}/{len(courses_raw)}] {c['name']}"
                    + (f"  ({', '.join(classes)})" if classes else ""))
            browser.close()

        sys.stdout.write(
            __import__("json").dumps({"ok": True, "courses": courses},
                                     ensure_ascii=False))
        sys.stdout.flush()
        log("  done — nothing was created or changed on the LMS.")
    except Exception as e:
        log(f"FAILED — {type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
