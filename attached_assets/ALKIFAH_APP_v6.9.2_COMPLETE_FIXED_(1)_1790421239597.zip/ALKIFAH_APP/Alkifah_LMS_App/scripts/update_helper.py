"""Alkifah LMS App - update helper (v6.6)
=========================================
Used by the web app's "update" button so the teacher never has to pick a file
by hand. Two commands:

    python update_helper.py scan [--self "APP_DIR"]
        -> {"ok": true, "zips": [{path, name, kind, size_mb, mtime, valid}, ...]}
        Looks for ALKIFAH*.zip update packages AND ALREADY-EXTRACTED package
        folders (v6.6: e.g. ALKIFAH_APP_NEW6.5 that Windows Explorer extracted)
        in Downloads / Desktop / Documents / OneDrive folders and next to the
        installed app. --self excludes the running app itself.

    python update_helper.py extract --zip "PATH" --dest "DIR"
        -> {"ok": true, "root": "...", "update_ps1": "..."}
        Validates the zip really is an ALKIFAH app package (webapp/server.js
        inside), extracts it safely into DIR and reports where the package
        root (the folder holding update_app.ps1) landed.

The JSON goes to stdout only; everything else goes to stderr.
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import argparse
import json
import os
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ZIP_NAME_RE = re.compile(r"^alkifah.*\.zip$", re.I)


def emit(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=True))
    sys.stdout.flush()


def look_dirs(extra):
    home = os.environ.get("USERPROFILE") or str(Path.home())
    dirs = [
        extra,
        os.path.join(home, "Downloads"),
        os.path.join(home, "Desktop"),
        os.path.join(home, "Documents"),
        os.path.join(home, "OneDrive", "Desktop"),
        os.path.join(home, "OneDrive", "Documents"),
        os.path.join(home, "OneDrive", "Downloads"),
    ]
    out, seen = [], set()
    for d in dirs:
        if not d:
            continue
        d = os.path.abspath(d)
        if d.lower() in seen:
            continue
        seen.add(d.lower())
        out.append(d)
    return out


def zip_is_package(path):
    """True when the zip contains a webapp/server.js entry (the app package)."""
    try:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                n = name.replace("\\", "/").lower()
                if n.endswith("webapp/server.js"):
                    return True
    except Exception:
        return False
    return False


def find_pkg_root(folder):
    """v6.6: return the package root (folder holding update_app.ps1 + webapp/)
    for an ALREADY-EXTRACTED package: check the folder itself, then one level
    of children (e.g. ALKIFAH_APP_NEW6.5/ALKIFAH_APP). None otherwise."""
    if (os.path.isfile(os.path.join(folder, "update_app.ps1"))
            and os.path.isdir(os.path.join(folder, "webapp"))):
        return folder
    try:
        for name in sorted(os.listdir(folder)):
            sub = os.path.join(folder, name)
            if not os.path.isdir(sub):
                continue
            if (os.path.isfile(os.path.join(sub, "update_app.ps1"))
                    and os.path.isdir(os.path.join(sub, "webapp"))):
                return sub
    except OSError:
        pass
    return None


def same_path(a, b):
    try:
        return os.path.normcase(os.path.abspath(a)) == os.path.normcase(
            os.path.abspath(b))
    except Exception:
        return False


def pkg_version_zip(zip_path):
    """v6.8: read ALKIFAH_APP/VERSION from inside the package zip."""
    try:
        import zipfile
        with zipfile.ZipFile(zip_path) as z:
            return z.read("ALKIFAH_APP/VERSION").decode("utf-8", "replace").strip()
    except Exception:
        return None


def pkg_version_folder(root):
    """v6.8: read VERSION from an extracted package root."""
    try:
        with open(os.path.join(root, "VERSION"), encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return None


def cmd_scan(extra, self_dir=None):
    found = {}

    def add(path, name, kind, mtime_s, size_mb=None, ts=None, version=None):
        key = os.path.normcase(os.path.abspath(path))
        if key in found:
            return
        if self_dir and same_path(path, self_dir):
            return
        found[key] = {
            "path": path,
            "name": name,
            "kind": kind,
            "size_mb": size_mb,
            "mtime": mtime_s,
            "ts": ts,
            "version": version,
            "valid": None,
        }

    for d in look_dirs(extra):
        try:
            if not os.path.isdir(d):
                continue
            for name in os.listdir(d):
                full = os.path.join(d, name)
                if os.path.isfile(full) and ZIP_NAME_RE.match(name):
                    st = os.stat(full)
                    add(full, name, "zip",
                        datetime.fromtimestamp(st.st_mtime).strftime(
                            "%Y-%m-%d %H:%M"),
                        round(st.st_size / 1e6, 1),
                        ts=st.st_mtime,
                        version=pkg_version_zip(full))
                elif os.path.isdir(full) and name.lower().startswith("alkifah"):
                    # v6.6: an extracted update package (no zip at all)
                    try:
                        st = os.stat(full)
                        add(full, name + " (مجلد جاهز)", "folder",
                            datetime.fromtimestamp(st.st_mtime).strftime(
                                "%Y-%m-%d %H:%M"),
                            ts=st.st_mtime,
                            version=pkg_version_folder(find_pkg_root(full) or ""))
                    except OSError:
                        pass
        except OSError:
            continue
    items = sorted(found.values(), key=lambda x: x["mtime"], reverse=True)[:10]
    for it in items:
        if it["kind"] == "zip":
            it["valid"] = zip_is_package(it["path"])
        else:
            it["valid"] = find_pkg_root(it["path"]) is not None
    emit({"ok": True, "zips": items})


def safe_extract(z, dest):
    """Extract guarding against zip-slip paths."""
    dest = os.path.abspath(dest)
    for info in z.infolist():
        name = info.filename.replace("\\", "/")
        if name.startswith("/") or ".." in name.split("/"):
            continue  # skip unsafe entries
        target = os.path.abspath(os.path.join(dest, name))
        if not (target == dest or target.startswith(dest + os.sep)):
            continue
        if name.endswith("/"):
            os.makedirs(target, exist_ok=True)
            continue
        os.makedirs(os.path.dirname(target), exist_ok=True)
        with z.open(info) as src, open(target, "wb") as out:
            while True:
                chunk = src.read(1024 * 256)
                if not chunk:
                    break
                out.write(chunk)


def cmd_extract(zip_path, dest):
    if not os.path.isfile(zip_path):
        emit({"ok": False, "error": "file not found"})
        return
    if not ZIP_NAME_RE.match(os.path.basename(zip_path)):
        emit({"ok": False, "error": "not an ALKIFAH zip package"})
        return
    try:
        os.makedirs(dest, exist_ok=True)
        with zipfile.ZipFile(zip_path) as z:
            names = [i.filename.replace("\\", "/") for i in z.infolist()]
            if not any(n.lower().endswith("webapp/server.js") for n in names):
                emit({"ok": False, "error": "this zip has no webapp/server.js - it is not the app update package"})
                return
            safe_extract(z, dest)
    except Exception as e:
        emit({"ok": False, "error": str(e)})
        return
    # find the package root: the folder (inside dest) that holds update_app.ps1
    candidates = []
    for dirpath, dirnames, filenames in os.walk(dest):
        if "update_app.ps1" in filenames and "webapp" in dirnames:
            candidates.append(dirpath)
            dirnames[:] = []  # do not descend further
    if not candidates:
        emit({"ok": False, "error": "update_app.ps1 not found inside the package (old package? use the manual steps)"})
        return
    root = min(candidates, key=len)  # shallowest match
    emit({"ok": True, "root": root, "update_ps1": os.path.join(root, "update_app.ps1")})


def main():
    ap = argparse.ArgumentParser(description="Alkifah app update helper")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p_scan = sub.add_parser("scan")
    p_scan.add_argument("--extra", default="", help="one more folder to search (e.g. the app's parent)")
    p_scan.add_argument("--self", dest="self_dir", default="",
                        help="the running app's own dir (never suggest updating it with itself)")
    p_ext = sub.add_parser("extract")
    p_ext.add_argument("--zip", required=True)
    p_ext.add_argument("--dest", required=True)
    args = ap.parse_args()
    try:
        if args.cmd == "scan":
            cmd_scan(args.extra if args.extra else None,
                     args.self_dir if args.self_dir else None)
        else:
            cmd_extract(args.zip, args.dest)
    except Exception as e:  # never crash without JSON
        emit({"ok": False, "error": str(e)})


if __name__ == "__main__":
    main()
