"""
Alkifah LMS — Electronic Assessment Creator (v2, fixed)
================================================================
...
Spec JSON:
{
  "title": "<Lesson Title> assessment",
  "duration": 10,
  "type": "Quiz",            # Quiz / Assignment / Homework
  "sheet_path": "C:/path/sheet.pdf",   # used when type = Homework
  "questions": [
    {"text": "...", "level": "Easy", "mark": 1,
     "options": ["A...", "B...", "C...", "D..."], "correct": 0,
     "image_path": "C:/path/figure.png"}   # optional, embeds in the question
  ]
}
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os, re, sys, json, base64, argparse
from pathlib import Path
from datetime import datetime
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# --- ALKIFAH-FIX-12 begin --------------------------------------------------------
_ALK_TITLE = None
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app"))
    import alkifah_title as _ALK_TITLE
except Exception:
    _ALK_TITLE = None


def generated_title(spec, spec_path):
    """The unified name for this run, from the best source available:
    an explicit lesson file in the spec, else the spec file's name, else the
    app's upload log (the platform's own record of the material's name). When two
    sources name the SAME lesson (same week + session), the platform's own words
    win; when they name different lessons, this run's file name wins."""
    c = {}
    if _ALK_TITLE is not None:
        try:
            c["spec"] = _ALK_TITLE.title_for(spec, None, None)
            c["file"] = _ALK_TITLE.title_for({}, str(spec_path), None)
            c["log"] = _ALK_TITLE.title_for({}, None, str(Path(__file__).resolve().parent))
        except Exception:
            pass
    if c.get("spec"):
        return c["spec"]
    f, l = c.get("file", ""), c.get("log", "")
    if f and l:
        try:
            wkf, wkl = _ALK_TITLE._week_session(f), _ALK_TITLE._week_session(l)
        except Exception:
            wkf = wkl = ("", "")
        if wkf and wkl:
            return l if wkf == wkl else f
        return l if (wkl and not wkf) else f
    return f or l


def _alk_run_log(lines):
    try:
        if _ALK_TITLE is not None:
            _ALK_TITLE.run_log(Path(__file__).resolve().parent, lines)
            return
    except Exception:
        pass
    try:
        import time as _t
        f = Path(__file__).resolve().parent / "ASSESS_run_log.txt"
        with f.open("a", encoding="utf-8") as fh:
            fh.write("%s  %s\n" % (_t.strftime("%Y-%m-%d %H:%M:%S"),
                                   " | ".join(str(x) for x in lines)))
    except Exception:
        pass


def _alk_dismiss_popups(page):
    """The platform puts overlays in front of the forms - the biggest one is the
    'Welcome to a New School Year' banner (id=scolaireWelcomeModal), which swallows
    every click until it is closed. Close it with its own button when it has one,
    remove it (and the mouse-blocking backdrop) when it does not. Returns what was
    closed, so the caller can say so out loud."""
    done = []
    try:
        done = page.evaluate("""() => {
            const out = [];
            const closeIn = (el) => {
                const cands = Array.from(el.querySelectorAll(
                    '.btn-close, [data-dismiss="modal"], [aria-label="Close"]'))
                    .concat(Array.from(el.querySelectorAll('button, a')));
                for (const b of cands) {
                    const t = ((b.innerText || '') + ' ' +
                               (b.getAttribute('aria-label') || '')).trim();
                    if (b.classList.contains('btn-close') ||
                        /close|dismiss|got it|continue|ok|later|next/i.test(t)) {
                        try { b.click(); out.push('closed via "' + (t || 'close') + '"'); }
                        catch (e) {}
                        return true;
                    }
                }
                return false;
            };
            document.querySelectorAll('#scolaireWelcomeModal, .scolaire-welcome-popup')
                .forEach(el => {
                    if (!closeIn(el)) {
                        try { el.remove(); out.push('removed ' + (el.id || el.className)); }
                        catch (e) {}
                    }
                });
            document.querySelectorAll('.modal-backdrop.show').forEach(b => {
                try { b.remove(); out.push('removed backdrop'); } catch (e) {}
            });
            return out;
        }""")
        done = [str(d) for d in (done or []) if str(d).strip()]
    except Exception:
        pass
    try:
        page.keyboard.press("Escape")
    except Exception:
        pass
    return done


def _alk_guarded_click(page, selector, timeout=15000):
    """Click, and when the platform put a popup in front of the button, close the
    popup and try again - instead of dying after 30 seconds with a long red error."""
    try:
        page.click(selector, timeout=timeout)
        return
    except Exception:
        _alk_dismiss_popups(page)
        page.wait_for_timeout(800)
        page.click(selector, timeout=timeout)


def _alk_heal_submit(page, title, duration, exam_type):
    """The first submit was answered with the platform's own complaint instead of the
    Details page. Read what it said, fix what we can, submit once more. When the
    platform says the name is already on it, find the existing exam and stop - a
    second copy is worse than stopping. Returns the new exam id or None."""
    errs, fixed = [], []
    if _ALK_TITLE is not None:
        try:
            errs = _ALK_TITLE.form_errors(page)
        except Exception:
            pass
    joined = " | ".join(errs)[:300]
    has_title = ""
    try:
        has_title = page.input_value("#Title", timeout=3000)
    except Exception:
        pass
    if (not has_title) and title:
        try:
            page.fill("#Title", title, timeout=5000)
            fixed.append("filled the empty Title box with: " + title)
        except Exception:
            pass
    if _ALK_TITLE is not None:
        try:
            fixed.extend(_ALK_TITLE.fill_missing_dates(page))
        except Exception:
            pass
    if re.search(r"(?i)already (exists|there)|same title|duplicate|in use|already added",
                 joined):
        found = ""
        if _ALK_TITLE is not None:
            try:
                found = _ALK_TITLE.find_exam_id(page, BASE_URL, title)
            except Exception:
                pass
        if found:
            print("  !! the platform says this name is already on it - and it is there:")
            print(f"     {BASE_URL}/Assessments/Exams/Details?Id={found}")
            print("     nothing new was created. Open that link; if you want a FRESH")
            print("     exam under this name, delete the old one on the platform first.")
            try:
                _alk_run_log(["STOPPED (no duplicate): the exam '%s' already exists on "
                              "the platform, id %s" % (title, found)])
            except Exception:
                pass
            sys.exit(0)
        return None
    if fixed:
        print("  platform complaint: " + (joined or "(none printed on the page)"))
        for fx in fixed:
            print("  fixed: " + fx)
        try:
            _alk_run_log(["the platform rejected the first submit (" +
                          (joined or "no message") + ") - fixed: " + "; ".join(fixed) +
                          " - submitted again"])
        except Exception:
            pass
        _alk_guarded_click(page, "form[action='/Assessments/Exams/Create'] input[type='submit']")
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(2500)
        m = re.search(r"Details(?:\?Id=|/)([A-Za-z0-9]+)", page.url)
        return m.group(1) if m else None
    return None


def _alk_fail_exit(page, title):
    extra = ""
    if _ALK_TITLE is not None:
        try:
            errs = _ALK_TITLE.form_errors(page)
            if errs:
                extra = " The platform said: " + " | ".join(errs)[:300]
        except Exception:
            pass
    try:
        _alk_run_log(["FAILED creating the exam '%s' - landed on %s%s"
                      % (title, page.url, extra)])
    except Exception:
        pass
    sys.exit("Could not determine the new exam id. Landed on: %s%s" % (page.url, extra))
# --- ALKIFAH-FIX-12 end ----------------------------------------------------------


## ============ SETTINGS ============
USERNAME = os.environ.get("LMS_USERNAME", "")
PASSWORD = os.environ.get("LMS_PASSWORD", "")
COURSE_STARTSWITH = "science 3"
LOG_PATH = Path(__file__).resolve().parent / "assessment_log.json"
QUESTION_RETRIES = 2
## ==================================

USERNAME = os.environ.get("LMS_USERNAME", USERNAME)
PASSWORD = os.environ.get("LMS_PASSWORD", PASSWORD)
# v6: the course name comes from the teacher profile (LMS_COURSE) instead of being fixed in the file.
COURSE_STARTSWITH = os.environ.get("LMS_COURSE", COURSE_STARTSWITH).split(" - ")[0].strip().lower()

BASE_URL = os.environ.get("LMS_BASE_URL", "https://lms.alkifah.edu.sa")  # ALKIFAH-FIX-12: another academy (or the test platform) can set the host

ap = argparse.ArgumentParser(description="Alkifah LMS Assessment Creator")
ap.add_argument("spec", help="Path to spec JSON file.")
ap.add_argument("--resume", metavar="EXAM_ID",
                help="Resume adding questions to an existing exam id.")
ap.add_argument("--show", action="store_true",
                help="Show the browser window (default: headless).")
ap.add_argument("--dry-run", action="store_true",
                help="Load spec and print plan, but do not touch the LMS.")
ARGS = ap.parse_args()

def load_log():
    if LOG_PATH.exists():
        try:
            return json.loads(LOG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_log(log):
    LOG_PATH.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")

def fill_first(page, selectors, value):
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return True
        except Exception:
            continue
    return False

def click_first(page, selectors, timeout=6000):
    for sel in selectors:
        try:
            page.click(sel, timeout=timeout)
            return True
        except Exception:
            continue
    return False

def login(page):
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    """FIX: original used #passwordInput which does not exist on the login form."""
    last = None
    for _ in range(2):
        try:
            page.goto(f"{BASE_URL}/Identity/Account/LogIn",
                      wait_until="domcontentloaded", timeout=60000)
            last = None
            break
        except Exception as e:
            last = e
    if last:
        sys.exit(f"Could not open LMS login page: {last}")
    page.wait_for_selector("#Input_Email", timeout=10000)
    if not fill_first(page, ["input[name='Input.Email']", "#Input_Email"], USERNAME):
        sys.exit("Could not find the email box on the login page.")
    # v6.2: the login page currently uses id="passwordInput" (name="Input.Password");
    # keep the name-based selector first and cover both ID layouts.
    if not fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                             "#Input_Password", "input[type='password']"], PASSWORD):
        sys.exit("Could not find the password box on the login page.")
    click_first(page, ["button[type='submit']", "input[type='submit']"])
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=20000)
    except PWTimeout:
        sys.exit("Login failed — check USERNAME/PASSWORD.")

def create_exam(page, title, duration, exam_type):
    page.goto(f"{BASE_URL}/Assessments/Exams/Create",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#CourseId", timeout=15000)
    _alk_dismiss_popups(page)      # ALKIFAH-FIX-12: the welcome banner covers the form
    course_guid = page.evaluate("""(pref) => {
        const el = document.getElementById('CourseId');
        for (const o of el.options) {
            if (o.value && o.text.trim().toLowerCase().startsWith(pref)) {
                el.value = o.value;
                el.dispatchEvent(new Event('change', {bubbles:true}));
                return o.value;
            }
        }
        return null;
    }""", COURSE_STARTSWITH)
    if not course_guid:
        sys.exit("No course starting with 'Science 3' found.")
    page.fill("#Title", title)
    page.fill("#Duration", str(duration))
    page.evaluate("""(t) => {
        const el = document.getElementById('ExamTypeId');
        for (const o of el.options) {
            if (o.text.trim().toLowerCase() === t.toLowerCase()) {
                el.value = o.value;
                el.dispatchEvent(new Event('change', {bubbles:true}));
                return;
            }
        }
        throw new Error('Exam type not found: ' + t);
    }""", exam_type)
    _alk_guarded_click(page, "form[action='/Assessments/Exams/Create'] input[type='submit']")   # ALKIFAH-FIX-12
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(2500)
    m = re.search(r"Details(?:\?Id=|/)([A-Za-z0-9]+)", page.url)
    if not m:
        m2 = page.evaluate("""() => {
            const a = Array.from(document.querySelectorAll('a'))
                .map(x => x.getAttribute('href') || '')
                .find(h => h.includes('Exams/Details'));
            return a || null;
        }""")
        if m2:
            m = re.search(r"Details(?:\?Id=|/)([A-Za-z0-9]+)", m2)
    if not m:
        m = _alk_heal_submit(page, title, duration, exam_type)   # ALKIFAH-FIX-12
    if not m:
        _alk_fail_exit(page, title)                              # ALKIFAH-FIX-12
    return m.group(1), course_guid

def _image_html(q):
    """v6.4: base64-embed the optional question image into the TinyMCE text
    (math teachers attach a screenshot of the problem). Safe on missing or
    oversized files — skips with a note instead of failing the question."""
    p = str((q or {}).get("image_path", "") or "").strip()
    if not p:
        return ""
    f = Path(p)
    if not f.exists():
        print(f"    (image skipped — file not found: {p})")
        return ""
    try:
        data = f.read_bytes()
    except OSError as e:
        print(f"    (image skipped — cannot read: {e})")
        return ""
    if len(data) > 700 * 1024:
        print(f"    (image skipped — bigger than 700KB: {f.name}. "
              f"Compress it and try again.)")
        return ""
    ext = f.suffix.lower()
    mime = "image/png" if ext == ".png" else \
           "image/gif" if ext == ".gif" else "image/jpeg"
    b64 = base64.b64encode(data).decode("ascii")
    return ('<p><img src="data:%s;base64,%s" style="max-width:100%%;" /></p>'
            % (mime, b64))


def add_mcq(page, q, q_index):
    """Add ONE multiple-choice question. Raises on hard failure.
    FIX: the original had `n = radios.count()` which shadowed the
    parameter `n` (the question index). Renamed to `radio_count`.
    """
    page.goto(page._cm_url, wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("button:has-text('Add Question')", timeout=15000)
    page.evaluate("""() => {
        const btn = Array.from(document.querySelectorAll('button'))
            .find(b => b.innerText.trim() === 'Add Question');
        if (btn) btn.click();
    }""")
    page.wait_for_timeout(800)
    page.evaluate("""() => {
        const el = Array.from(document.querySelectorAll('div,span,h5,h6'))
            .find(e => e.innerText.trim() === 'Multiple Choice' && e.children.length === 0);
        if (el) el.click(); else throw new Error('Multiple Choice option not found');
    }""")
    page.wait_for_timeout(1200)
    page.evaluate("""(lvl) => {
        const sel = Array.from(document.querySelectorAll('select'))
            .find(s => Array.from(s.options).some(o => o.text.trim() === 'Easy'));
        if (!sel) throw new Error('Level select not found');
        const o = Array.from(sel.options).find(o => o.text.trim() === lvl);
        sel.value = o.value;
        sel.dispatchEvent(new Event('change', {bubbles:true}));
    }""", q["level"])
    filled = False
    for sel in ["#QuestionMark", "input[placeholder*='Mark']", "input[name*='Mark']"]:
        try:
            page.fill(sel, str(q["mark"]), timeout=3000)
            filled = True
            break
        except Exception:
            continue
    if not filled:
        raise RuntimeError("Question Mark input not found")
    page.evaluate("""(args) => {
        if (!window.tinymce) throw new Error('TinyMCE not found');
        const h = tinymce.get('questionHeader');
        const q = tinymce.get('questionText');
        if (!h || !q) throw new Error('editors missing');
        h.setContent('<p>' + args.header + '</p>'); h.save();
        q.setContent(args.text); q.save();
    }""", {"header": "choose the correct answer", "text": q["text"] + _image_html(q)})
    for _ in range(3):
        page.evaluate("""() => {
            const btn = Array.from(document.querySelectorAll('button'))
                .find(b => b.innerText.trim() === 'Add Option');
            if (btn) btn.click(); else throw new Error('Add Option not found');
        }""")
        page.wait_for_timeout(400)
    radio_count = page.locator("input[type=radio]").count()
    labeled = page.evaluate("""() => {
        const out = [];
        for (const r of document.querySelectorAll('input[type=radio]')) {
            let el = r, txt = '';
            for (let up = 0; up < 3 && el; up++) {
                el = el.parentElement;
                if (el && el.innerText && el.innerText.trim()) { txt = el.innerText; break; }
            }
            if (/correct/i.test(txt)) out.push(r);
        }
        return out.length;
    }""")
    if labeled != 4:
        raise RuntimeError(
            f"Expected 4 option radios labeled 'Correct', found total={radio_count}, labeled={labeled}")
    page.evaluate("""(opts) => {
        const inputs = Array.from(document.querySelectorAll('input[type=text]'))
            .filter(i => (i.placeholder || '').trim() === 'Text');
        if (inputs.length < 4) throw new Error('Option inputs found: ' + inputs.length);
        for (let i = 0; i < 4; i++) {
            inputs[i].value = opts[i];
            inputs[i].dispatchEvent(new Event('input', {bubbles:true}));
        }
    }""", q["options"])
    page.evaluate("""(correct) => {
        const labeled = [];
        for (const r of document.querySelectorAll('input[type=radio]')) {
            let el = r, txt = '';
            for (let up = 0; up < 3 && el; up++) {
                el = el.parentElement;
                if (el && el.innerText && el.innerText.trim()) { txt = el.innerText; break; }
            }
            if (/correct/i.test(txt)) labeled.push(r);
        }
        if (labeled.length < 4) throw new Error('labeled radios: ' + labeled.length);
        labeled[correct].click();
    }""", q["correct"])
    page.evaluate("""() => {
        const btn = Array.from(document.querySelectorAll('button'))
            .find(b => b.innerText.trim() === 'Save Question');
        if (btn) btn.click(); else throw new Error('Save Question not found');
    }""")
    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(2000)

def apply_status_and_assign(page, exam_id):
    page.goto(f"{BASE_URL}/Assessments/Exams/Details?Id={exam_id}",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#btnAssignClass", timeout=15000)
    page.evaluate("""() => {
        const want_on  = ['btnChangeStatus','btnDisplayResult','btnShuffleQuestions',
                          'btnShuffleAnswers','btnAllowPractice'];
        const want_off = ['btnForceMobile','btnCanEditQuestion','btn-public-for-other-teachers'];
        for (const id of want_on)  { const el = document.getElementById(id);
                                     if (el && el.checked === false) el.click(); }
        for (const id of want_off) { const el = document.getElementById(id);
                                     if (el && el.checked === true)  el.click(); }
    }""")
    page.wait_for_timeout(1500)
    page.evaluate("""() => {
        const r = document.getElementById('allStudentsRadioBtn'); if (r) r.click();
        const sel = document.getElementById('ClassId');
        if (sel) { for (const o of sel.options) o.selected = true;
                   sel.dispatchEvent(new Event('change', {bubbles:true})); }
        const btn = document.getElementById('btnAssignClass');
        if (btn) { btn.disabled = false; btn.click(); }
    }""")
    page.wait_for_timeout(4000)
    toasts = page.evaluate("""() => Array.from(document.querySelectorAll('.toast, .swal2-popup'))
        .map(t => t.innerText.trim())
        .filter(t => /assign|success|saved/i.test(t)).length""")
    return toasts > 0

def verify_exam(page, exam_id, expected_count, expected_total):
    """FIX: original used loose `("5" in body)` check. Now uses regex.
    v6.2: the details page now labels the counters "Total Questions" / "Total Mark"
    (verified live); accept both the old "Questions Count" and the new wording."""
    page.goto(f"{BASE_URL}/Assessments/Exams/Details?Id={exam_id}",
              wait_until="domcontentloaded")
    page.wait_for_timeout(2000)
    body = page.inner_text("body")
    qm = (re.search(r"questions?\s*(?:count)?\s*[:|]\s*(\d+)", body, re.I)
          or re.search(r"total\s+questions\s*[:| ]*\s*(\d+)", body, re.I))
    tm = re.search(r"total\s*mark\s*[:| ]*\s*(\d+(?:\.\d+)?)", body, re.I)
    q_ok = qm and int(qm.group(1)) == expected_count
    t_ok = tm and abs(float(tm.group(1)) - expected_total) < 0.01
    return bool(q_ok and t_ok), qm, tm

def upload_homework_sheet(page, exam_id, sheet_path):
    """v6.4 (homework): attach the questions-sheet file to a Homework-type exam.
    The upload box lives on the details page for this LMS layout, but the probe
    never hard-fails: if nothing is found we print clear manual steps instead."""
    if not sheet_path:
        print("  sheet: no sheet file in the spec — the homework was created "
              "without a sheet; attach the file manually from the platform.")
        return False
    f = Path(sheet_path)
    if not f.exists():
        print(f"  sheet: file not found ({sheet_path}) — attach it manually.")
        return False
    page.goto(f"{BASE_URL}/Assessments/Exams/Details?Id={exam_id}",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_timeout(2500)
    inputs = page.locator("input[type='file']")
    n = inputs.count()
    if not n:
        print("  sheet: the homework page shows no upload box on this account — "
              "attach the sheet manually from the platform, and send the app "
              "developer a screenshot of that page (Details Id=" + exam_id + ") "
              "so this step can be automated too.")
        return False
    for i in range(n):
        try:
            inputs.nth(i).set_input_files(str(f), timeout=120000)
            print(f"  sheet: attached through file input #{i + 1}")
            page.wait_for_timeout(4000)
            try:
                page.wait_for_load_state("networkidle", timeout=30000)
            except Exception:
                pass
            try:
                body = page.inner_text("body").casefold()
                if any(w in body for w in ("success", "uploaded", "attached")):
                    print("  sheet: the platform confirmed the upload.")
            except Exception:
                pass
            return True
        except Exception as e:
            print(f"  sheet: file input #{i + 1} rejected the file ({e})")
    print("  sheet: could not attach the file — attach it manually from the platform.")
    return False


def _alk_ai_sheet(spec):
    """ALKIFAH-FIX-CONVENTIONS: no sheet chosen for a homework? The AI makes one from
    the questions already in this spec, so the teacher never builds a sheet by hand."""
    import subprocess
    import tempfile
    try:
        qs = spec.get("questions") or []
        if not qs:
            print("  sheet: this spec has no questions yet, so there is nothing to print.")
            return ""
        here = Path(__file__).resolve().parent
        maker = here.parent / "app" / "homework_maker.py"
        if not maker.exists():
            print("  sheet: homework_maker.py is missing - run INSTALL_FIXES.bat once.")
            return ""
        qf = Path(tempfile.gettempdir()) / "alkifah_homework_questions.json"
        qf.write_text(json.dumps(qs, ensure_ascii=False), encoding="utf-8")
        title = str(spec.get("title") or "Homework").strip() or "Homework"
        out_dir = Path(spec.get("homework_dir") or (here.parent / "First Term" / "Homework"))
        out_dir.mkdir(parents=True, exist_ok=True)
        cmd = [sys.executable, str(maker), "--from-json", str(qf), "--no-lesson",
               "--title", title, "--out", str(out_dir),
               "--lang", str(spec.get("lang") or "en")]
        print("  sheet: making it with the local AI now (no download, no cost)...")
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        for line in (r.stdout or "").splitlines():
            if "student sheet" in line and ":" in line:
                found = line.split(":", 1)[1].strip().strip('"')
                if found and Path(found).exists():
                    return found
        made = sorted(out_dir.glob("* - Homework.pdf"), key=lambda q: q.stat().st_mtime)
        if made:
            return str(made[-1])
        print("  sheet: the maker returned no file (%s)"
              % ((r.stderr or r.stdout or "")[-200:]))
    except Exception as e:
        print("  sheet: could not make one automatically (%s) - attach it by hand if you want." % e)
    return ""


def main():
    spec = json.loads(Path(ARGS.spec).read_text(encoding="utf-8"))
    title = str(spec.get("title") or "").strip()
    want = generated_title(spec, ARGS.spec)        # ALKIFAH-FIX-12: one unified name
    if want and want != title:
        print(("  title: unified with the lesson's name -> " if title
               else "  title: the lesson's name -> ") + want)
        title = want
        spec["title"] = want
    try:
        _alk_run_log(["RUN '%s'  spec=%s" % (title or "(no title)", ARGS.spec)])
    except Exception:
        pass
    duration = spec.get("duration", 10)
    # v6.2: the LMS now rejects durations of 10 minutes or less
    # ("Exam Duration must be greater than 10" — verified live on 2026-09-17).
    if duration <= 10:
        print(f"  NOTE: duration {duration} is rejected by the LMS (must be > 10) — "
              f"bumping it to 15 minutes.")
        duration = 15
    exam_type = spec.get("type", "Quiz")
    questions = spec.get("questions") or []
    sheet = str(spec.get("sheet_path", "") or "").strip()
    is_homework = str(exam_type).strip().casefold() == "homework"
    if is_homework and not sheet and not ARGS.resume:   # ALKIFAH-FIX-CONVENTIONS
        sheet = _alk_ai_sheet(spec)
        if sheet:
            spec["sheet_path"] = sheet
    print(f"Spec loaded: {title}")
    if is_homework:
        print(f"  Type: Homework — a sheet file is uploaded instead of typed questions")
        print(f"  Sheet: {sheet if sheet else '(not chosen — attach it manually later)'}")
    else:
        print(f"  Duration: {duration} min, Type: {exam_type}, Questions: {len(questions)}")
    if ARGS.dry_run:
        print("\n--dry-run: not touching the LMS. Plan:")
        if is_homework:
            print(f"  1) create the exam on /Assessments/Exams/Create with type={exam_type}")
            print(f"  2) attach the sheet: {sheet if sheet else '(none)'}")
            print("  3) turn the statuses on and assign it to the classes")
        else:
            for i, q in enumerate(questions, 1):
                img = " + image" if q.get("image_path") else ""
                print(f"  Q{i} [{q['level']}]{img} {q['text'][:70]}...")
        return
    log = load_log()
    if title in log and not ARGS.resume:
        print(f"SKIPPED — '{title}' already exists in the log.")
        return
    # login details are checked before the browser starts
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=not ARGS.show)
        context = browser.new_context(locale="en-US")
        page = context.new_page()
        login(page)
        try:                                         # ALKIFAH-FIX-12: popups on arrival
            _closed = _alk_dismiss_popups(page)
            if _closed:
                print("  closed the platform's popup on arrival: " + ", ".join(_closed))
        except Exception:
            pass
        if ARGS.resume:
            print(f"Resuming exam {ARGS.resume}: {title}")
            page.goto(f"{BASE_URL}/Assessments/ExamsQuestions/Index/{ARGS.resume}",
                      wait_until="domcontentloaded", timeout=60000)
            link = page.evaluate("""() => {
                const a = Array.from(document.querySelectorAll('a'))
                    .map(x => x.getAttribute('href') || '')
                    .find(h => h.includes('CreateMultiple'));
                return a || null;
            }""")
            if not link:
                sys.exit("Could not find the CreateMultiple link on the questions page.")
            course_guid = re.search(r"CourseId=([A-Za-z0-9\-]+)", link).group(1)
            exam_id = ARGS.resume
        else:
            print(f"Creating exam: {title}")
            exam_id, course_guid = create_exam(page, title, duration, exam_type)
        print(f"  exam id: {exam_id}")
        sheet_ok = None
        if is_homework:
            sheet_ok = upload_homework_sheet(page, exam_id, sheet)
        failed_questions = []
        if not is_homework:
            page._cm_url = (f"{BASE_URL}/Assessments/ExamsQuestions/"
                            f"CreateMultiple/{exam_id}?CourseId={course_guid}")
            for i, q in enumerate(questions, 1):
                print(f"  adding question {i}/{len(questions)} ...", flush=True)
                ok = False
                for attempt in range(1, QUESTION_RETRIES + 1):
                    try:
                        add_mcq(page, q, i)
                        ok = True
                        break
                    except Exception as e:
                        print(f"    attempt {attempt} failed: {e}")
                        if attempt < QUESTION_RETRIES:
                            try:
                                page.goto(BASE_URL, wait_until="domcontentloaded")
                            except Exception:
                                pass
                if not ok:
                    failed_questions.append(i)
                    print(f"    !! question {i} FAILED after {QUESTION_RETRIES} attempts — continuing")
        if is_homework:
            verified, qm, tm = True, None, None
        else:
            verified, qm, tm = verify_exam(page, exam_id, expected_count=len(questions),
                                            expected_total=sum(q["mark"] for q in questions))
        print(f"  verify: questions={qm.group(1) if qm else '?'} total={tm.group(1) if tm else '?'} ok={verified}")
        assign_ok = False
        try:
            assign_ok = apply_status_and_assign(page, exam_id)
        except Exception as e:
            print(f"  assignment step failed: {e}")
        details_url = f"{BASE_URL}/Assessments/Exams/Details?Id={exam_id}"
        browser.close()
    log[title] = {
        "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "exam_url": details_url,
        "type": exam_type,
        "sheet_attached": sheet_ok if is_homework else None,
        "verified": verified,
        "assigned": assign_ok,
        "failed_questions": failed_questions,
        "questions": [q["text"] for q in questions],
    }
    save_log(log)
    extra = f"  sheet_attached={sheet_ok}" if is_homework else ""
    try:
        _alk_run_log(["DONE '%s' verified=%s assigned=%s url=%s"
                      % (title, verified, assign_ok, details_url)])
    except Exception:
        pass
    print(f"DONE — {title}  verified={verified}  assigned={assign_ok}{extra}  url={details_url}")
    if failed_questions:
        print(f"WARNING: {len(failed_questions)} question(s) failed: {failed_questions}.")
        print("         Re-run with --resume " + exam_id + " to retry just those.")
    if not verified:
        print("WARNING: could not confirm count/mark on the details page — check manually.")

if __name__ == "__main__":
    main()
