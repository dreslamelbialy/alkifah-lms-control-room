"""
Alkifah LMS — Auto Material Uploader (v6, PDF-only edition)
================================================================
v6 change (pack rule): lesson materials are PowerPoint files but they must reach the
LMS as PDF. Every .ppt/.pptx is converted to PDF with PowerPoint and the PDF is what
gets attached to Materials/Create. If the conversion fails the lesson is SKIPPED, never
uploaded as a raw PowerPoint. Lesson materials and booklet PDFs both end up in the same
LMS place: Course Management -> Materials.
================================================================
Fixes over the original v4:
  * Credentials / paths read from environment variables first, then SETTINGS.
  * Removed the duplicated PREVIOUSLY_UPLOADED list — single source of truth
    is uploaded_log.json (loaded by load_log).
  * `--show` flag forces a visible browser for local debugging.
  * `--no-pdf` uploads the .pptx as-is (no PowerPoint conversion).
  * `--limit N` only uploads the first N new items.
  * `convert_to_pdf` no longer falls back to opening PowerPoint with a
    visible window in headless mode (the original silently showed a window).
  * Clearer error message when PowerPoint can't open a file, with the
    exact COM HRESULT so you know whether to retry or skip.
  * Login uses fill_first() against #Input_Password (the original v4 did
    this correctly; we keep it).
  * Numbered-pagination fallback in check_repetition (not just "Next" link).

Usage:
    python upload_materials.py            (asks before uploading, visible browser)
    python upload_materials.py auto       (uploads everything new, headless)
    python upload_materials.py auto --show      (auto upload, visible browser)
    python upload_materials.py auto --limit 2   (auto upload, only first 2 new)
    python upload_materials.py auto --no-pdf    (skip PPT->PDF conversion)

Env vars (override SETTINGS block):
    LMS_USERNAME, LMS_PASSWORD, LMS_FOLDER, LMS_COURSE, LMS_CLASSES
"""

# v6.9: force UTF-8 output on Windows (Arabic in the app terminal)
import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass


import os, re, sys, json, time, zipfile, argparse
from pathlib import Path
from datetime import datetime, timedelta
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

## ============ SETTINGS — EDIT ONLY THESE LINES ============
FOLDER   = r"D:\Alkifah academy\2026-2027\First Term"
COURSE   = "Science 3 - Grade 9"
CLASSES  = "ALL"      # "ALL" or "G9A|G9B|G9C"
USERNAME = os.environ.get("LMS_USERNAME", "")
PASSWORD = os.environ.get("LMS_PASSWORD", "")
MINUTES_AHEAD = 5     # publish time = now + N minutes (LMS_MINUTES_AHEAD overrides)
RETRIES  = 2
UPLOAD_AS_PDF = True     # PowerPoint -> PDF before attaching (pack rule)
PDF_ONLY      = True     # if the conversion fails: SKIP, never upload the .pptx
MAX_MB   = 25
## ==========================================================

## Env-var overrides (handy on localhost: keep secrets out of the script)
FOLDER   = os.environ.get("LMS_FOLDER",   FOLDER)
COURSE   = os.environ.get("LMS_COURSE",   COURSE)
CLASSES  = os.environ.get("LMS_CLASSES",  CLASSES)
USERNAME = os.environ.get("LMS_USERNAME", USERNAME)
PASSWORD = os.environ.get("LMS_PASSWORD", PASSWORD)
_env_minutes = os.environ.get("LMS_MINUTES_AHEAD", "").strip()
if _env_minutes.isdigit():
    MINUTES_AHEAD = int(_env_minutes)

BASE_URL = "https://lms.alkifah.edu.sa"
SCRIPT_DIR  = Path(__file__).resolve().parent
LOG_PATH    = SCRIPT_DIR / "uploaded_log.json"
REPORT_PATH = SCRIPT_DIR / "upload_report.txt"
STATE = {"materials_url": None, "create_url": None}
_pp_app = None

## ---------- CLI ----------
def parse_args():
    p = argparse.ArgumentParser(description="Alkifah LMS Auto Material Uploader")
    p.add_argument("mode", nargs="?", default="manual",
                   help="auto | manual (default). 'auto' = headless, no prompts.")
    p.add_argument("--show", action="store_true",
                   help="Force a visible browser even in auto mode.")
    p.add_argument("--no-verify", action="store_true",
                   help="skip the look at the platform that repairs the "
                        "'already uploaded' memory after a deletion (LMS_MEMORY_CHECK=0 "
                        "does the same)")
    p.add_argument("--no-pdf", action="store_true",
                   help="Emergency only: upload the .pptx as-is (pack rule is PDF-only).")
    p.add_argument("--limit", type=int, default=0,
                   help="Upload at most N new items (0 = no limit).")
    p.add_argument("--only", action="append", default=[],
                   help="Upload only these files. Repeat the flag or separate "
                        "entries with commas. Matches the title or the file name.")
    return p.parse_args()

ARGS = parse_args()
AUTO = ARGS.mode.lower() == "auto"
HEADLESS = AUTO and not ARGS.show
UPLOAD_AS_PDF = UPLOAD_AS_PDF and not ARGS.no_pdf
if ARGS.no_pdf and PDF_ONLY:
    print("WARNING: --no-pdf uploads the PowerPoint file itself. The pack rule is "
          "PDF-only — use it only if PowerPoint is broken on this laptop.")

## ---------- memory of uploaded lessons ----------
def load_log():
    """Load uploaded_log.json. Returns {} if missing/corrupt."""
    if LOG_PATH.exists():
        try:
            return json.loads(LOG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_log(log):
    LOG_PATH.write_text(json.dumps(log, indent=2, ensure_ascii=False),
                        encoding="utf-8")

def settle(page, timeout_ms=8000):
    """v6.6: BOUNDED network settle.

    The old code called wait_for_load_state("networkidle") with Playwright's
    default 30s timeout. On a chatty LMS page (analytics, signalR, pollers) the
    network is NEVER idle, so every login / attach / save silently burned up to
    30s doing nothing — that was the mysterious 'the file uploaded fast but then
    it just sits there' slowness. 6-8s is plenty on school Wi-Fi."""
    try:
        page.wait_for_load_state("networkidle", timeout=timeout_ms)
    except Exception:
        pass

def title_on_lms(page, title, max_pages=6):
    """v6.6: is this title already in the LMS Materials list?

    Used after a save that did not confirm cleanly: the LMS may have accepted
    the material even when the page did not show it. Checking BEFORE retrying
    prevents duplicate uploads and the multi-minute retry loops."""
    try:
        page.goto(f"{BASE_URL}/CourseManagement/Materials",
                  wait_until="domcontentloaded", timeout=30000)
        page.wait_for_selector("table", timeout=10000)
        for _ in range(max_pages):
            page_titles = page.evaluate("""() => {
                const t = document.querySelector('table');
                if (!t) return [];
                return Array.from(t.querySelectorAll('tbody tr')).map(r => {
                    const c = r.querySelectorAll('td');
                    return c.length > 1 ? c[1].innerText.replace(/\\s+/g, ' ').trim() : '';
                }).filter(Boolean);
            }""")
            if title in page_titles:
                return True
            clicked = page.evaluate("""() => {
                const next = Array.from(document.querySelectorAll('a'))
                    .find(a => a.innerText.trim().toLowerCase() === 'next');
                if (next && !next.closest('li').classList.contains('disabled')) {
                    next.click(); return true;
                }
                const active = document.querySelector('.pagination .active');
                if (active) {
                    let el = active.nextElementSibling;
                    if (el) { const a = el.querySelector('a') || el; a.click(); return true; }
                }
                return false;
            }""")
            if not clicked:
                return False
            page.wait_for_load_state("domcontentloaded")
            page.wait_for_timeout(600)
    except Exception:
        return False
    return False

## ---------- find the PowerPoint files ----------
def _num(name):
    m = re.search(r"(\d+)", name)
    return int(m.group(1)) if m else None

def session_number(name):
    """Session folder names come in several shapes in real term folders:
    '01', 'Session 01', 'S 3', 'session-2'. They all mean the same thing."""
    m = re.match(r"^\s*(?:session|s)?[\s\-_.]*(\d{1,2})\s*$", name, re.I)
    if m:
        return int(m.group(1))
    m = re.match(r"^\s*(?:session|s)[\s\-_.]*(\d{1,2})\b", name, re.I)
    return int(m.group(1)) if m else None

def extract_zips(week_dir):
    for z in week_dir.rglob("*.zip"):
        if z.name.startswith("~$"):
            continue
        target = z.parent / ("extracted_" + z.stem)
        if target.exists():
            continue
        try:
            with zipfile.ZipFile(z) as zf:
                zf.extractall(target)
            print(f"     (unzipped {z.name})")
        except Exception as e:
            print(f"     (could not unzip {z.name}: {e})")

def find_ppts(folder):
    found = {}
    for p in folder.rglob("*"):
        try:
            if p.suffix.lower() in (".pptx", ".ppt") and not p.name.startswith("~$"):
                found[(p.name.lower(), p.stat().st_size)] = p
        except OSError:
            pass
    return sorted(found.values(), key=lambda p: str(p).lower())

def session_no(week_dir, ppt_path):
    rel = ppt_path.relative_to(week_dir)
    for part in reversed(rel.parts[:-1]):
        name = part[9:] if part.startswith("extracted_") else part
        n = session_number(name)
        if n is not None:
            return n
    n = session_number(rel.parts[-1])
    return n if n is not None else (_num(rel.parts[-1]) or 0)

def find_materials(root):
    root = Path(root)
    if not root.exists():
        sys.exit(f"Cannot find the folder: {root}\nSet LMS_FOLDER or edit FOLDER in the script.")
    items, seen = [], set()
    week_dirs = sorted([d for d in root.glob("Week*") if d.is_dir()],
                       key=lambda d: _num(d.name) or 0)
    for week_dir in week_dirs:
        w = _num(week_dir.name) or 0
        extract_zips(week_dir)
        for sd in week_dir.iterdir():
            if sd.is_dir() and session_number(sd.name) is not None:
                s = session_number(sd.name)
                for ppt in find_ppts(sd):
                    if str(ppt) not in seen:
                        seen.add(str(ppt))
                        items.append({"week": w, "session": s, "path": str(ppt)})
        for ppt in find_ppts(week_dir):          # PPTs not inside session folders
            if str(ppt) not in seen:
                seen.add(str(ppt))
                items.append({"week": w, "session": session_no(week_dir, ppt),
                              "path": str(ppt)})
    items.sort(key=lambda x: (x["week"], x["session"], x["path"].lower()))
    out, titles = [], {}
    for it in items:
        stem = Path(it["path"]).stem
        t = (f"Week {it['week']} - Session {it['session']:02d} - {stem}"
             if it["session"] else f"Week {it['week']} - {stem}")
        if t in titles:                          # same name twice -> keep both
            titles[t] += 1
            t = f"{t} ({titles[t]})"
        else:
            titles[t] = 1
        it["title"] = t
        out.append(it)
    return out

## ---------- PPT to PDF ----------
def get_powerpoint():
    """Start Microsoft PowerPoint (COM). Stops the run with a plain-language message
    when this laptop cannot do the PPT -> PDF step at all (v6.1 wording)."""
    global _pp_app
    if _pp_app is None:
        try:
            import comtypes.client
        except ImportError:
            sys.exit(
                "\nThis laptop cannot turn the PowerPoint files into PDF because Microsoft "
                "PowerPoint automation is not available (the 'comtypes' tool is missing).\n"
                "Fix: install Microsoft Office (with PowerPoint) on this PC, then run the "
                "task again.\nThe run has stopped - nothing was uploaded.\n")
        try:
            _pp_app = comtypes.client.CreateObject("PowerPoint.Application")
        except Exception:
            sys.exit(
                "\nMicrosoft PowerPoint is installed but it did not start.\n"
                "Fix: open PowerPoint once by hand, close it, then run the task again.\n"
                "The run has stopped - nothing was uploaded.\n")
    return _pp_app

def quit_powerpoint():
    global _pp_app
    if _pp_app is not None:
        try:
            _pp_app.Quit()
        except Exception:
            pass
        _pp_app = None

def unblock_file(path):
    """Remove the Windows "downloaded from the internet" mark (Zone.Identifier).

    This is the most common reason for 'PowerPoint could not open the file' when the
    .pptx came from email, WhatsApp, OneDrive or a USB stick.
    """
    removed = False
    for suffix in (":Zone.Identifier", ":Zone.Identifier:$DATA"):
        try:
            os.remove(str(path) + suffix)
            removed = True
        except Exception:
            continue
    return removed


def is_office_file(path):
    """A .pptx/.ppt is a zip container; anything else PowerPoint cannot open."""
    try:
        with open(path, "rb") as fh:
            return fh.read(2) == b"PK"
    except OSError:
        return False


def _convert_with_powerpoint(pp, src, dst):
    """Try the known Open() variants. Returns None on success, else the last error."""
    variants = [dict(ReadOnly=True, WithWindow=False),
                dict(ReadOnly=True, WithWindow=False, Untitled=False),
                dict(ReadOnly=True),
                dict(ReadOnly=True, WithWindow=True)]
    last = None
    for kwargs in variants:
        pres = None
        try:
            pres = pp.Presentations.Open(str(src), **kwargs)
            try:
                pres.SaveAs(str(dst), 32)          # 32 = PDF
            finally:
                pres.Close()
            return None
        except Exception as e:
            last = e
            if pres is not None:
                try:
                    pres.Close()
                except Exception:
                    pass
    return last

def convert_to_pdf(pptx_path):
    """Convert .pptx -> .pdf with Microsoft PowerPoint (v6.1 hardening).

    Real runs failed with "HRESULT: -2147467259 'PowerPoint could not open the file'".
    Before giving up we now:
      * refuse 0-byte and non-Office files with a plain message,
      * remove the Windows "mark of the web" (files from email/USB/OneDrive),
      * try more Open() variants,
      * and, if the original path keeps failing, convert from a temporary copy with a
        short simple name (long or non-English paths break PowerPoint COM).
    Only if all of that fails is the lesson skipped - it is never uploaded as a .pptx.
    """
    p = Path(pptx_path)
    pdf_path = p.with_suffix(".pdf")
    if pdf_path.exists() and pdf_path.stat().st_mtime >= p.stat().st_mtime:
        return str(pdf_path)
    if p.stat().st_size == 0:
        raise RuntimeError(f"'{p.name}' is empty (0 bytes) - copy the file again.")
    if not is_office_file(p):
        raise RuntimeError(f"'{p.name}' is not a valid PowerPoint file (not an Office zip) "
                           f"- open it once in PowerPoint and save it again.")
    if unblock_file(p):
        print(f"     (removed the Windows internet block from '{p.name}')")

    pp = get_powerpoint()
    err = _convert_with_powerpoint(pp, p, pdf_path)
    if err is None and pdf_path.exists():
        return str(pdf_path)

    try:
        import tempfile
        import shutil
        tmp_dir = Path(tempfile.gettempdir()) / "lms_convert"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        safe = re.sub(r"[^A-Za-z0-9]+", "_", p.stem).strip("_")[:40] or "lesson"
        tmp_src = tmp_dir / (safe + p.suffix.lower())
        shutil.copy2(p, tmp_src)
        unblock_file(tmp_src)
        tmp_pdf = tmp_src.with_suffix(".pdf")
        err2 = _convert_with_powerpoint(pp, tmp_src, tmp_pdf)
        if err2 is None and tmp_pdf.exists():
            shutil.copy2(tmp_pdf, pdf_path)
            print("     (converted from a temporary copy - the original path was the problem)")
            return str(pdf_path)
        err = err2 or err
    except Exception as e:
        err = err or e

    raise RuntimeError(
        f"PowerPoint could not open '{p.name}' ({err}). Usual causes: the file is already "
        f"open in PowerPoint, it is damaged, or it is blocked. Close PowerPoint and try "
        f"again; if it still fails, open the file once by hand (allow editing) and save it "
        f"as a new .pptx, then re-run - the lesson stays skipped until it converts.")

## ---------- page helpers ----------
def fill_first(page, selectors, value):
    for sel in selectors:
        try:
            page.wait_for_selector(sel, timeout=4000)
            page.fill(sel, value)
            return True
        except Exception:
            continue
    return False

def click_first(page, selectors, timeout=6000):
    for sel in selectors:
        try:
            page.click(sel, timeout=timeout)
            return True
        except Exception:
            continue
    return False

def select2_single(page, select_id, label):
    res = page.evaluate("""([sid, lbl]) => {
        const el = document.getElementById(sid);
        const opts = [];
        let found = false;
        const base = lbl.split(' - ')[0].trim().toLowerCase();
        for (const o of el.options) {
            const t = o.text.trim();
            opts.push(t);
            if (t === lbl) { el.value = o.value; found = true; }
        }
        if (!found) {
            for (const o of el.options) {
                const t = o.text.trim();
                if (o.value && t.split(' - ')[0].trim().toLowerCase() === base) {
                    el.value = o.value; found = true; break;
                }
            }
        }
        if (found) el.dispatchEvent(new Event('change', {bubbles:true}));
        return {found: found, options: opts};
    }""", [select_id, label])
    if not res["found"]:
        raise ValueError(f"Course '{label}' not found. Courses: {res['options']}")

def wait_for_classes_loaded(page, timeout_ms=20000):
    """v6.2: the Classes dropdown (#classesSelectList) is EMPTY and DISABLED until the
    course selection triggers an AJAX load (verified live on the LMS: G9A/G9B/G9C only
    appear after CourseId fires 'change'). Selecting too early silently saved materials
    with NO classes. This waits until the list is enabled and populated."""
    try:
        page.wait_for_function(
            """() => { const el = document.getElementById('classesSelectList');
                       return el && !el.disabled && el.options.length > 0; }""",
            timeout=timeout_ms)
        return True
    except Exception:
        return False

def select2_multi_all(page, select_id):
    page.evaluate("""(sid) => {
        const el = document.getElementById(sid);
        for (const o of el.options) o.selected = true;
        el.dispatchEvent(new Event('change', {bubbles:true}));
    }""", select_id)
    chosen = page.evaluate(
        """(sid) => document.getElementById(sid)
              ? document.getElementById(sid).selectedOptions.length : 0""", select_id)
    if not chosen:
        raise RuntimeError(
            f"No classes could be selected in #{select_id} — the list was empty. "
            f"The material would be invisible to students, so the upload was stopped. "
            f"(v6.2 safety guard)")

def select2_multi_list(page, select_id, labels):
    page.evaluate("""([sid, lbls]) => {
        const el = document.getElementById(sid);
        const want = new Set(lbls.map(s => s.trim()));
        for (const o of el.options) o.selected = want.has(o.text.trim());
        el.dispatchEvent(new Event('change', {bubbles:true}));
    }""", [select_id, labels])

def set_publish_date(page, minutes=None):
    """Set Publish Date = now + MINUTES_AHEAD (default 5 minutes).

    v6.6: ONE fast JavaScript pass instead of the old five sequential
    fill() attempts (each burning up to 4s when a selector missed). The JS
    writes the value into every publish-ish input + every datetime-local field,
    fires input/change/blur, then we read the value back to verify.
    Typical cost now: well under a second.
    """
    minutes = MINUTES_AHEAD if minutes is None else minutes
    value = (datetime.now() + timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M")

    # fast path: the known field id (1.5s cap — it is a plain datetime-local)
    try:
        page.fill("#PublishDate", value, timeout=1500)
    except Exception:
        pass

    found = page.evaluate("""(v) => {
        const els = Array.from(document.querySelectorAll('input')).filter(i =>
            /publish/i.test((i.id||'') + (i.name||'') + (i.placeholder||'')) ||
            i.type === 'datetime-local');
        for (const el of els) {
            el.value = v;
            el.dispatchEvent(new Event('input',  {bubbles:true}));
            el.dispatchEvent(new Event('change', {bubbles:true}));
            el.dispatchEvent(new Event('blur',   {bubbles:true}));
        }
        return els.length;
    }""", value)

    got = page.evaluate("""() => {
        const el = Array.from(document.querySelectorAll('input'))
            .find(i => /publish/i.test((i.id||'') + (i.name||'') + (i.placeholder||'')));
        return el ? el.value : '';
    }""")
    if got:
        print(f"     (publish date: {got} - {minutes} minute(s) from now)")
    else:
        print(f"     (warning: could not fill the Publish Date automatically "
              f"[{found} field(s) found]. Type it by hand in the browser window if the "
              f"Save button stays grey.)")
    return value

def _file_input_selectors():
    """Every place the LMS has been seen to keep the hidden <input type=file>."""
    return ["#MaterialDropZoneCreate input[type='file']",
            "input[type='file'][name*='ttachment']",
            "input[type='file'][name*='ile']",
            "#MaterialDropZoneCreate input",
            "input[type='file']"]


def attach_file(page, path):
    """Attach a file to the "Drop files here or click to upload" box.

    v6.1: the original code knew only two ways of finding the upload box and stopped with
    "Timeout 30000ms exceeded" when the layout did not match. It now:
      1. waits for the dropzone script to build itself,
      2. sets the hidden <input type=file> directly (Playwright can fill hidden inputs),
      3. otherwise clicks the dropzone / its text and uses the file chooser,
      4. warns instead of failing when the page does not confirm the upload by itself.
    """
    name = os.path.basename(path)

    # v6.6: one combined wait instead of 4 sequential 15s waits (60s worst case
    # became 10s worst case — the dropzone is always one of these).
    try:
        page.wait_for_selector(
            "#MaterialDropZoneCreate, .dropzone, input[type='file']",
            timeout=10000)
    except PWTimeout:
        pass
    page.wait_for_timeout(800)

    sent = False
    last_err = None
    for sel in _file_input_selectors():
        try:
            loc = page.locator(sel).first
            if loc.count():
                loc.set_input_files(path, timeout=30000)
                sent = True
                print(f"     (attached through {sel})")
                break
        except Exception as e:
            last_err = e
            continue

    if not sent:
        for sel in ["#MaterialDropZoneCreate .dropzone-select",
                    "#MaterialDropZoneCreate .dz-clickable",
                    "#MaterialDropZoneCreate",
                    ".dropzone-select", ".dz-clickable",
                    "text=Drop files here or click to upload"]:
            try:
                with page.expect_file_chooser(timeout=8000) as fc:
                    page.click(sel, timeout=8000)
                fc.value.set_files(path)
                sent = True
                print(f"     (attached by clicking {sel})")
                break
            except Exception as e:
                last_err = e
                continue

    if not sent:
        raise RuntimeError(
            "could not find the upload box ('Drop files here or click to upload') on the "
            f"Materials/Create page ({last_err}). If the page looks different, send a "
            "screenshot of it to your admin.")

    confirmed = False
    for sel in [f'.dropzone-item.dz-complete:has(span[data-dz-name]:text-is("{name}"))',
                ".dropzone-item.dz-complete", ".dz-complete", ".dz-success"]:
        try:
            # v6.4: 5 minutes (was 3) — big files on slow school Wi-Fi
            page.wait_for_selector(sel, timeout=300000)
            confirmed = True
            break
        except PWTimeout:
            continue
    if not confirmed:
        try:
            confirmed = name in page.inner_text("body")
        except Exception:
            confirmed = False
    settle(page)                      # v6.6: bounded (was up to 30s of silence)
    if not confirmed:
        raise RuntimeError(
            f"'{name}' was sent but the page never showed it - the LMS did not accept the "
            f"file (check the size, 25 MB maximum).")

def _shot(page, kind, title):
    safe = re.sub(r"[^\w\-]+", "_", title)[:40]
    try:
        page.screenshot(path=str(SCRIPT_DIR / f"{kind}_{safe}.png"), full_page=True)
    except Exception:
        pass

## ---------- steps ----------
def login(page):
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    last_err = None
    for attempt in range(2):
        try:
            page.goto(f"{BASE_URL}/Identity/Account/LogIn",
                      wait_until="domcontentloaded", timeout=60000)
            last_err = None
            break
        except Exception as e:
            last_err = e
            print("   (login page load timed out — trying again...)")
    if last_err:
        sys.exit(f"Could not open the LMS login page: {last_err}")
    page.wait_for_selector("#Input_Email", timeout=10000)
    settle(page, 6000)                # v6.6: bounded
    if not fill_first(page, ["input[name='Input.Email']", "#Input_Email",
                             "input[name='Email']", "input[type='email']"], USERNAME):
        sys.exit("Could not find the email box on the login page.")
    # v6.2: the LMS login page currently uses id="passwordInput" for the password box
    # (name="Input.Password"). The name-based selector still matches first; the ID
    # fallbacks cover both the old (#Input_Password) and current (#passwordInput) layouts.
    if not fill_first(page, ["input[name='Input.Password']", "#passwordInput",
                             "#Input_Password", "input[type='password']"], PASSWORD):
        sys.exit("Could not find the password box on the login page.")
    click_first(page, ["button[type='submit']", "button:has-text('Log in')",
                       "input[type='submit']"])
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=15000)
    except PWTimeout:
        sys.exit("Login failed — check email/password in the SETTINGS.")
    settle(page)                      # v6.6: bounded

def check_repetition(page, items, log):
    """DUPLICATE CHECK: read every material title from the LMS Materials
    list (all pages) and mark lessons that are already online.
    FIX: also handles numbered pagination (1,2,3...) in addition to 'Next'.
    """
    page.goto(f"{BASE_URL}/CourseManagement/Materials",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("table", timeout=15000)
    titles = set()
    for _ in range(30):
        page_titles = page.evaluate("""() => {
            const t = document.querySelector('table');
            if (!t) return [];
            return Array.from(t.querySelectorAll('tbody tr')).map(r => {
                const c = r.querySelectorAll('td');
                return c.length > 1 ? c[1].innerText.replace(/\\s+/g, ' ').trim() : '';
            }).filter(Boolean);
        }""")
        titles.update(page_titles)
        clicked = page.evaluate("""() => {
            const next = Array.from(document.querySelectorAll('a'))
                .find(a => a.innerText.trim().toLowerCase() === 'next');
            if (next && !next.closest('li').classList.contains('disabled')) {
                next.click(); return true;
            }
            const active = document.querySelector('.pagination .active');
            if (active) {
                let el = active.nextElementSibling;
                if (el) {
                    const a = el.querySelector('a') || el;
                    a.click(); return true;
                }
            }
            return false;
        }""")
        if not clicked:
            break
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(1500)
    reconciled = 0
    for it in items:
        stem = Path(it["path"]).stem
        if it["title"] not in log and (it["title"] in titles or stem in titles):
            log[it["title"]] = f"already on LMS (reconciled {datetime.now():%Y-%m-%d %H:%M})"
            reconciled += 1
    if reconciled:
        save_log(log)
    return reconciled

def open_create_form(page):
    page.goto(f"{BASE_URL}/CourseManagement/Materials/Create",
              wait_until="domcontentloaded", timeout=60000)
    page.wait_for_selector("#general_form", timeout=15000)

def upload_one(page, path, title):
    open_create_form(page)
    page.fill("#Name", title)
    page.fill("#Description", f"Lesson material — {title}")
    select2_single(page, "CourseId", COURSE)
    if not wait_for_classes_loaded(page):          # v6.2: classes load via AJAX
        print("   (classes list still empty — waiting a little more...)")
        if not wait_for_classes_loaded(page, timeout_ms=15000):
            raise RuntimeError("Classes dropdown never loaded after selecting the "
                               "course (v6.2 guard) — nothing was saved.")
    attach_file(page, path)
    if CLASSES.strip().upper() == "ALL":
        select2_multi_all(page, "classesSelectList")
    else:
        select2_multi_list(page, "classesSelectList",
                           [c.strip() for c in CLASSES.split("|")])
    set_publish_date(page)
    # v6.4: the stale re-fill block that referenced an undefined `publish`
    # variable is gone — it crashed every upload with
    # "name 'publish' is not defined" right after the publish date was set,
    # which retried the whole file and looked like the upload was stuck.
    # set_publish_date() above already fills the field and verifies it.
    try:
        page.wait_for_selector("#saveButton:not([disabled])", timeout=15000)
    except PWTimeout:
        _shot(page, "notready", title)
        raise RuntimeError("Save button never became active (see notready_*.png)")
    page.click("#saveButton")
    # v6.6: poll up to 60s for the form to go away (slow LMS servers) instead of
    # one fixed 30s detach wait, then decide with evidence instead of guessing.
    saved = False
    deadline = time.time() + 60
    while time.time() < deadline:
        try:
            if page.locator("#general_form").count() == 0:
                saved = True
                break
        except Exception:
            saved = True
            break
        try:
            body = page.inner_text("body")
            if "successfully" in body.lower() or "تم " in body or "تمت" in body:
                saved = True
                break
        except Exception:
            pass
        page.wait_for_timeout(500)
    if not saved:
        try:
            if title in page.inner_text("body"):
                return True
        except Exception:
            pass
        msg = ""
        try:
            errs = page.locator(".validation-summary-errors li:visible, "
                                ".field-validation-error:visible")
            if errs.count():
                msg = " | ".join(errs.all_inner_texts()[:3])
        except Exception:
            pass
        _shot(page, "savefailed", title)
        raise RuntimeError(("Site said: " + msg) if msg
                           else "Save did not finish (see savefailed_*.png)")
    settle(page)                      # v6.6: bounded (was up to 30s of silence)
    try:
        return title in page.inner_text("body")
    except Exception:
        return False

## ---------- main ----------
def _alk_memory_repair(items=None):
    # ALKIFAH-FIX-CONVENTIONS: after something is deleted ON THE PLATFORM the app's
    # memory (uploaded_log.json) still says 'uploaded', so the lesson never goes back
    # up. One quiet headless look at the Materials list fixes the memory: a remembered
    # title that is not online anymore is dropped, so the normal upload sends it again
    # under the SAME name - no ' (2)', nothing deleted. --no-verify or
    # LMS_MEMORY_CHECK=0 skips the look, and any problem leaves the log untouched.
    try:
        if ARGS.no_verify or str(os.environ.get("LMS_MEMORY_CHECK") or "1").strip() == "0":
            return 0
    except Exception:
        pass
    log = load_log()
    if not isinstance(log, dict) or not log:
        return 0
    if not USERNAME or not PASSWORD:
        return 0
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app"))
        import alkifah_memory
    except Exception as e:
        print("  [!] the platform memory check could not run (%s) - nothing was changed."
              % type(e).__name__)
        return 0
    if items is not None:
        # only worth a browser when something remembered is also on the shelf - the
        # names are compared loosely, because a renamed file must still be recognised
        try:
            keys = set(alkifah_memory.norm(k) for k in log)
            hit = any(alkifah_memory.norm(it.get("title")) in keys for it in items)
        except Exception:
            hit = any(str(it.get("title")) in log for it in items)
        if not hit:
            return 0
    try:
        dropped, note = alkifah_memory.repair(log, LOG_PATH, BASE_URL, USERNAME, PASSWORD,
                                              login)
    except BaseException as e:
        if isinstance(e, KeyboardInterrupt):
            raise
        print("  [!] the platform memory check could not run (%s) - nothing was changed."
              % (getattr(e, "code", None) or type(e).__name__))
        return 0
    if note:
        print("      " + note)
    if not dropped:
        return 0
    for t in dropped:
        log.pop(t, None)
    save_log(log)
    print("  [OK] memory fixed: %d lesson(s) deleted on the platform go up again under"
          % len(dropped))
    print("       their SAME names:")
    for t in list(dropped)[:12]:
        print("         - " + str(t))
    return len(dropped)


def _alk_sync_tracking():
    # ALKIFAH-FIX-CONVENTIONS: right before the app decides what counts as "new", let its
    # own tracker forget lessons that no longer exist on this laptop. That is what keeps
    # names identical after a deletion on the platform: no " (2)", no new wording.
    # Silent if anything is missing - it can never stop or break an upload.
    try:
        helper = Path(__file__).resolve().parent.parent / "app" / "alkifah_upload.py"
        if not helper.exists():
            return
        import subprocess
        r = subprocess.run([sys.executable, str(helper), "--sync"],
                           capture_output=True, text=True, timeout=240)
        for line in (r.stdout or "").splitlines():
            if any(k in line for k in ("tracking log  :", "forgotten by this sync",
                                       "cleared because", "no lesson file could be read")):
                print("   " + line.strip())
    except Exception:
        pass


def main():
    _alk_sync_tracking()      # ALKIFAH-FIX-CONVENTIONS
    if not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    items = find_materials(FOLDER)
    _alk_memory_repair(items)      # ALKIFAH-FIX-CONVENTIONS: follow deletions online
    log = load_log()
    save_log(log)
    def _alk_forced(title):          # ALKIFAH-FIX-CONVENTIONS: re-upload on purpose
        _f = str(os.environ.get("LMS_FORCE_TITLES") or "").strip()
        if not _f:
            return False
        if _f.casefold() in ("*", "all", "كل"):
            return True
        t = str(title).casefold()
        return any(part.strip() and part.strip() in t for part in re.split(r"[,;|]", _f))

    new_items = [it for it in items
                 if it["title"] not in log or _alk_forced(it["title"])]
    if str(os.environ.get("LMS_FORCE_TITLES") or "").strip():
        print("  re-upload is ON (%s) - remembered lessons are sent again, same name. "
              "If one is still online you will get two copies of it."
              % os.environ["LMS_FORCE_TITLES"])
    print(f"\nFound {len(items)} PowerPoint file(s). "
          f"Already uploaded: {len(items) - len(new_items)}. New: {len(new_items)}.\n")
    for i, it in enumerate(new_items, 1):
        print(f"  {i:2}. {it['title']}")
    if not new_items:
        print("\nNothing new to upload. Goodbye!")
        return
    chosen = new_items
    # v6.4: let the user pick exactly which files to upload (app checkboxes)
    only = [s.strip().casefold() for a in ARGS.only for s in a.split(",") if s.strip()]
    if only:
        def _picked(it):
            t = it["title"].strip().casefold()
            fn = os.path.basename(it["path"]).strip().casefold()
            return t in only or fn in only
        picked = [it for it in chosen if _picked(it)]
        left_out = len(chosen) - len(picked)
        print(f"\n--only: uploading {len(picked)} selected file(s) "
              f"({left_out} left out by your selection).")
        if not picked:
            print("None of the selected files matched the NEW files in the folder.")
            print("Selected entries:")
            for s in only:
                print(f"   - {s}")
            print("(files uploaded before are skipped automatically — untick them "
                  "in the app or scan again.)")
            return
        chosen = picked
    if ARGS.limit > 0:
        chosen = chosen[:ARGS.limit]
        print(f"\n--limit {ARGS.limit}: only uploading the first {len(chosen)}.")
    if not AUTO:
        answer = input("\nType ALL to upload the new ones, or numbers like 1,3 : ").strip()
        if not answer:
            sys.exit("Cancelled — nothing uploaded.")
        if answer.lower() != "all":
            try:
                chosen = [new_items[int(n) - 1] for n in answer.split(",") if n.strip()]
            except Exception:
                sys.exit("I didn't understand the numbers. Run again and type ALL.")
    results = [(it["title"], "SKIPPED", "already uploaded before")
               for it in items if it not in chosen]
    # login details are checked before the browser starts
    if not USERNAME or not PASSWORD:
        sys.exit("No login details. Open the LMS Automation app, add your teacher account (email + password), then start the task from there. If you prefer the Command Prompt, set LMS_USERNAME and LMS_PASSWORD with setx first.")
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=HEADLESS)
        context = browser.new_context(locale="en-US")
        page = context.new_page()
        login(page)
        print("\nLogged in. Checking the LMS for already-uploaded lessons ...")
        reconciled = check_repetition(page, chosen, log)
        if reconciled:
            print(f"   {reconciled} lesson(s) were already on the LMS but missing "
                  f"from the log — marked to avoid duplicates.")
            chosen = [it for it in chosen if it["title"] not in log]
        if not chosen:
            print("   Nothing new to upload after the duplicate check. Goodbye!")
            quit_powerpoint()
            browser.close()
            return
        print(f"Uploading {len(chosen)} new material(s)...\n")
        for n, item in enumerate(chosen, 1):
            if item["title"] in log:                    # v6.2 in-run duplicate guard
                print(f"[{n}/{len(chosen)}] {item['title']}")
                print("   -> SKIPPED — uploaded earlier in this same run "
                      "(in-run duplicate guard)")
                results.append((item["title"], "SKIPPED",
                                "uploaded earlier in this run"))
                continue
            print(f"[{n}/{len(chosen)}] {item['title']}")
            status, note = "FAILED", "unknown error"
            for attempt in range(1, RETRIES + 1):
                try:
                    upload_path = item["path"]
                    if Path(upload_path).suffix.lower() in (".ppt", ".pptx"):
                        if ARGS.no_pdf:
                            print("   (uploading the PowerPoint file as-is — pack rule is "
                                  "PDF-only)")
                        else:
                            try:
                                upload_path = convert_to_pdf(item["path"])
                            except Exception as conv_err:
                                status = "SKIPPED"
                                note = (f"PDF conversion failed ({conv_err}) — the lesson was "
                                        f"NOT uploaded. Fix PowerPoint or re-run with --no-pdf.")
                                break
                    mb = os.path.getsize(upload_path) / 1024 / 1024
                    if mb > MAX_MB:
                        status, note = "SKIPPED", f"file is {mb:.1f} MB (site limit is {MAX_MB} MB)"
                        break
                    confirmed = upload_one(page, upload_path, item["title"])
                    log[item["title"]] = datetime.now().strftime("%Y-%m-%d %H:%M")
                    save_log(log)
                    status = "OK"
                    note = ("also seen in the list" if confirmed
                            else "saved (site did not display the list)")
                    break
                except Exception as e:
                    note = str(e)
                    # v6.6: the save may have landed even when the page did not
                    # confirm — verify on the LMS BEFORE retrying. This kills
                    # both duplicate uploads and the multi-minute retry loops
                    # the teacher saw as 'stuck on the calendar / create step'.
                    if not str(e).startswith("could not find the upload box"):
                        try:
                            if title_on_lms(page, item["title"]):
                                log[item["title"]] = datetime.now().strftime(
                                    "%Y-%m-%d %H:%M")
                                save_log(log)
                                status, note = "OK", (
                                    "saved (confirmed in the materials list after "
                                    "an unclear save response)")
                                break
                        except Exception:
                            pass
                    if attempt < RETRIES:
                        print(f"   attempt {attempt} failed ({e}) — trying again...")
                        try:
                            page.goto(BASE_URL)
                            settle(page)
                        except Exception:
                            pass
            print(f"   -> {status} — {note}")
            results.append((item["title"], status, note))
        quit_powerpoint()
        browser.close()
    lines = [f"LMS Upload Report — {datetime.now():%Y-%m-%d %H:%M}", "=" * 60]
    for title, status, note in results:
        lines.append(f"[{status:7}] {title}" + (f"  ({note})" if note else ""))
    ok = sum(1 for _, s, _ in results if s == "OK")
    lines += ["=" * 60, f"Uploaded OK: {ok} / {len(chosen)}",
              "Failed items will be retried automatically on the next run."]
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nReport saved to: {REPORT_PATH}")
    if not AUTO:
        input("Press Enter to finish...")

if __name__ == "__main__":
    main()
