# LMS Automation Pack — FIXED (v2)

This is the patched version of the original `LMS_Automation_Pack.zip`. It contains the
same three ZCode skills, with the bugs that prevented localhost execution fixed.

### What's inside

    LMS_Automation_Pack_FIXED/
    ├── requirements.txt
    ├── README.md               <- you are here
    ├── scripts/
    │   ├── upload_materials.py     <- LMS Auto Upload (v5)
    │   ├── create_assessment.py    <- LMS Assessment Maker (v2)
    │   ├── assign_exam.py          <- companion to Assessment Maker (v2)
    │   └── upload_booklet.py       <- LMS Booklet Upload (v2)
    └── skills/
        ├── lms-auto-upload/SKILL.md
        ├── lms-assessment-maker/SKILL.md
        └── lms-booklet-upload/SKILL.md

### Bugs that were fixed (summary)

| # | File | Bug | Fix |
|---|------|-----|-----|
| 1 | `create_assessment.py` | `page.fill("#passwordInput", PASSWORD)` — selector doesn't exist on the LMS login form | Use `fill_first()` against `#Input_Password` (with fallbacks) |
| 2 | `create_assessment.py` | `n = radios.count()` shadowed the `n` parameter (question index) | Renamed to `radio_count` |
| 3 | `create_assessment.py` | `ok = ("5" in body) and ("5.0" in body or "5.00" in body or "5.00" in body)` — too loose, plus duplicated `"5.00"` | Regex parse of `Questions Count: N` and `Total Mark: N.N` |
| 4 | `create_assessment.py` | A single failing question aborted the whole exam | Per-question retry (2×) + `failed_questions` in the log + `--resume <examId>` to retry |
| 5 | `create_assessment.py` | Assignment step had no verification | Verify the success toast after `btnAssignClass.click()` |
| 6 | `upload_booklet.py` | Same `#passwordInput` login bug | Same `fill_first()` fix |
| 7 | `upload_booklet.py` | SKILL.md claimed "Week 3 not uploaded until its Sunday" but code never enforced it | Added `--respect-sunday-rule` flag (off by default; behaviour now matches documentation) |
| 8 | `upload_booklet.py` | `mode_answer` only uploaded the newest booklet week's answer, silently skipping any older missing answer | Iterate newest→oldest, fill missing answers in order, up to `--limit` |
| 9 | `upload_materials.py` | `convert_to_pdf` fell back to `Presentations.Open(..., WithWindow=True)` which broke headless runs | Raise a clear error with the COM HRESULT instead |
| 10 | `upload_materials.py` | `PREVIOUSLY_UPLOADED` list hardcoded in source, duplicating `uploaded_log.json` | Removed; log is the single source of truth |
| 11 | `upload_materials.py` | `check_repetition` only handled "Next"-link pagination, not numbered pagination | Added numbered-pagination fallback (`.pagination .active + li`) |
| 12 | `upload_materials.py` | No way to skip PowerPoint conversion when troubleshooting | Added `--no-pdf` flag |
| 13 | `upload_materials.py` | No way to rate-limit | Added `--limit N` flag |
| 14 | all scripts | Credentials hardcoded in source, easy to leak when sharing files | Env-var overrides (`LMS_USERNAME`, `LMS_PASSWORD`, `LMS_FOLDER`, `LMS_COURSE`, `LMS_CLASSES`) |
| 15 | all scripts | No way to see the browser when debugging on localhost | Added `--show` flag to all scripts |

### Setup (new laptop, one-time)

```cmd
:: 1. Install Python 3.10+ from python.org (tick "Add to PATH")
:: 2. Open Command Prompt and install dependencies:
pip install -r requirements.txt
playwright install chromium

:: 3. Microsoft PowerPoint must be installed (for PPT->PDF conversion).
::    If you don't have PowerPoint, you can still run with --no-pdf.

:: 4. (Recommended) Set credentials as env vars so they don't live in the .py:
setx LMS_USERNAME "your.email@alkifahacademy.edu.sa"
setx LMS_PASSWORD "your-password"
setx LMS_FOLDER   "D:\Alkifah academy\2026-2027\First Term"
setx LMS_COURSE   "Science 3 - Grade 9"
setx LMS_CLASSES  "ALL"
```

After `setx`, **close and reopen** Command Prompt so the new env vars are picked up.

### Quick test

```cmd
:: Visible browser, asks before uploading
python scripts\upload_materials.py

:: Visible browser, all booklets status
python scripts\upload_booklet.py status --show

:: Dry-run an assessment spec (no LMS touch)
python scripts\create_assessment.py specs\Cellular_Transport_Blueprint_assessment.json --dry-run
```

### Scheduling

**ZCode automation** — recreate using `AUTOMATIONS_TO_CREATE.txt` (paths adjusted to your
laptop).

**Windows Task Scheduler** (no ZCode needed):

```cmd
schtasks /Create /SC DAILY /ST 07:00 /TN "LMS Auto Upload" ^
  /TR "python \"C:\path\to\LMS_Automation_Pack_FIXED\scripts\upload_materials.py\" auto"

schtasks /Create /SC WEEKLY /D SUN,MON,TUE,WED,THU /ST 08:00 /TN "LMS Assessment" ^
  /TR "python \"C:\path\to\LMS_Automation_Pack_FIXED\scripts\create_assessment.py\" <spec.json>"

schtasks /Create /SC WEEKLY /D SUN /ST 07:00 /TN "LMS Booklet" ^
  /TR "python \"C:\path\to\LMS_Automation_Pack_FIXED\scripts\upload_booklet.py\" auto"

schtasks /Create /SC WEEKLY /D THU /ST 12:30 /TN "LMS Model Answer" ^
  /TR "python \"C:\path\to\LMS_Automation_Pack_FIXED\scripts\upload_booklet.py\" answer"
```

The laptop must be ON (not sleeping) at those times.

### Logs

- `scripts\uploaded_log.json` — every lesson material ever uploaded.
- `scripts\upload_report.txt` — last upload report (overwritten each run).
- `scripts\assessment_log.json` — every assessment ever created, with exam URL.
- `scripts\booklet_log.json` — every booklet / model answer ever uploaded.

To force re-upload/re-create, delete the relevant line from the corresponding log file.

### ✅ Folder structure you should end up with

    LMS_Automation_Pack_FIXED
    ├── README.md
    ├── requirements.txt
    ├── scripts
    │   ├── upload_materials.py
    │   ├── create_assessment.py
    │   ├── assign_exam.py
    │   └── upload_booklet.py
    └── skills
        ├── lms-auto-upload
        │   └── SKILL.md
        ├── lms-assessment-maker
        │   └── SKILL.md
        └── lms-booklet-upload
            └── SKILL.md

For each file above, just open Notepad → paste the contents (without the fence lines, only
what's inside) → Save As with the exact filename shown in the header → save into the
matching folder.

After all 9 files are saved, run from inside `LMS_Automation_Pack_FIXED\`:

```cmd
pip install -r requirements.txt
playwright install chromium
setx LMS_USERNAME "your.email@alkifahacademy.edu.sa"
setx LMS_PASSWORD "your-password"
:: close & reopen Command Prompt, then:
python scripts\upload_booklet.py status --show
```

## Extra helper included in this build: check_login.py

```cmd
python scripts\check_login.py --show
```

Read-only login check: signs in with `LMS_USERNAME` / `LMS_PASSWORD`, prints which login
selectors were found, opens `/CourseManagement/Materials` and exits 0 on success, 1 on
failure with the reason. Use it to verify a teacher's email + password (and the
`#Input_Password` fix) before running any upload. It creates nothing and changes nothing.
