============================================================
  Alkifah Academy LMS - Automation  v6.2  (ابدأ من هنا)
============================================================

  خطوة واحدة فقط: انقر مرتين على الملف  START_HERE.bat

------------------------------------------------------------
  5 خطوات بالعربي
------------------------------------------------------------
1) انقر مرتين على START_HERE.bat
   (أول مرة فقط: إن ظهرت رسالة أن بايثون غير مثبّت، اتبع
    التعليمات على الشاشة ثم أعد النقر على الملف)

2) سيفتح المتصفح تلقائياً على صفحة التطبيق.

3) اكتب بريدك وكلمة مرورك في المنصة مرة واحدة، ثم اضغط
   "احفظ الحساب". (تُحفظ مشفّرة على جهازك فقط)

4) اضغط "اختبار الدخول" للتأكد أن البريد وكلمة المرور يعملان.

5) ضع ملفاتك في مجلد First Term (هو المصدر الوحيد):
       First Term\Week 1\Session 01\الدرس.pptx
       First Term\Booklet\Week 1 booklet.pdf
       First Term\Booklet\Week 1 booklet (Model Answer).pdf
   ثم اضغط الزر الأخضر الكبير:  ⬆ ابدأ الرفع الآن

   القواعد:
     - الشرائح مصدرها PowerPoint وتُرفع PDF (يحوّلها التطبيق تلقائياً)
     - الكتيبات ونماذج الإجابة PDF فقط (يُرفض أي ملف ليس PDF)
     - كل شيء يُرفع إلى قسم "المواد" في المنصة
     - لا يُكرَّر أي ملف موجود مسبقاً (يفحص التطبيق المنصة قبل الرفع)
     - تاريخ النشر = وقت الرفع + 5 دقائق (يمكن تغييره من الإعدادات)

   جديد في v6.2 (بعد فحص مباشر للمنصة بتاريخ 2026-09-17):
     - زر «ابدأ الرفع» لو اتضغط مرتين كانت بتشتغل جلستين
       متوازيين وترفع نفس الملف مرتين (حصل فعلاً مع مادة
       Week 4 يوم ١٥ سبتمبر) - الآن الجلسة التانية تُرفض
       برسالة واضحة لحد ما الأولى تخلص.
     - قائمة الفصول (G9A/G9B/G9C) بتظهر بعد اختيار المادة
       بثانية أو اثنتين (AJAX) - التطبيق كان بيختارها فوراً
       ولو اتأخرت كانت المادة تُرفع من غير فصول. الآن ينتظر
       ظهورها، ولو مفيش فصول يتحدّث الرفع تماماً كحماية.
     - المنصة بترفض امتحاناً مدته ١٠ دقايق أو أقل - أي spec
       بمدة أقل بيرتفع تلقائياً لـ ١٥ دقيقة مع تنبيه.
     - حقل كلمة المرور في صفحة الدخول بـ id="passwordInput"
       حالياً (كان #Input_Password) - سلاسل البدائل اتحدّثت
       في كل السكربتات لتغطية الشكلين.
     - فحص التحقق بعد إنشاء الامتحان بيقبل الصيغة الجديدة
       "Total Questions / Total Mark" الموجودة على المنصة.

   جديد في v6.1 (بعد آخر تجربة على المنصة):
     - مربع المرفقات كان لا يُعثر عليه فيتوقف الرفع برسالة
       set_input_files: Timeout 30000ms - الآن يُبحث عنه بخمس طرق
       مختلفة، ولو لم يظهر تُكتشف المشكلة برسالة واضحة.
     - حقل تاريخ النشر كان يبقى فارغاً فيتعطّل زر الحفظ - الآن
       يكتبه التطبيق بنفسه (الآن + 5 دقائق) ويتحقق من القيمة.
     - ملفات بوربوينت من الإيميل/الفلاش/ون درايف كانت تُرفض
       برسالة HRESULT -2147467259 - الآن يُزال حظر الإنترنت عن
       الملف ويُعاد المحاولة من نسخة مؤقتة، والمحاضرة تُتخطّى فقط
       إن استمر الفشل (ولا تُرفع أبداً كـ pptx).

مهم: إذا لم تعمل، لا تغلق النافذة السوداء - اقرأ آخر سطر فيها.

------------------------------------------------------------
  English - 5 steps
------------------------------------------------------------
1) Double-click START_HERE.bat
   (first time only: if it says Python is missing, follow the
    on-screen instructions, install Python, then click again)

2) Your browser opens on the app by itself.

3) Type your school email and password once, press "Save account".
   (stored encrypted on this computer only)

4) Press "Test login" to confirm the email and password work.

5) Put your files in the First Term folder (the only import folder):
       First Term\Week 1\Session 01\lesson.pptx
       First Term\Booklet\Week 1 booklet.pdf
       First Term\Booklet\Week 1 booklet (Model Answer).pdf
   then press the big green button:  Start upload now

   The rules:
     - slides come from PowerPoint and are uploaded as PDF (converted automatically)
     - booklets and model answers must be PDF files (anything else is refused)
     - everything goes to the Materials section of the platform
     - nothing already uploaded is repeated (the app checks the platform first)
     - the publish date is set to now + 5 minutes (change it in Settings)

   New in v6.2 (after a live platform check on 2026-09-17):
     - Pressing "Start upload" twice used to run two parallel
       sessions and upload the same file twice (it really
       happened with a Week 4 material on Sep 15) - a second
       start is now refused with a clear message until the
       first one finishes.
     - The Classes list (G9A/G9B/G9C) only loads a second or
       two AFTER the course is chosen (AJAX) - the app now
       waits for it, and if no classes appear the upload is
       stopped entirely as a safety guard.
     - The LMS rejects exams with a duration of 10 minutes or
       less - any spec below that is bumped to 15 minutes.
     - The login password box currently has id="passwordInput"
       (was #Input_Password) - the fallback chains in every
       script were updated to cover both layouts.
     - The post-creation verification now accepts the new
       "Total Questions / Total Mark" wording on the page.

   New in v6.1 (after the last live run):
     - the Attachment box could not be found, so the run stopped with
       "set_input_files: Timeout 30000ms" - it is now searched five
       different ways, and if the page is really different you get a
       clear message instead of a timeout.
     - the Publish Date was left empty, which keeps Save disabled -
       the app now types it (now + 5 minutes) and reads it back.
     - PowerPoint files coming from email / USB / OneDrive were refused
       with "HRESULT: -2147467259" - the internet block is removed,
       more Open() variants are tried and a temporary copy is used.
       A lesson is skipped only if all of that fails (never uploaded
       as .pptx).

The black window must stay open while you use the app.
Keep the folder together - do not move just one file out of it.
