#!/usr/bin/env python3
"""
Alkifah LMS Automation — web control room (Flask).

Run locally on the Windows laptop that has the pack installed:

    python app\\app.py                 # then open http://127.0.0.1:8770
    python app\\app.py --port 9000 --open

It reads/writes the pack's own files (scripts, logs, specs) and launches the same
python commands you would type in Command Prompt, streaming their output into the page.
It never asks for, stores or transmits the LMS password: the scripts read
LMS_USERNAME / LMS_PASSWORD from the environment where you launched the app.
"""
from __future__ import annotations

import argparse
import json
import os
import webbrowser
from pathlib import Path

from flask import Flask, jsonify, request, render_template, send_file

import pack
import profiles

app = Flask(__name__, template_folder=str(Path(__file__).resolve().parent / "templates"))
app.config["JSON_SORT_KEYS"] = False


def cfg() -> dict:
    """config.json merged with the active teacher profile."""
    return pack.effective_config()


def raw_cfg() -> dict:
    return pack.load_config()


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/dashboard")
def api_dashboard():
    return jsonify(pack.dashboard(cfg()))


@app.get("/api/config")
def api_config_get():
    return jsonify(cfg())


PROFILE_KEYS = {"install_dir", "term_folder", "booklet_folder", "course", "classes",
                "python_exe", "email", "name"}


@app.post("/api/config")
def api_config_set():
    """App-level settings go to config.json; per-teacher keys go to the active profile."""
    body = request.get_json(force=True, silent=True) or {}
    scope = body.pop("scope", "auto")
    prof = profiles.active()
    prof_patch = {k: v for k, v in body.items() if k in PROFILE_KEYS}
    app_patch = {k: v for k, v in body.items() if k not in PROFILE_KEYS}

    if prof and scope in ("auto", "profile") and prof_patch:
        profiles.update(prof["id"], prof_patch)
        profiles.apply_to_config(profiles.get(prof["id"]))
    if app_patch:
        pack.save_config(app_patch)
    return jsonify(pack.effective_config())


@app.get("/api/pack")
def api_pack():
    return jsonify(pack.pack_status(cfg()))


@app.post("/api/pack/install")
def api_pack_install():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.install_pack(cfg(), body.get("target")))


@app.get("/api/fixes")
def api_fixes():
    return jsonify(pack.verify_fixes(cfg()))


@app.get("/api/env")
def api_env():
    return jsonify(pack.env_status(cfg()))


@app.get("/api/setup_commands")
def api_setup_commands():
    c = cfg()
    install = c["install_dir"]
    term = c["term_folder"]
    block = "\n".join([
        f'cd /d "{install}"',
        "pip install -r requirements.txt",
        "playwright install chromium",
        'setx LMS_USERNAME "your.email@alkifahacademy.edu.sa"',
        'setx LMS_PASSWORD "your-password"',
        f'setx LMS_FOLDER   "{term}"',
        f'setx LMS_COURSE   "{c.get("course", "")}"',
        f'setx LMS_CLASSES  "{c.get("classes", "ALL")}"',
        "REM close this window, open a NEW Command Prompt, then:",
        f'python "{install}\\scripts\\upload_booklet.py" status --show',
    ])
    return jsonify({"install_dir": install, "block": block,
                    "quick_tests": [
                        f'cd /d "{install}\\scripts"',
                        'python upload_booklet.py status --show',
                        f'python create_assessment.py "{c["specs_dir"]}\\'
                        'Week1_Session03_Cell_Cycle_assessment.json" --dry-run',
                    ]})


@app.get("/api/materials/scan")
def api_scan_materials():
    return jsonify(pack.scan_materials(cfg()))


@app.get("/api/booklets/scan")
def api_scan_booklets():
    return jsonify(pack.scan_booklets(cfg()))


@app.get("/api/logs")
def api_logs():
    return jsonify(pack.logs_overview(cfg()))


@app.post("/api/logs/forget")
def api_logs_forget():
    body = request.get_json(force=True, silent=True) or {}
    if not body.get("confirmed"):
        return jsonify({"ok": False, "needs_confirm": True,
                        "message": "This removes the entry from the log so the item "
                                   "can be uploaded/created again."})
    return jsonify(pack.forget_log_entry(cfg(), body.get("log", ""), body.get("key", "")))


@app.get("/api/specs")
def api_specs():
    return jsonify(pack.list_specs(cfg()))


@app.get("/api/specs/get")
def api_spec_get():
    name = request.args.get("name", "")
    path = pack.specs_dir(cfg()) / Path(name).name
    if not path.exists():
        return jsonify({"ok": False, "error": "spec not found"})
    return jsonify({"ok": True, "name": path.name,
                    "spec": json.loads(path.read_text(encoding="utf-8"))})


@app.post("/api/specs/validate")
def api_specs_validate():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.validate_spec(body.get("spec") or {}))


@app.post("/api/specs/save")
def api_specs_save():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.save_spec(cfg(), body.get("spec") or {}, body.get("filename", "")))


@app.post("/api/specs/delete")
def api_specs_delete():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.delete_spec(cfg(), body.get("name", "")))


@app.get("/api/lessons/pdfs")
def api_lesson_pdfs():
    return jsonify(pack.lesson_pdfs(cfg()))


@app.post("/api/lesson/extract")
def api_lesson_extract():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.extract_pdf_text(body.get("path", ""),
                                         int(body.get("max_pages", 10))))


@app.get("/api/latest_lesson")
def api_latest_lesson():
    lesson = pack.latest_lesson(cfg())
    return jsonify(lesson or {})


@app.get("/api/schedules")
def api_schedules():
    c = cfg()
    return jsonify({"rows": pack.schedules(c), "bat": pack.schedule_bat(c),
                    "install_dir": c["install_dir"]})


@app.get("/api/schedules/bat")
def api_schedules_bat():
    c = cfg()
    out = Path(c["install_dir"]) / "install_schedules.bat"
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(pack.schedule_bat(c), encoding="utf-8")
        return jsonify({"ok": True, "path": str(out), "content": pack.schedule_bat(c)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e), "content": pack.schedule_bat(c)})


@app.get("/api/automations_file")
def api_automations_file():
    c = cfg()
    p = Path(c["install_dir"]) / "AUTOMATIONS_TO_CREATE.txt"
    if p.exists():
        return jsonify({"ok": True, "path": str(p), "text": p.read_text(encoding="utf-8")})
    return jsonify({"ok": False, "error": "AUTOMATIONS_TO_CREATE.txt not found in the "
                                          "install folder (install the pack first)"})


@app.post("/api/run")
def api_run():
    body = request.get_json(force=True, silent=True) or {}
    return jsonify(pack.run_action(cfg(), body.get("kind", ""), body.get("action", ""),
                                   body.get("opts") or {},
                                   bool(body.get("confirmed"))))


@app.get("/api/run/<run_id>")
def api_run_poll(run_id):
    run = pack.MANAGER.get(run_id)
    if not run:
        return jsonify({"ok": False, "error": "unknown run id"})
    since = int(request.args.get("since", 0))
    payload = run.tail(since)
    payload["ok"] = True
    return jsonify(payload)


@app.post("/api/run/<run_id>/kill")
def api_run_kill(run_id):
    return jsonify(pack.MANAGER.kill(run_id))


@app.get("/api/runs")
def api_runs():
    return jsonify({"history": pack.MANAGER.history(),
                    "active": [pack.MANAGER.runs[i].tail(0) for i in pack.MANAGER.order
                               if pack.MANAGER.runs[i].status in ("running", "starting")]})


@app.get("/api/preview/run")
def api_preview_run():
    """Show the exact command(s) that a button would run, without running them."""
    kind = request.args.get("kind", "")
    action = request.args.get("action", "")
    opts = {}
    for key in ("limit", "spec", "resume", "exam_ids", "file_path", "file_title"):
        if request.args.get(key):
            opts[key] = request.args[key]
    for flag in ("show", "no_pdf", "dry_run", "respect_sunday"):
        opts[flag] = request.args.get(flag) == "1"
    built = pack.build_command(cfg(), kind, action, opts)
    argv = built.get("argv", [])
    return jsonify({"command": " ".join(f'"{a}"' if " " in a else a for a in argv),
                    "env": built.get("env", {}),
                    "needs_confirm": built.get("needs_confirm", False),
                    "error": built.get("error"),
                    "warnings": built.get("warnings", [])})


@app.post("/api/lesson/pdf_from_text")
def api_pdf_from_text():
    """Small helper: turn pasted lesson text into a PDF (useful when only the PPT exists)."""
    body = request.get_json(force=True, silent=True) or {}
    text = body.get("text", "")
    out = Path(body.get("path") or (Path(cfg()["term_folder"]) / "lesson_from_text.pdf"))
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        doc = fitz.open()
        page = doc.new_page()
        y = 60
        for raw in text.splitlines():
            for chunk in [raw[i:i + 90] for i in range(0, max(len(raw), 1), 90)]:
                if y > 780:
                    page = doc.new_page()
                    y = 60
                page.insert_text((48, y), chunk, fontsize=11)
                y += 16
        out.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out))
        doc.close()
        return jsonify({"ok": True, "path": str(out)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


# --------------------------------------------------------------- teacher profiles
@app.get("/api/profiles")
def api_profiles():
    return jsonify({"profiles": profiles.list_profiles(),
                    "active_profile": profiles.active_id(),
                    "crypto": profiles.crypto_method(),
                    "defaults": {
                        "install_dir": raw_cfg().get("install_dir", ""),
                        "term_folder": raw_cfg().get("term_folder", ""),
                        "booklet_folder": raw_cfg().get("booklet_folder", ""),
                        "course": raw_cfg().get("course", ""),
                        "classes": raw_cfg().get("classes", "ALL"),
                        "python_exe": raw_cfg().get("python_exe", ""),
                    }})


@app.post("/api/profiles")
def api_profiles_save():
    """Create or update a teacher profile. The password is written to the encrypted
    local store - never to the pack's scripts, never into a log, never returned."""
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id")
    password = body.get("password")
    if password == "":
        password = None                       # empty string = leave unchanged
    data = {k: body.get(k) for k in profiles.PROFILE_FIELDS if k in body}
    if pid:
        result = profiles.update(pid, data, password)
    else:
        result = profiles.create(data, password)
    if result.get("ok"):
        pid = result.get("id") or pid
        if body.get("activate", True) and pid:
            profiles.set_active(pid)
            profiles.apply_to_config(profiles.get(pid))
    return jsonify(result)


@app.post("/api/profiles/activate")
def api_profiles_activate():
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id", "")
    if pid and not profiles.get(pid):
        return jsonify({"ok": False, "error": "profile not found"})
    profiles.set_active(pid)
    profiles.apply_to_config(profiles.get(pid))
    return jsonify({"ok": True, "active_profile": pid,
                    "config": pack.effective_config()})


@app.post("/api/profiles/delete")
def api_profiles_delete():
    body = request.get_json(force=True, silent=True) or {}
    if not body.get("confirmed"):
        return jsonify({"ok": False, "needs_confirm": True,
                        "message": "This deletes the teacher profile and its stored "
                                   "password from this computer."})
    result = profiles.delete(body.get("id", ""))
    profiles.apply_to_config()
    return jsonify(result)


@app.post("/api/profiles/password")
def api_profiles_password():
    """Set or clear the stored LMS password for a profile."""
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id") or profiles.active_id()
    if not pid or not profiles.get(pid):
        return jsonify({"ok": False, "error": "no teacher profile"})
    return jsonify(profiles.set_password(pid, body.get("password", "")))


@app.get("/api/profiles/setx")
def api_profiles_setx():
    reveal = request.args.get("reveal") == "1"
    return jsonify({"text": profiles.setx_block(None, reveal),
                    "revealed": reveal})


@app.post("/api/login/test")
def api_login_test():
    """Run the read-only login checker with this profile's credentials."""
    body = request.get_json(force=True, silent=True) or {}
    pid = body.get("id") or profiles.active_id()
    prof = profiles.get(pid)
    if not prof:
        return jsonify({"ok": False, "error": "create a teacher profile first "
                                              "(email + password)"})
    if not prof.get("email"):
        return jsonify({"ok": False, "error": "the profile has no LMS email"})
    if not profiles.get_password(pid):
        return jsonify({"ok": False, "error": "the profile has no stored password "
                                              "(enter it in the profile form)"})
    return jsonify(pack.run_action(cfg(), "login", "test",
                                   {"show": bool(body.get("show"))}, True))


@app.get("/api/pick_folder")
def api_pick_folder():
    """Open the native folder dialog on the machine running the app (the teacher's
    laptop) so no path ever has to be typed by hand."""
    import subprocess
    import sys as _sys
    title = request.args.get("title", "Choose a folder")
    initial = request.args.get("initial", "")
    helper = Path(__file__).resolve().parent / "pick_folder.py"
    py = cfg().get("python_exe") or _sys.executable
    try:
        proc = subprocess.run([py, str(helper), title, initial], capture_output=True,
                              text=True, timeout=600)
    except FileNotFoundError:
        return jsonify({"ok": False, "error": f"Python executable not found: {py}"})
    except subprocess.TimeoutExpired:
        return jsonify({"ok": False, "error": "the folder window was left open too long"})
    out = (proc.stdout or "").strip()
    if out.startswith("ERROR"):
        return jsonify({"ok": False, "error": out.replace("ERROR: ", "") +
                        " — copy and paste the path instead."})
    if not out:
        return jsonify({"ok": False, "error": "no folder chosen (cancelled)"})
    return jsonify({"ok": True, "path": out})


@app.get("/api/health")
def api_health():
    return jsonify({"ok": True, "python": os.sys.version.split()[0],
                    "cwd": str(Path.cwd()), "base": str(pack.BASE)})


def main() -> None:
    ap = argparse.ArgumentParser(description="LMS Automation web control room")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8770)
    ap.add_argument("--open", action="store_true", help="open the browser automatically")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()
    if args.open:
        webbrowser.open(f"http://127.0.0.1:{args.port}")
    print(f"LMS Automation control room -> http://127.0.0.1:{args.port}")
    print(f"install folder : {pack.load_config()['install_dir']}")
    app.run(host=args.host, port=args.port, debug=args.debug, threaded=True)


if __name__ == "__main__":
    main()
