# LMS Automation — web control room (app)

A local web app that drives the three skills of **LMS Automation Pack — FIXED (v2)** on
`lms.alkifah.edu.sa`. It runs the same four Python scripts you would type in Command
Prompt, streams their output live, and prepares every spec / schedule / command for you.

```
START_HERE.bat          ← double-click this on Windows
app/app.py               ← Flask server (python app/app.py --port 8770)
app/pack.py              ← backend: scanning, logs, fix-verifier, runner, schedules
app/templates/index.html ← the UI (Arabic RTL by default, English toggle)
```

## Start it

**Windows (the laptop that has the pack):**

```cmd
cd /d "D:\Alkifah academy\2026-2027\LMS_Automation_Pack_FIXED"
START_HERE.bat
```

Then open <http://127.0.0.1:8770>.

**Any machine (preview, nothing is uploaded):**

```bash
python3 app/app.py --port 8770
```

## What each tab does

| Tab | What you get |
|---|---|
| **لوحة الحالة / Dashboard** | KPI cards (materials uploaded, waiting, assessments, booklets, missing answers), the **15-fix verification** read live from your script sources, current `LMS_*` environment variables (set / not set — values are never displayed), the latest uploaded lesson, and the last `upload_report.txt`. |
| **الإعداد / Setup** | The install folder, term folder, booklet folder, course and classes. A button that **creates all nine pack files** in the folder you choose (scripts, SKILL.md × 3, requirements.txt, README.md, AUTOMATIONS_TO_CREATE.txt, two example specs). The exact `pip` / `playwright` / `setx` block to copy into Command Prompt, and two "quick test" commands. |
| **المواد / Materials** | Scans your `Week*/Session*` tree with the same naming rules as `upload_materials.py` (`Week N - Session NN - <file>`), shows what is new vs already in `uploaded_log.json`, flags files over the 25 MB LMS limit, and runs `upload_materials.py auto` with `--limit`, `--no-pdf`, `--show`. |
| **منشئ التقييمات / Assessment maker** | Pulls the **latest uploaded lesson** from `uploaded_log.json`, reads the lesson `PDF` text with pymupdf, gives you a 5-question MCQ editor (level, mark, 4 options, correct answer), validates against the skill rules (exactly 5 questions, 3 Easy + 2 Medium, 1 mark each, one correct option), saves the spec JSON, then runs `--dry-run` or creates the exam for real, and can re-assign with `assign_exam.py <examId>`. |
| **الكتيبات / Booklets** | Booklet/model-answer table for the exact filenames the script expects, `status` / `auto` / `answer` runs, `--limit`, `--respect-sunday-rule`, and manual one-off `file "<pdf>" "<title>"` uploads. |
| **الجدولة / Schedules** | The four automations with cron expressions (`0 7 * * *`, `0 8 * * 0-4`, `0 7 * * 0`, `30 12 * * 4`), the `schtasks` command for each with **your** paths already substituted, copy buttons, and a **Write install_schedules.bat** button that puts the admin-ready batch file in the install folder. |
| **السجلات / Logs & runs** | All three JSON logs with a per-line "delete line" button (re-upload / re-create an item), the full `upload_report.txt`, and the history of every command the app has run with its exit code. |

## Teacher accounts (sign-in) — how it works

Any teacher can use the same app on the same laptop. At the top-right there is a button
with the teacher's name; the first time you open the app the sign-in form opens by itself.

The form asks for:

| Field | Why |
|---|---|
| **اسم المعلم / Teacher name** | only a label, so several teachers are easy to tell apart |
| **بريد الدخول للمنصة / LMS login email** | `LMS_USERNAME` for every run |
| **كلمة المرور / Password** | `LMS_PASSWORD` for every run (show/hide button) |
| Install folder, term folder, booklet folder, course, classes, Python path | each teacher can point at his own folders and his own course |

Buttons: **احفظ الحساب** (save), **اختبار الدخول** (test the login, read-only),
**حذف الحساب** (delete the account and its stored password).

**Where the password lives**

* Written to `app/secrets.json`, encrypted with a key in `app/.appkey` — AES/Fernet when the
  `cryptography` package is installed (the launcher installs it), otherwise HMAC obfuscation.
  The app shows which one you have.
* It is **never** written into the pack's `.py` files, never into a log, never returned by any
  API call (the UI only ever knows "a password is stored: yes/no").
* It is injected as `LMS_PASSWORD` **for the duration of a single run only**.
* Deleting the profile deletes it. Removing `app/.appkey` makes every stored password
  unreadable (teachers then just re-enter it).
* Nothing is sent anywhere except `lms.alkifah.edu.sa`, by the pack's own scripts.

**Testing the login without uploading anything.** *Test login* runs the new
`scripts/check_login.py` (read-only): it signs in, prints which login selectors the LMS
actually has, opens the Materials page and exits 0 on success / 1 with the reason. It never
creates or changes anything.

**Switching teachers.** Click a name in **المعلمون على هذا الجهاز** (Setup tab) → *استخدم هذا
الحساب*. Every scan, upload, assessment and schedule command in the app then uses that
teacher's email, password, folders, course and classes.

**Optional: also use Command Prompt by hand.** The Setup tab generates the `setx` block for
the active teacher (password hidden by default, "reveal" if you want it inside the command).
Useful only if you also run the scripts outside the app.

## Upload rules enforced by the app and the scripts (v6)

(v6.1 additions — live-run hardening, nothing to edit by hand)

| Symptom you may have seen | v6.1 behaviour |
|---|---|
| `set_input_files: Timeout 30000ms` at the Attachment step | the upload box is searched in five places, then by clicking the dropzone and using the file chooser; the script prints `(attached through <selector>)` |
| Publish Date left empty → Save stays grey | the app fills **now + Publish delay minutes** (default 5) and reads the value back; if it cannot, it tells you to type it in the browser window |
| `PowerPoint could not open … HRESULT: -2147467259` → lesson skipped | the internet block (`:Zone.Identifier`) is removed, 0-byte / non-Office files are refused with a plain message, four `Open()` variants are tried and a retry runs from a temp copy; the lesson is skipped only if all fail (never uploaded as `.pptx`) |
| PowerPoint automation missing on the PC | the run stops immediately with "install Microsoft Office … nothing was uploaded" instead of failing lesson by lesson |

* **Settings → Publish delay in minutes** = `LMS_MINUTES_AHEAD` for the run (default 5).
* The Dashboard shows the **pack version** next to `fixes 23/23`; if it is older than the version
  announced in the chat, unzip the newest `Alkifah_LMS_App.zip` over this folder and press *Rescan*.

| Item | Source | Uploaded as | Destination |
|---|---|---|---|
| Lesson materials | `.pptx` / `.ppt` in `First Term\Week*\Session*` | **PDF** (converted with PowerPoint; if conversion fails the lesson is skipped, never uploaded as PowerPoint) | LMS → Course Management → **Materials** |
| Weekly booklet | `First Term\Booklet\Week N booklet.pdf` | **PDF only** (content checked by the `%PDF` header) | LMS → **Materials** |
| Booklet model answer | `First Term\Booklet\Week N booklet (Model Answer).pdf` | **PDF only** | LMS → **Materials** |

* **One import folder:** `First Term`. Choose only that folder in the profile (📁 button);
  the booklet folder is derived as `First Term\Booklet`, and the app also finds booklet PDFs
  sitting directly in `First Term`.
* **Session folders** may be named `01`, `Session 01`, `S 3` or `session-2`; the title becomes
  `Week N - Session NN - <lesson name>`.
* **Duplicate check before every upload:** local logs **and** the live LMS Materials list.
  Materials are matched by generated title or source file name; booklets by title, via
  `reconcile_with_lms()` inside `upload_booklet.py`. A repeated item is skipped and marked
  `already on LMS (reconciled …)`.
* The Materials tab shows a **PDF** column (`PDF` = already converted, `سيُحوَّل PDF` = will be
  converted); the Booklets tab shows ignored non-PDF files and the folders it searched.

## Safety model

* The password is stored **encrypted, locally, per teacher** (`app/secrets.json`, key in
  `app/.appkey`) and is injected into a run as an environment variable only for that run.
  It is never written into the pack's scripts and never leaves this computer except to
  `lms.alkifah.edu.sa`. Prefer no local storage? Leave the password field empty and use the
  `setx` block from the Setup tab instead — the app then reads it from the environment.
* Every action that touches the LMS first shows the **exact command** in a confirmation
  dialog. Read-only actions (`status`, `--dry-run`, scans) run without a prompt.
* The console panel at the bottom shows live output and has a **Stop** button.
* Only the four whitelisted pack scripts can be executed — the app cannot run arbitrary
  commands.
* Materials are materials: there is no "upload homework" or "upload exam file" button
  anywhere, matching the pack's hard rule. Exams exist only in the Assessment Maker tab.
* Log-line deletion asks for confirmation and never touches the LMS.

## Troubleshooting

| Symptom | Fix |
|---|---|
| `env 0/5` in the header | No teacher account yet. Click the name button at the top and save your email + password, or run the `setx` block from Setup and restart the app. |
| `scripts 0/4` in the header | Press **Create the pack files here** in Setup, or point the install folder at your real `LMS_Automation_Pack_FIXED` folder. |
| `fixes 13/15` | One of the scripts is an older copy. Re-copy the matching script from `pack_template/scripts/`. |
| A run ends with `TimeoutError` on the login page | The login selector bug. Check fix **#1/#6** shows ✅ in the Dashboard; if not, the file is the old version. |
| `playwright is not installed` | `pip install -r requirements.txt` then `playwright install chromium`. |
| Port already in use | `python app\app.py --port 8899 --open`. |
| PowerPoint HRESULT error | Close PowerPoint, or run with **--no-pdf**. |
| Nothing found in the materials scan | The app expects `Week*` folders containing `Session NN` (or numbered) folders with `.pptx/.ppt/.pdf` inside. |

## HTTP API (if you want to script it)

`GET /api/dashboard` · `/api/status` · `/api/fixes` · `/api/env` · `/api/setup_commands`
`GET /api/materials/scan` · `/api/booklets/scan` · `/api/logs` · `/api/specs`
`GET /api/lessons/pdfs` · `/api/latest_lesson` · `/api/schedules` · `/api/runs` · `/api/health`
`POST /api/config` · `/api/pack/install` · `/api/specs/save` · `/api/specs/validate`
`POST /api/lesson/extract` · `/api/logs/forget` · `/api/run` · `/api/run/<id>/kill`
