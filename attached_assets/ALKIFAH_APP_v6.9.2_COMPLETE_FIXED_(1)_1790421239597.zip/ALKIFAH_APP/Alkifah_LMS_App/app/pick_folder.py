"""
Opens the native Windows/macOS folder picker and prints the chosen folder.

Used by the web app's "📁" buttons so a teacher never has to type a path.
Called as:  python pick_folder.py "<dialog title>" "<start folder>"
Prints the chosen absolute path on stdout (empty line if cancelled).
"""
import sys


def main() -> int:
    title = sys.argv[1] if len(sys.argv) > 1 else "Choose a folder"
    initial = sys.argv[2] if len(sys.argv) > 2 else ""
    try:
        import tkinter as tk
        from tkinter import filedialog
    except Exception as e:  # headless Linux, minimal Python, etc.
        print(f"ERROR: no graphical folder picker on this machine ({e})")
        return 2
    try:
        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass
        path = filedialog.askdirectory(title=title, initialdir=initial or None,
                                       mustexist=False)
        root.destroy()
        print(path or "")
        return 0
    except Exception as e:
        print(f"ERROR: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
