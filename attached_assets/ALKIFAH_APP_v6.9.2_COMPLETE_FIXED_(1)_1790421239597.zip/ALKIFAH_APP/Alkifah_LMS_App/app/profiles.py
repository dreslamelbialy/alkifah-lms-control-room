"""
Per-teacher profiles for the LMS Automation app.

Each teacher gets a profile: name, LMS email, password, folder paths, course and
classes. The active profile is used by every run, so the same app on the same laptop
can serve several teachers (or several LMS accounts).

Password handling — read this
-----------------------------
* The password is NEVER written into the pack's .py files. It is injected as the
  LMS_PASSWORD environment variable for the duration of a single run only.
* It is stored on this computer in app/secrets.json, encrypted with a key that lives in
  app/.appkey (created once, permissions 600 where the OS allows).
  - With `cryptography` installed: real AES (Fernet).
  - Without it: HMAC-SHA256 keystream (obfuscation, not strong encryption).
    The UI states which method is in use.
* Nothing is ever sent anywhere except lms.alkifah.edu.sa by the pack scripts.
* Deleting a profile deletes its stored password.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import sys
import uuid
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
PROFILES_PATH = APP_DIR / "profiles.json"
SECRETS_PATH = APP_DIR / "secrets.json"
KEY_PATH = APP_DIR / ".appkey"
CONFIG_PATH = APP_DIR / "config.json"

PROFILE_FIELDS = ("name", "email", "install_dir", "term_folder", "booklet_folder",
                  "course", "classes", "python_exe")


# --------------------------------------------------------------------- io helpers
def _read(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default


def _write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)
    if path.name in ("secrets.json", ".appkey"):
        try:
            os.chmod(path, 0o600)
        except Exception:
            pass          # Windows: best effort


# --------------------------------------------------------------------- crypto
def _key() -> bytes:
    if KEY_PATH.exists():
        raw = KEY_PATH.read_bytes()
        if len(raw) >= 32:
            return raw[:32]
    key = os.urandom(32)
    KEY_PATH.write_bytes(key)
    try:
        os.chmod(KEY_PATH, 0o600)
    except Exception:
        pass
    return key


def crypto_method() -> str:
    try:
        from cryptography.fernet import Fernet  # noqa: F401
        return "fernet"
    except Exception:
        return "hmac-xor"


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = b""
    counter = 0
    while len(out) < length:
        out += hmac.new(key, nonce + counter.to_bytes(8, "big"), hashlib.sha256).digest()
        counter += 1
    return out[:length]


def encrypt(plain: str) -> dict:
    if plain is None or plain == "":
        return {}
    data = plain.encode("utf-8")
    key = _key()
    try:
        from cryptography.fernet import Fernet
        token = Fernet(base64.urlsafe_b64encode(key)).encrypt(data).decode()
        return {"method": "fernet", "v": 1, "data": token}
    except Exception:
        nonce = os.urandom(16)
        stream = _keystream(key, nonce, len(data))
        ct = bytes(a ^ b for a, b in zip(data, stream))
        tag = hmac.new(key, nonce + ct, hashlib.sha256).hexdigest()
        return {"method": "hmac-xor", "v": 1, "nonce": nonce.hex(),
                "data": base64.b64encode(ct).decode(), "tag": tag}


def decrypt(blob: dict) -> str:
    if not blob or not blob.get("data"):
        return ""
    key = _key()
    try:
        if blob.get("method") == "fernet":
            from cryptography.fernet import Fernet
            return Fernet(base64.urlsafe_b64encode(key)).decrypt(
                blob["data"].encode()).decode("utf-8")
        nonce = bytes.fromhex(blob["nonce"])
        ct = base64.b64decode(blob["data"])
        stream = _keystream(key, nonce, len(ct))
        pt = bytes(a ^ b for a, b in zip(ct, stream))
        tag = hmac.new(key, nonce + ct, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(tag, blob.get("tag", "")):
            return ""
        return pt.decode("utf-8")
    except Exception:
        return ""          # key changed / file edited -> ask the teacher to re-enter


# --------------------------------------------------------------------- profiles
def _derive_booklet_folder(record: dict) -> None:
    """The whole term lives in one folder ("First Term"); booklets sit inside it in a
    Booklet sub-folder. If the teacher only chose the term folder, fill this in."""
    term = (record.get("term_folder") or "").strip()
    booklet = (record.get("booklet_folder") or "").strip()
    sep = "\\" if "\\" in term else "/"
    if term and not booklet:
        record["booklet_folder"] = term.rstrip("/\\") + sep + "Booklet"
    elif term and booklet and not Path(booklet).parts[-1:] == ["Booklet"]:
        # only override when the booklet folder is clearly outside the term folder
        try:
            inside = Path(booklet).resolve().is_relative_to(Path(term).resolve())
        except Exception:
            inside = booklet.lower().startswith(term.lower())
        if not inside:
            record["booklet_folder"] = term.rstrip("/\\") + sep + "Booklet"


def list_profiles() -> list:
    data = _read(PROFILES_PATH, {"profiles": []})
    secrets = _read(SECRETS_PATH, {})
    out = []
    for p in data.get("profiles", []):
        item = {k: p.get(k, "") for k in PROFILE_FIELDS}
        item["id"] = p.get("id")
        item["created"] = p.get("created")
        item["updated"] = p.get("updated")
        item["has_password"] = bool(secrets.get(p.get("id", ""), {}).get("data"))
        out.append(item)
    return out


def get(profile_id: str | None) -> dict | None:
    if not profile_id:
        return None
    for p in list_profiles():
        if p["id"] == profile_id:
            return p
    return None


def active_id() -> str:
    cfg = _read(CONFIG_PATH, {})
    return cfg.get("active_profile") or ""


def active() -> dict | None:
    prof = get(active_id())
    if prof:
        return prof
    profiles = list_profiles()
    return profiles[0] if profiles else None


def set_active(profile_id: str) -> dict:
    cfg = _read(CONFIG_PATH, {})
    cfg["active_profile"] = profile_id or ""
    _write(CONFIG_PATH, cfg)
    return {"ok": True, "active_profile": cfg["active_profile"]}


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")[:40]


def create(data: dict, password: str | None = None) -> dict:
    profiles = _read(PROFILES_PATH, {"profiles": []})
    pid = uuid.uuid4().hex[:12]
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    record = {"id": pid, "created": now, "updated": now}
    for key in PROFILE_FIELDS:
        record[key] = (data.get(key) or "").strip() if isinstance(data.get(key), str) \
            else data.get(key)
    if not record.get("name"):
        record["name"] = record.get("email") or f"teacher-{_slug(pid)}"
    _derive_booklet_folder(record)
    profiles["profiles"].append(record)
    _write(PROFILES_PATH, profiles)
    if password:
        set_password(pid, password)
    if not active_id():
        set_active(pid)
    return {"ok": True, "id": pid, "profile": get(pid)}


def update(profile_id: str, patch: dict, password: str | None = None) -> dict:
    profiles = _read(PROFILES_PATH, {"profiles": []})
    hit = None
    for p in profiles.get("profiles", []):
        if p.get("id") == profile_id:
            hit = p
            break
    if not hit:
        return {"ok": False, "error": "profile not found"}
    for key in PROFILE_FIELDS:
        if key in patch and patch[key] is not None:
            value = patch[key]
            hit[key] = value.strip() if isinstance(value, str) else value
    _derive_booklet_folder(hit)
    hit["updated"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    _write(PROFILES_PATH, profiles)
    if password:
        set_password(profile_id, password)
    return {"ok": True, "profile": get(profile_id)}


def delete(profile_id: str) -> dict:
    profiles = _read(PROFILES_PATH, {"profiles": []})
    before = len(profiles.get("profiles", []))
    profiles["profiles"] = [p for p in profiles.get("profiles", [])
                            if p.get("id") != profile_id]
    if len(profiles["profiles"]) == before:
        return {"ok": False, "error": "profile not found"}
    _write(PROFILES_PATH, profiles)
    secrets = _read(SECRETS_PATH, {})
    if profile_id in secrets:
        secrets.pop(profile_id)
        _write(SECRETS_PATH, secrets)
    if active_id() == profile_id:
        remaining = [p["id"] for p in profiles["profiles"]]
        set_active(remaining[0] if remaining else "")
    return {"ok": True, "deleted": profile_id}


def set_password(profile_id: str, password: str) -> dict:
    secrets = _read(SECRETS_PATH, {})
    if password:
        secrets[profile_id] = encrypt(password)
    else:
        secrets.pop(profile_id, None)
    _write(SECRETS_PATH, secrets)
    return {"ok": True, "stored": bool(password),
            "method": crypto_method() if password else None}


def get_password(profile_id: str) -> str:
    secrets = _read(SECRETS_PATH, {})
    return decrypt(secrets.get(profile_id, {}))


def env_for(profile: dict | None = None) -> dict:
    """Environment variables a run should use for this teacher."""
    prof = profile or active()
    if not prof:
        return {}
    env = {"LMS_USERNAME": prof.get("email", "")}
    pw = get_password(prof["id"])
    if pw:
        env["LMS_PASSWORD"] = pw
    return env


def setx_block(profile: dict | None = None, reveal_password: bool = False) -> str:
    prof = profile or active()
    if not prof:
        return 'REM no teacher profile yet — create one in the app first'
    pw = get_password(prof["id"]) if reveal_password else "<your-password>"
    lines = [f"REM {prof.get('name','')} — run in a normal Command Prompt on this laptop",
             f'setx LMS_USERNAME "{prof.get("email","")}"',
             f'setx LMS_PASSWORD "{pw}"']
    if prof.get("term_folder"):
        lines.append(f'setx LMS_FOLDER   "{prof["term_folder"]}"')
    if prof.get("course"):
        lines.append(f'setx LMS_COURSE   "{prof["course"]}"')
    if prof.get("classes"):
        lines.append(f'setx LMS_CLASSES  "{prof["classes"]}"')
    lines.append("REM close this window and open a NEW Command Prompt for the values to apply")
    return "\n".join(lines)


def apply_to_config(profile: dict | None = None) -> dict:
    """Copy the active profile's paths/etc into config.json (used by the dashboard)."""
    prof = profile or active()
    cfg = _read(CONFIG_PATH, {})
    if prof:
        for key in ("install_dir", "term_folder", "booklet_folder", "course",
                    "classes", "python_exe"):
            if prof.get(key):
                cfg[key] = prof[key]
        if prof.get("email"):
            cfg["lms_user"] = prof["email"]
    _write(CONFIG_PATH, cfg)
    return cfg


def summary() -> dict:
    prof = active()
    return {
        "active": ({k: v for k, v in prof.items() if k != "password"} if prof else None),
        "count": len(list_profiles()),
        "password_method": crypto_method(),
        "has_password": bool(prof and prof.get("has_password")),
        "python": sys.version.split()[0],
    }
