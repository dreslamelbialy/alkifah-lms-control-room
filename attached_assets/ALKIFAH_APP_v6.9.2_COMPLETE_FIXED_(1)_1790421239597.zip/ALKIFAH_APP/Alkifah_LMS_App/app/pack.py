"""
Alkifah LMS Automation — app backend library.

Everything the web UI needs that is not HTTP: config, folder scanning (same rules as
the pack's scripts), local log reading, the 15-fix verifier, schedule generation,
pack installation and the script runner.

Design rules taken from the pack:
  * The app NEVER stores or asks for the LMS password. It is read from the
    environment (setx LMS_PASSWORD) at the moment a script is launched.
  * Nothing is uploaded without an explicit confirmation flag from the UI.
  * The materials skill is materials-only; the app has no "homework/exam upload"
    button anywhere - exams live in the Assessment Maker tab only.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

import profiles

APP_DIR = Path(__file__).resolve().parent
BASE = APP_DIR.parent                 # /home/user/LMS_Automation
CONFIG_PATH = APP_DIR / "config.json"
RUNS_PATH = APP_DIR / "runs.json"
TEMPLATE_DIR = BASE / "pack_template"
WORKBENCH_DIR = BASE / "workbench"

SCRIPTS = {
    "materials": "upload_materials.py",
    "assessment": "create_assessment.py",
    "assign": "assign_exam.py",
    "booklet": "upload_booklet.py",
}

_WINDOWS_DEFAULTS = {
    "install_dir": r"D:\Alkifah academy\2026-2027\LMS_Automation_Pack_FIXED",
    "term_folder": r"D:\Alkifah academy\2026-2027\First Term",
    "booklet_folder": r"D:\Alkifah academy\2026-2027\First Term\Booklet",
}
_DEMO_DEFAULTS = {
    "install_dir": str(WORKBENCH_DIR),
    "term_folder": str(WORKBENCH_DIR / "demo" / "First Term"),
    "booklet_folder": str(WORKBENCH_DIR / "demo" / "First Term" / "Booklet"),
}


def pack_root() -> Path | None:
    """The folder this app was unzipped into, when it contains the pack scripts.

    If the app is started from inside its own pack folder (the normal, one-click
    case) then everything is already in the right place and no path needs typing.
    """
    for candidate in (APP_DIR.parent, APP_DIR.parent.parent):
        try:
            if (candidate / "scripts" / "upload_materials.py").exists():
                return candidate
        except OSError:
            continue
    return None


def _default_paths() -> dict:
    root = pack_root()
    if root is not None:
        term = root / "First Term"
        return {"install_dir": str(root),
                "term_folder": str(term),
                "booklet_folder": str(term / "Booklet")}
    if sys.platform.startswith("win"):
        return dict(_WINDOWS_DEFAULTS)
    return dict(_DEMO_DEFAULTS)


DEFAULT_CONFIG = {
    **_default_paths(),
    "course": "Science 3 - Grade 9",
    "classes": "ALL",
    "publish_minutes": 5,          # publish date = now + N minutes (LMS_MINUTES_AHEAD)
    "python_exe": sys.executable,
    "lms_user": "",
    "base_url": "https://lms.alkifah.edu.sa",
    "specs_dir": "",
    "demo_mode": True,
    "active_profile": "",
}

TITLE_UNSAFE = re.compile(r"[^\w\-.]+")


# --------------------------------------------------------------------------- config
def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if CONFIG_PATH.exists():
        try:
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except Exception:
            pass
    # v6.7 portable self-heal: a config.json that travelled inside an update
    # package may carry paths from the computer where the package was BUILT.
    # If the stored install_dir is not a real pack folder on THIS machine,
    # re-point everything at the pack we are actually running from.
    try:
        root = pack_root()
        stored = Path(cfg.get("install_dir") or "")
        invalid = (not cfg.get("install_dir")) or (not stored.exists()) \
            or (not (stored / "app" / "webapi.py").exists())
        if root is not None and invalid:
            cfg["install_dir"] = str(root)
            if not Path(cfg.get("term_folder") or "").exists() and (root / "First Term").exists():
                cfg["term_folder"] = str(root / "First Term")
            if not Path(cfg.get("booklet_folder") or "").exists() and (root / "First Term" / "Booklet").exists():
                cfg["booklet_folder"] = str(root / "First Term" / "Booklet")
            cfg["specs_dir"] = str(root / "specs")
        # a python_exe recorded on another machine can never exist here
        if cfg.get("python_exe") and not Path(cfg["python_exe"]).exists():
            cfg["python_exe"] = sys.executable
    except Exception:
        pass
    if not cfg.get("specs_dir"):
        cfg["specs_dir"] = str(Path(cfg["install_dir"]) / "specs")
    return cfg


def save_config(patch: dict) -> dict:
    cfg = load_config()
    for key in DEFAULT_CONFIG:
        if key in patch and patch[key] is not None:
            cfg[key] = patch[key]
    cfg["specs_dir"] = str(Path(cfg["install_dir"]) / "specs")
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    return cfg


def effective_config(cfg: dict | None = None) -> dict:
    """config.json + the active teacher profile (profile wins where it is filled in)."""
    cfg = dict(cfg or load_config())
    prof = profiles.get(cfg.get("active_profile") or "") or None
    if prof is None:
        profiles_list = profiles.list_profiles()
        prof = profiles_list[0] if profiles_list else None
    cfg["profile"] = {k: v for k, v in prof.items() if k != "password"} if prof else None
    if prof:
        for key in ("install_dir", "term_folder", "booklet_folder", "course",
                    "classes", "python_exe"):
            if prof.get(key):
                cfg[key] = prof[key]
        if prof.get("email"):
            cfg["lms_user"] = prof["email"]
        cfg["specs_dir"] = str(Path(cfg["install_dir"]) / "specs")
    return cfg


def scripts_dir(cfg: dict) -> Path:
    return Path(cfg["install_dir"]) / "scripts"


def script_path(cfg: dict, kind: str) -> Path:
    return scripts_dir(cfg) / SCRIPTS[kind]


# --------------------------------------------------------------------------- helpers
def human_size(num: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return f"{num:.0f} {unit}" if unit in ("B", "KB") else f"{num:.1f} {unit}"
        num /= 1024
    return f"{num:.1f} GB"


def load_json(path: Path, default):
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return default
    return default


def num(name: str):
    m = re.search(r"(\d+)", name)
    return int(m.group(1)) if m else None


def session_number(name: str):
    """'01', 'Session 01', 'S 3', 'session-2' all mean the same session folder."""
    m = re.match(r"^\s*(?:session|s)?[\s\-_.]*(\d{1,2})\s*$", name, re.I)
    if m:
        return int(m.group(1))
    m = re.match(r"^\s*(?:session|s)[\s\-_.]*(\d{1,2})\b", name, re.I)
    return int(m.group(1)) if m else None


# --------------------------------------------------------------------------- status
def pack_status(cfg: dict) -> dict:
    sd = scripts_dir(cfg)
    files = {}
    for name in list(SCRIPTS.values()) + ["check_login.py", "uploaded_log.json",
                                          "upload_report.txt", "assessment_log.json",
                                          "booklet_log.json"]:
        p = sd / name
        files[name] = {
            "exists": p.exists(),
            "size": human_size(p.stat().st_size) if p.exists() else None,
            "mtime": (datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M")
                      if p.exists() else None),
        }
    skills = {}
    for skill, script in (("lms-auto-upload", "upload_materials.py"),
                          ("lms-assessment-maker", "create_assessment.py"),
                          ("lms-booklet-upload", "upload_booklet.py")):
        p = Path(cfg["install_dir"]) / "skills" / skill / "SKILL.md"
        skills[skill] = p.exists()
    return {
        "install_dir": cfg["install_dir"],
        "install_dir_exists": Path(cfg["install_dir"]).exists(),
        "scripts_dir": str(sd),
        "files": files,
        "skills": skills,
        "readme": (Path(cfg["install_dir"]) / "README.md").exists(),
        "requirements": (Path(cfg["install_dir"]) / "requirements.txt").exists(),
        "automations_file": (Path(cfg["install_dir"]) / "AUTOMATIONS_TO_CREATE.txt").exists(),
    }


def env_status(cfg: dict | None = None) -> dict:
    """Where each value comes from: the active teacher profile or the OS environment.
    Values are never returned - only presence - except the email, which is the
    teacher's own login name."""
    cfg = cfg or load_config()
    prof = (cfg.get("profile") if isinstance(cfg, dict) and "profile" in cfg
            else profiles.active())
    out = {}
    env = os.environ
    for key in ("LMS_USERNAME", "LMS_PASSWORD", "LMS_FOLDER", "LMS_COURSE", "LMS_CLASSES"):
        from_profile = bool(
            (key == "LMS_USERNAME" and prof and prof.get("email")) or
            (key == "LMS_PASSWORD" and prof and prof.get("has_password")) or
            (key == "LMS_FOLDER" and prof and prof.get("term_folder")) or
            (key == "LMS_COURSE" and prof and prof.get("course")) or
            (key == "LMS_CLASSES" and prof and prof.get("classes"))
        )
        value = env.get(key)
        out[key] = {
            "set": bool(from_profile or value),
            "from": "profile" if from_profile else ("env" if value else None),
            "preview": (prof.get("email") if key == "LMS_USERNAME" and prof
                        else (value[:3] + "…" if value and key != "LMS_PASSWORD" else None)),
        }
    out["playwright"] = module_available("playwright")
    out["pymupdf"] = module_available("pymupdf") or module_available("fitz")
    out["comtypes"] = module_available("comtypes")
    out["cryptography"] = module_available("cryptography")
    out["password_method"] = profiles.crypto_method()
    out["platform"] = sys.platform
    out["python"] = sys.version.split()[0]
    return out


def module_available(name: str) -> bool:
    try:
        __import__(name)
        return True
    except Exception:
        return False


# --------------------------------------------------------------------------- fix verification
FIX_CHECKS = [
    (1, "create_assessment.py", "#Input_Password", "must",
     "login fills #Input_Password (was #passwordInput)",
     "تسجيل الدخول يستخدم #Input_Password (كان #passwordInput)"),
    (2, "create_assessment.py", "radio_count", "must",
     "radio count no longer shadows the question index",
     "لم يعد عدّاد الراديو يشوّش على رقم السؤال"),
    (3, "create_assessment.py", "total\\s*mark", "regex",
     "verification parses Questions Count / Total Mark",
     "التحقق يقرأ عدد الأسئلة والدرجة الكلية"),
    (4, "create_assessment.py", "--resume", "must",
     "per-question retry + --resume <examId>",
     "إعادة المحاولة لكل سؤال + --resume <examId>"),
    (5, "create_assessment.py", "swal2-popup", "must",
     "assignment verified by success toast",
     "التأكد من رسالة نجاح الإسناد"),
    (6, "upload_booklet.py", "#Input_Password", "must",
     "same login fix in the booklet uploader",
     "نفس إصلاح الدخول في رافع الكتيبات"),
    (7, "upload_booklet.py", "respect-sunday-rule", "must",
     "--respect-sunday-rule flag exists",
     "خيار --respect-sunday-rule موجود"),
    (8, "upload_booklet.py", "reverse=True", "must",
     "answer mode scans newest -> oldest",
     "وضع الإجابة يبدأ من الأحدث للأقدم"),
    (9, "upload_materials.py", "HRESULT", "must",
     "PowerPoint failure raises a clear HRESULT error",
     "خطأ واضح مع HRESULT عند فشل باوربوينت"),
    (10, "upload_materials.py", "PREVIOUSLY_UPLOADED", "must_not",
     "hardcoded upload list removed",
     "إزالة القائمة المثبّتة في الكود"),
    (11, "upload_materials.py", ".pagination .active", "must",
     "numbered-pagination fallback present",
     "دعم الترقيم رقم ١،٢،٣ في الصفحات"),
    (12, "upload_materials.py", "--no-pdf", "must",
     "--no-pdf flag exists",
     "خيار --no-pdf موجود"),
    (13, "upload_materials.py", "--limit", "must",
     "--limit N flag exists",
     "خيار --limit N موجود"),
    (15, "ALL", "--show", "all",
     "--show visible-browser flag in all four scripts",
     "خيار --show في الأربعة سكربتات"),
    (16, "create_assessment.py", "LMS_COURSE", "must",
     "course name comes from the teacher profile (LMS_COURSE), not fixed in the file",
     "اسم المقرر يأتي من حساب المعلم (LMS_COURSE) وليس ثابتاً في الملف"),
    (17, "ALL", 'PASSWORD = os.environ.get("LMS_PASSWORD", "")', "all",
     "no password written inside any script — only LMS_PASSWORD is used",
     "لا توجد كلمة مرور داخل أي سكربت — يُستخدم LMS_PASSWORD فقط"),
    (18, "ALL", "No login details.", "all",
     "clear message when a task is started without a teacher account",
     "رسالة واضحة عند تشغيل مهمة بدون حساب معلم"),
    (19, "upload_materials.py", "def _file_input_selectors", "must",
     "v6.1 - the Attachment box is found five ways (no more 'set_input_files: Timeout')",
     "v6.1 - يتم إيجاد مربع المرفقات بخمس طرق (لا مزيد من خطأ set_input_files: Timeout)"),
    (20, "upload_materials.py", "def set_publish_date", "must",
     "v6.1 - Publish Date is filled with now + 5 minutes and read back",
     "v6.1 - يتم تعبئة تاريخ النشر = الآن + 5 دقائق والتحقق من القيمة"),
    (21, "upload_materials.py", 'os.environ.get("LMS_MINUTES_AHEAD"', "must",
     "v6.1 - the publish delay is a setting, not fixed in the code (LMS_MINUTES_AHEAD)",
     "v6.1 - مهلة النشر إعداد قابل للتغيير (LMS_MINUTES_AHEAD)"),
    (22, "upload_materials.py", "def _convert_with_powerpoint", "must",
     "v6.1 - PowerPoint conversion removes the internet block and retries from a temp copy",
     "v6.1 - تحويل بوربوينت يزيل حظر الإنترنت ويعيد المحاولة من نسخة مؤقتة"),
    (24, "upload_materials.py", "comtypes' tool is missing", "must",
     "v6.1 - plain message telling the teacher to install PowerPoint instead of a traceback",
     "v6.1 - رسالة واضحة تطلب تثبيت بوربوينت بدلاً من رسالة خطأ برمجية"),
    (23, "upload_booklet.py", "def _file_input_selectors", "must",
     "v6.1 - booklets: Attachment fallbacks and the Publish Date helper are present too",
     "v6.1 - كتيبات: طرق المرفقات وتاريخ النشر موجودة أيضاً"),
]


def verify_fixes(cfg: dict) -> dict:
    sd = scripts_dir(cfg)
    sources = {}
    for name in SCRIPTS.values():
        p = sd / name
        sources[name] = p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""

    results = []
    for number, file, marker, mode, desc_en, desc_ar in FIX_CHECKS:
        if marker == "regex":
            key = marker.strip("\\")
            pattern = re.compile("total\\s*mark", re.I)
            ok = bool(pattern.search(sources.get(file, "")))
        elif mode == "all":
            ok = all(marker in src for src in sources.values() if src)
        elif mode == "must_not":
            # must not appear as a live assignment (it is still named in the
            # changelog docstring at the top of the file, which is fine)
            ok = not re.search(r"^\s*" + re.escape(marker) + r"\s*=", sources.get(file, ""),
                               re.M)
        else:
            ok = marker in sources.get(file, "")
        results.append({"n": number, "file": file, "ok": bool(ok),
                        "en": desc_en, "ar": desc_ar})

    env_vars = []
    for name in SCRIPTS.values():
        src = sources.get(name, "")
        env_vars.append({
            "file": name,
            "LMS_USERNAME": 'LMS_USERNAME' in src,
            "LMS_PASSWORD": 'LMS_PASSWORD' in src,
            "LMS_FOLDER": 'LMS_FOLDER' in src,
            "LMS_COURSE": 'LMS_COURSE' in src,
            "LMS_CLASSES": 'LMS_CLASSES' in src,
        })

    gaps = []
    ca = sources.get("create_assessment.py", "")
    if ca and "LMS_COURSE" not in ca:
        gaps.append({
            "id": "assessment_course_env",
            "en": "create_assessment.py has no LMS_COURSE env override - it always looks "
                  "for a course starting with 'science 3'.",
            "ar": "سكربت إنشاء التقييم لا يدعم LMS_COURSE — يبحث دائماً عن مقرر يبدأ بـ "
                  "'science 3'.",
            "patch": ('# one line, after the OTHER env overrides:\n'
                      'COURSE_STARTSWITH = os.environ.get("LMS_COURSE", COURSE_STARTSWITH).split(" - ")[0].lower()'),
        })
    if any(not r["ok"] for r in results if r["n"] >= 19):
        gaps.append({
            "id": "pack_v61",
            "en": "The scripts in this folder are older than v6.1 (Attachment box / Publish "
                  "Date / PowerPoint fixes). Do not edit anything by hand: download the "
                  "latest Alkifah_LMS_App.zip from the chat and unzip it over this folder, "
                  "then press Rescan.",
            "ar": "نسخة السكربتات في هذا المجلد أقدم من v6.1 (إصلاحات مربع المرفقات "
                  "وتاريخ النشر وبوربوينت). لا تعدّل أي شيء يدوياً: نزّل ملف "
                  "Alkifah_LMS_App.zip الأحدث من المحادثة وفك ضغطه فوق هذا المجلد ثم "
                  "اضغط إعادة الفحص.",
            "patch": "Unzip the newest Alkifah_LMS_App.zip over the existing folder.",
        })

    hard_coded = []
    for name, src in sources.items():
        m = re.search(r'^PASSWORD\s*=\s*"([^"]*)"', src, re.M)
        if m and m.group(1):        # a non-empty literal = a real password in the file
            hard_coded.append({"file": name, "line_hint": f'PASSWORD = "{m.group(1)}"'})
    if hard_coded:
        gaps.append({
            "id": "hardcoded_password",
            "en": "A real password is still written inside the script. Blank it so only "
                  "the LMS_PASSWORD env var is used.",
            "ar": "توجد كلمة مرور مكتوبة داخل السكربت. اجعلها فارغة لاستخدام متغير البيئة "
                  "LMS_PASSWORD فقط.",
            "patch": 'PASSWORD = os.environ.get("LMS_PASSWORD", "")',
            "files": [g["file"] for g in hard_coded],
        })

    passed = sum(1 for r in results if r["ok"])
    latest = max((r["n"] for r in results if r["ok"]), default=0)
    version = "6.1" if latest >= 24 else ("6.0" if latest >= 18 else "older")
    return {"checks": results, "passed": passed, "total": len(results),
            "env_vars": env_vars, "gaps": gaps, "version": version}


# --------------------------------------------------------------------------- scanning
def scan_materials(cfg: dict) -> dict:
    """Mirror of find_materials() in upload_materials.py (plus log reconciliation)."""
    root = Path(cfg["term_folder"])
    if not root.exists():
        return {"error": f"folder not found: {root}", "items": []}
    log = load_json(scripts_dir(cfg) / "uploaded_log.json", {})
    items, seen = [], set()

    def ppts(folder: Path):
        """Source files are PowerPoint only. The pack converts each one to PDF and
        uploads the PDF, so converted .pdf files are never counted as new material."""
        found = {}
        for p in folder.rglob("*"):
            try:
                if p.suffix.lower() in (".pptx", ".ppt") and not p.name.startswith("~$"):
                    found[(p.name.lower(), p.stat().st_size)] = p
            except OSError:
                pass
        return sorted(found.values(), key=lambda p: str(p).lower())

    week_dirs = sorted([d for d in root.glob("Week*") if d.is_dir()],
                       key=lambda d: num(d.name) or 0)
    for week_dir in week_dirs:
        week = num(week_dir.name) or 0
        for session_dir in week_dir.iterdir():
            if session_dir.is_dir() and session_number(session_dir.name) is not None:
                session = session_number(session_dir.name)
                for ppt in ppts(session_dir):
                    if str(ppt) not in seen:
                        seen.add(str(ppt))
                        items.append({"week": week, "session": session, "path": ppt})
        for ppt in ppts(week_dir):
            if str(ppt) not in seen:
                seen.add(str(ppt))
                rel = ppt.relative_to(week_dir)
                session = 0
                for part in reversed(rel.parts[:-1]):
                    clean = part[9:] if part.startswith("extracted_") else part
                    found = session_number(clean)
                    if found is not None:
                        session = found
                        break
                if not session:
                    session = session_number(rel.parts[-1]) or num(rel.parts[-1]) or 0
                items.append({"week": week, "session": session, "path": ppt})

    items.sort(key=lambda x: (x["week"], x["session"], str(x["path"]).lower()))
    out, titles = [], {}
    for it in items:
        stem = it["path"].stem
        title = (f"Week {it['week']} - Session {it['session']:02d} - {stem}"
                 if it["session"] else f"Week {it['week']} - {stem}")
        if title in titles:
            titles[title] += 1
            title = f"{title} ({titles[title]})"
        else:
            titles[title] = 1
        size = it["path"].stat().st_size
        pdf_path = it["path"].with_suffix(".pdf")
        try:
            converted = (pdf_path.exists() and
                         pdf_path.stat().st_mtime >= it["path"].stat().st_mtime)
        except OSError:
            converted = False
        out.append({
            "week": it["week"],
            "session": it["session"],
            "title": title,
            "name": it["path"].name,
            "folder": str(it["path"].parent.relative_to(root)),
            "size": human_size(size),
            "mb": round(size / 1024 / 1024, 2),
            "too_big": size / 1024 / 1024 > 25,
            "uploaded": title in log,
            "uploaded_when": log.get(title),
            "pdf_ready": converted,
            "pdf_name": pdf_path.name,
        })
    new = [i for i in out if not i["uploaded"]]
    return {"root": str(root), "items": out, "total": len(out), "new": len(new),
            "already": len(out) - len(new), "pdf_only": True,
            "to_convert": [i["title"] for i in out if not i["pdf_ready"]],
            "oversize": [i["title"] for i in out if i["too_big"]],
            "note": "PowerPoint sources: each lesson is converted to PDF and the PDF is "
                    "uploaded to Course Management -> Materials."}


def _is_real_pdf(path: Path) -> bool:
    """PDF-only rule: the content must really be a PDF, not just the file name."""
    try:
        with path.open("rb") as fh:
            return fh.read(5).startswith(b"%PDF")
    except OSError:
        return False


# v6.4: case-insensitive + tolerate missing/doubled spaces around the words
BOOKLET_PATTERNS = (
    (re.compile(r"^week\s*(\d+)\s*booklet$", re.I), "booklet", "Week {w} Booklet Assessment"),
    (re.compile(r"^week\s*(\d+)\s*booklet\s*\(model\s*answer\)$", re.I), "answer",
     "Week {w} Booklet Model Answer"),
)


def scan_booklets(cfg: dict) -> dict:
    """Booklets and model answers: PDF only. Looks in the booklet folder and, if that
    is empty or missing, anywhere directly inside the First Term folder."""
    log = load_json(scripts_dir(cfg) / "booklet_log.json", {})
    folder = Path(cfg["booklet_folder"])
    term = Path(cfg["term_folder"])

    search_dirs, seen = [], set()
    for d in (folder, term):
        try:
            key = str(d.resolve()).lower()
        except OSError:
            key = str(d).lower()
        if d.exists() and key not in seen:
            seen.add(key)
            search_dirs.append(d)
    if not search_dirs:
        return {"error": f"folder not found: {folder}", "items": [], "ignored_non_pdf": []}

    items, ignored = [], []
    for d in search_dirs:
        for p in sorted(d.glob("*.pdf")):
            # v6.4: normalize stray spaces ("Week 5 booklet .pdf" etc.)
            name = re.sub(r"\s+", " ", p.stem.strip())
            matched = None
            for pattern, kind, title_tpl in BOOKLET_PATTERNS:
                m = pattern.match(name)
                if m:
                    matched = (kind, title_tpl.format(w=int(m.group(1))), int(m.group(1)))
                    break
            if not matched:
                if name.casefold() == "orientation booklet":
                    matched = ("booklet", "Orientation Booklet Assessment", 0)
                elif name.casefold() == "orientation booklet (model answer)":
                    matched = ("answer", "Orientation Booklet Model Answer", 0)
            if not matched:
                continue                      # not a booklet-named file (lesson PDF etc.)
            if any(i["name"] == p.name for i in items):
                continue
            kind, title, week = matched
            if not _is_real_pdf(p):
                ignored.append(p.name)
                continue
            size = p.stat().st_size
            items.append({
                "week": week, "kind": kind, "name": p.name, "title": title,
                "folder": str(p.parent),
                "uploaded": title in log, "uploaded_when": log.get(title),
                "size": human_size(size), "mb": round(size / 1024 / 1024, 2),
                "too_big": size / 1024 / 1024 > 25, "pdf": True,
            })

    orphan_named = []
    for d in search_dirs:
        for p in sorted(d.glob("*.pdf")):
            name = re.sub(r"\s+", " ", p.stem.strip())
            looks_like_booklet = ("booklet" in name.lower())
            if looks_like_booklet and not any(i["name"] == p.name for i in items) \
                    and p.name not in ignored:
                orphan_named.append({
                    "week": None, "kind": "unrecognised", "name": p.name, "title": "",
                    "folder": str(p.parent), "uploaded": False,
                    "note": "name must be 'Week N booklet.pdf' or "
                            "'Week N booklet (Model Answer).pdf' — check for "
                            "extra spaces before .pdf too",
                    "size": human_size(p.stat().st_size),
                    "too_big": p.stat().st_size / 1024 / 1024 > 25, "pdf": True,
                })
    items.extend(orphan_named)
    items.sort(key=lambda x: (x["week"] if x["week"] is not None else 99,
                              0 if x["kind"] == "booklet" else 1))
    missing_b = [i["title"] for i in items if i["kind"] == "booklet" and not i["uploaded"]]
    missing_a = [i["title"] for i in items if i["kind"] == "answer" and not i["uploaded"]]
    return {"folder": str(folder), "searched": [str(d) for d in search_dirs],
            "items": items, "pdf_only": True,
            "missing_booklets": missing_b, "missing_answers": missing_a,
            "ignored_non_pdf": ignored,
            "note": "PDF only. Everything is uploaded to Course Management -> Materials; "
                    "anything already on the LMS is skipped automatically."}


def latest_lesson(cfg: dict) -> dict | None:
    """Newest entry of uploaded_log.json - the input for the assessment maker."""
    log = load_json(scripts_dir(cfg) / "uploaded_log.json", {})
    best = None
    for title, stamp in log.items():
        m = re.search(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2})", str(stamp))
        if not m:
            continue
        if best is None or m.group(1) > best[1]:
            best = (title, m.group(1))
    if not best:
        return None
    return {"title": best[0], "when": best[1]}


def logs_overview(cfg: dict) -> dict:
    sd = scripts_dir(cfg)
    return {
        "uploaded_log.json": load_json(sd / "uploaded_log.json", {}),
        "assessment_log.json": load_json(sd / "assessment_log.json", {}),
        "booklet_log.json": load_json(sd / "booklet_log.json", {}),
        "upload_report.txt": ((sd / "upload_report.txt").read_text(encoding="utf-8")
                              if (sd / "upload_report.txt").exists() else ""),
    }


def forget_log_entry(cfg: dict, log_name: str, key: str) -> dict:
    allowed = {"uploaded_log.json", "assessment_log.json", "booklet_log.json"}
    if log_name not in allowed:
        return {"ok": False, "error": "not an allowed log"}
    path = scripts_dir(cfg) / log_name
    data = load_json(path, {})
    if key not in data:
        return {"ok": False, "error": "entry not found"}
    removed = data.pop(key)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "removed": key, "was": removed}


# --------------------------------------------------------------------------- specs
def specs_dir(cfg: dict) -> Path:
    d = Path(cfg.get("specs_dir") or (Path(cfg["install_dir"]) / "specs"))
    d.mkdir(parents=True, exist_ok=True)
    return d


def list_specs(cfg: dict) -> list:
    out = []
    for p in sorted(specs_dir(cfg).glob("*.json")):
        spec = load_json(p, {})
        out.append({
            "name": p.name,
            "title": spec.get("title", ""),
            "questions": len(spec.get("questions", [])),
            "duration": spec.get("duration"),
            "type": spec.get("type"),
            "marks": sum(q.get("mark", 0) for q in spec.get("questions", [])),
            "size": human_size(p.stat().st_size),
            "mtime": datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M"),
        })
    return out


# --- ALKIFAH-FIX-CONVENTIONS begin --------------------------------------------
# The academy's rules, all readable from config.json so they can change later
# without touching code again:
#    "level_mix"   : {"Easy": 5}   what a finished assessment should look like
#    "force_level" : "Easy"        how generated questions are labelled
def _alk_cfg_get(key, default=None):
    try:
        return (load_config() or {}).get(key, default)
    except Exception:
        return default


def _alk_clean(stem):
    # the platform already shows a lesson as "Week 1 - Session 03 - Cell Cycle",
    # so a generated name is written the same way - never with new wording
    stem = re.sub(r"\.(pdf|pptx?|docx?)$", "", str(stem), flags=re.I)
    stem = re.sub(r"[_\-\.]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    stem = re.sub(r"(?i)\bweeks?\s*(\d+)", lambda m: "Week " + m.group(1), stem)
    stem = re.sub(r"(?i)\bsessions?\s*(\d+)", lambda m: "Session " + m.group(1), stem)
    m = re.match(r"(?i)^Week (\d+) Session (\d+) (.+)$", stem)
    if m:
        stem = "Week %s - Session %s - %s" % (m.group(1), m.group(2), m.group(3))
    else:
        m = re.match(r"(?i)^Session (\d+) (.+)$", stem)
        if m:
            stem = "Session %s - %s" % (m.group(1), m.group(2))
    return stem


def _alk_lesson_name(spec):
    # the app does not store a path in the spec, so look for any hint of one and
    # fall back to the newest lesson the picker can see
    for key in ("lesson", "source_pdf", "pdf", "path", "file", "source", "lesson_path"):
        raw = str(spec.get(key) or "").strip()
        if raw:
            name = _alk_clean(Path(raw).stem)
            if name and "template" not in name.lower():
                return name
    try:                    # the upload log IS the platform's own record of the name
        cfg = load_config() or {}
        log = json.loads((Path(cfg.get("install_dir") or ".") / "scripts" /
                          "uploaded_log.json").read_text(encoding="utf-8"))
        dated = sorted((str(v or ""), str(t)) for t, v in (log or {}).items())
        if dated:
            return _alk_clean(dated[-1][1])      # the most recently uploaded lesson
    except Exception:
        pass
    try:                    # last resort: the newest lesson file the app can see
        for item in reversed(list(lesson_pdfs(load_config() or [])) or []):
            path = item.get("path") if isinstance(item, dict) else item
            name = _alk_clean(Path(str(path or "")).stem)
            if name:
                return name
    except Exception:
        pass
    return ""


def _alk_title(spec):
    # UNIFIED name (the teacher asked for one place, one name): whenever the lesson can
    # be identified, the assessment is called '<Week N - Session M - lesson> assessment'
    # - the same words the platform already uses for the material, so a re-run can never
    # create a second copy under a drifted name. A title typed by hand survives only
    # when nothing else can name the assessment.
    try:
        stem = _alk_lesson_name(spec)
        if stem:
            return stem if stem.lower().endswith("assessment") else stem + " assessment"
    except Exception:
        pass
    name = str(spec.get("title") or "").strip()
    if name:
        return name
    return ""


def _alk_timing_env(cfg):
    # what the platform should do with the dates: open a few minutes from now,
    # close a couple of months from now.  The script reads these env values.
    env = {}
    try:
        env["LMS_MINUTES_AHEAD"] = str(int((cfg or {}).get("publish_minutes") or 5))
    except Exception:
        env["LMS_MINUTES_AHEAD"] = "5"
    try:
        env["LMS_OPEN_MINUTES"] = env["LMS_MINUTES_AHEAD"]
    except Exception:
        pass
    try:
        env["LMS_CLOSE_MONTHS"] = str(int((cfg or {}).get("close_months") or 2))
    except Exception:
        env["LMS_CLOSE_MONTHS"] = "2"
    try:
        days = int((cfg or {}).get("close_days") or 0)
        if days > 0:                      # exact day count, if she ever wants one
            env["LMS_CLOSE_DAYS"] = str(days)
    except Exception:
        pass
    return env


def _alk_fix_spec(cfg, spec):
    # name it after the lesson, then keep the difficulty the academy asked for
    try:
        want = _alk_title(spec)           # ALKIFAH-FIX-CONVENTIONS: unified lesson name
        if want:
            spec["title"] = want
        want = ""
        if isinstance(cfg, dict):
            want = str(cfg.get("force_level") or "")
        want = want or str(_alk_cfg_get("force_level", "") or "")
        # only a MISSING level is filled in. A level that is there is left alone -
        # stamping "Easy" on a Medium question would only fool the checker, and the
        # panel would stop telling you the AI ignored the rule.
        if want:
            for q in spec.get("questions") or []:
                if isinstance(q, dict) and not str(q.get("level") or "").strip():
                    q["level"] = want.strip().capitalize()
    except Exception:
        pass
    return spec
# --- ALKIFAH-FIX-CONVENTIONS end ----------------------------------------------


def validate_spec(spec: dict) -> dict:
    """v6.4: Homework specs carry a sheet file instead of typed questions.
    The 5-question rule is a convention warning now, not a hard error."""
    problems, warnings = [], []
    title = str(spec.get("title", "")).strip()
    want = _alk_title(spec)               # ALKIFAH-FIX-CONVENTIONS: one unified name
    if want and want != title:
        spec["title"] = want
        title = want
    if not title:
        problems.append("title is empty")
    if not title.endswith("assessment"):
        warnings.append('the skill convention is "<Lesson Title> assessment"')
    exam_type = str(spec.get("type", "Quiz") or "Quiz")
    qs = spec.get("questions") or []
    if exam_type.casefold() == "homework":
        sheet = str(spec.get("sheet_path", "") or "").strip()
        if not sheet and not (APP_DIR / "homework_maker.py").exists():
            warnings.append("homework without a sheet file, and the sheet printer is "
                            "missing - run INSTALL_FIXES.bat once (it prints the sheet "
                            "from these questions by itself)")
        elif not Path(sheet).exists():
            problems.append(f"sheet file not found: {sheet}")
    else:
        if not qs:
            problems.append("no questions in the spec")
        elif len(qs) != 5:
            warnings.append(f"the skill convention is 5 questions (found {len(qs)})")
    levels = {}
    for i, q in enumerate(qs, 1):
        text = str(q.get("text", "")).strip()
        if len(text) < 8:
            problems.append(f"Q{i}: question text missing")
        opts = q.get("options") or []
        if len(opts) != 4:
            problems.append(f"Q{i}: 4 options required (found {len(opts)})")
        if any(not str(o).strip() for o in opts):
            problems.append(f"Q{i}: empty option text")
        if len({str(o).strip().lower() for o in opts}) != len(opts):
            warnings.append(f"Q{i}: duplicated options")
        correct = q.get("correct")
        if not isinstance(correct, int) or not 0 <= correct < max(len(opts), 1):
            problems.append(f"Q{i}: 'correct' must be an option index (0-3)")
        if q.get("mark") != 1:
            warnings.append(f"Q{i}: the skill sets mark = 1 for every question")
        level = q.get("level", "Easy")
        if level not in ("Easy", "Medium", "Hard"):
            problems.append(f"Q{i}: level must be Easy / Medium / Hard")
        levels[level] = levels.get(level, 0) + 1
    want_mix = _alk_cfg_get("level_mix") or {"Easy": 5}   # ALKIFAH-FIX-CONVENTIONS
    if levels and isinstance(want_mix, dict) and want_mix:
        off = any(levels.get(k, 0) != v for k, v in want_mix.items())
        off = off or sum(levels.values()) != sum(want_mix.values())
        if off:
            warnings.append("the skill asks for " + " + ".join(
                "%d %s" % (v, k) for k, v in sorted(want_mix.items())))
    return {"ok": not problems, "problems": problems, "warnings": warnings,
            "questions": len(qs), "marks": sum(q.get("mark", 0) for q in qs),
            "levels": levels}


def save_spec(cfg: dict, spec: dict, filename: str) -> dict:
    spec = _alk_fix_spec(cfg, spec)       # ALKIFAH-FIX-CONVENTIONS: title + level
    name = Path(filename or f"{(spec.get('title') or 'spec')[:60]}.json").name
    name = TITLE_UNSAFE.sub("_", name)
    if not name.endswith(".json"):
        name += ".json"
    path = specs_dir(cfg) / name
    path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "path": str(path), "name": name,
            "validation": validate_spec(spec)}


def delete_spec(cfg: dict, name: str) -> dict:
    path = specs_dir(cfg) / Path(name).name
    if path.exists():
        path.unlink()
        return {"ok": True}
    return {"ok": False, "error": "spec not found"}


def extract_pdf_text(path: str, max_pages: int = 10) -> dict:
    p = Path(path)
    if not p.exists():
        return {"ok": False, "error": f"file not found: {p}"}
    try:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
    except ImportError:
        return {"ok": False, "error": "pymupdf is not installed on this machine "
                                      "(pip install pymupdf)"}
    try:
        doc = fitz.open(str(p))
        pages = min(len(doc), max_pages)
        text = "\n".join(doc[i].get_text() for i in range(pages))
        doc.close()
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        return {"ok": True, "pages": pages, "chars": len(text), "text": text[:20000],
                "truncated": len(text) > 20000}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def extract_lesson_text(path: str, max_pages: int = 14, max_chars: int = 20000) -> dict:
    """v6.4: text extraction for AI question generation.
    PDF (pymupdf), PPTX (python-pptx, slides + speaker notes), DOCX (python-docx)."""
    p = Path(path)
    if not p.exists():
        return {"ok": False, "error": f"file not found: {p}"}
    ext = p.suffix.lower()
    try:
        if ext == ".pdf":
            try:
                import pymupdf as fitz
            except ImportError:
                import fitz
            doc = fitz.open(str(p))
            pages = min(len(doc), max_pages)
            text = "\n".join(doc[i].get_text() for i in range(pages))
            doc.close()
        elif ext in (".pptx", ".ppt"):
            try:
                from pptx import Presentation
            except ImportError:
                return {"ok": False, "error": "python-pptx is not installed on this "
                        "machine. From the update window choose the libraries "
                        "option, or run: pip install python-pptx"}
            prs = Presentation(str(p))
            parts = []
            for idx, slide in enumerate(prs.slides, 1):
                chunks = []
                for shp in slide.shapes:
                    t = getattr(shp, "text", "") or ""
                    if t.strip():
                        chunks.append(t.strip())
                try:
                    if slide.has_notes_slide and slide.notes_slide is not None:
                        nt = slide.notes_slide.notes_text_frame.text or ""
                        if nt.strip():
                            chunks.append(nt.strip())
                except Exception:
                    pass
                if chunks:
                    parts.append(f"[Slide {idx}] " + "\n".join(chunks))
                if sum(len(x) for x in parts) > max_chars:
                    break
            text = "\n\n".join(parts)
        elif ext in (".docx", ".doc"):
            try:
                import docx
            except ImportError:
                return {"ok": False, "error": "python-docx is not installed on this "
                        "machine. Run: pip install python-docx"}
            d = docx.Document(str(p))
            text = "\n".join(par.text for par in d.paragraphs if par.text.strip())
        else:
            return {"ok": False, "error": f"unsupported file type: {ext} "
                    "(PDF / PPTX / DOCX only)"}
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        if not text:
            return {"ok": False, "error": "no readable text in this file "
                    "(scanned images cannot be read)"}
        return {"ok": True, "chars": len(text), "text": text[:max_chars],
                "truncated": len(text) > max_chars}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# --- ALKIFAH-FIX-UPLOADED-ONLY (installed by ALKIFAH_FIXES) begin ------------------------------
def _alk_norm(s) -> str:
    """Case/space/underscore-insensitive key, so a file called 'Cell_Cycle' matches
    the platform title 'Cell Cycle SRL Lesson'."""
    s = re.sub(r"\s*\(\d+\)\s*$", "", str(s).strip().casefold())
    s = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "-", s)
    return s.strip("-")


def _alk_segments(s) -> list:
    """Split an LMS item title on its ' - ' separators (not on hyphens in words)."""
    return [x.strip() for x in re.split(r"\s+-\s+", str(s).strip()) if x.strip()]


def _alk_uploaded(cfg: dict) -> dict:
    """What the platform already has, straight from the uploader's own log."""
    log = load_json(scripts_dir(cfg) / "uploaded_log.json", {}) or {}
    titles, stems = set(), set()
    for key in log:
        t = _alk_norm(key)
        if not t:
            continue
        titles.add(t)
        seg = _alk_segments(key)
        if len(seg) >= 3:                      # 'Week 1 - Session 02 - <lesson title>'
            stems.add(_alk_norm(seg[-1]))
    return {"titles": titles, "stems": stems, "count": len(titles)}


def _alk_title_of(pdf: Path, root: Path) -> str:
    """Rebuild the LMS item title from the folder layout (same rule as the uploader)."""
    week = session = None
    for part in pdf.relative_to(root).parts[:-1]:
        if week is None:
            week = num(part)
        if session is None:
            session = session_number(part)
    stem = re.sub(r"(?i)^\s*week\s*\d+\s*-?\s*session\s*\d+\s*-?\s*", "", pdf.stem)
    stem = re.sub(r"(?i)^\s*week\s*\d+\s*-?\s*", "", stem)
    if week and session:
        return "Week %s - Session %02d - %s" % (week, session, stem)
    if week:
        return "Week %s - %s" % (week, stem)
    return pdf.stem


def lesson_pdfs(cfg: dict) -> list:
    """Files offered to the assessment / homework maker.

    ALKIFAH-FIX-UPLOADED-ONLY: only lessons that are ALREADY on the platform (uploaded_log.json) are
    offered, so the AI never writes questions from a draft the students have not seen.
    Generated homework sheets are never offered as lessons. When the log is empty
    (brand-new install) nothing is hidden, so the tool can never be left unusable.
    """
    root = Path(cfg["term_folder"])
    if not root.exists():
        return []
    up = _alk_uploaded(cfg)
    gate = up["count"] > 0
    out = []
    for p in sorted(root.rglob("*.pdf")):
        low = (str(p.parent) + " " + p.stem).lower()
        if "booklet" in low or "model answer" in low or "homework" in low:
            continue
        title = _alk_title_of(p, root)
        seg = _alk_segments(title)
        stem_n = _alk_norm(seg[-1]) if seg else _alk_norm(p.stem)
        n = _alk_norm(title)
        on_lms = ((not gate) or n in up["titles"] or stem_n in up["titles"]
                  or stem_n in up["stems"])
        if gate and not on_lms:
            continue
        out.append({"path": str(p), "name": p.name,
                    "folder": str(p.parent.relative_to(root)),
                    "size": human_size(p.stat().st_size), "on_lms": True})
    return out
# --- ALKIFAH-FIX-UPLOADED-ONLY end ----------------------------------------------------------------


# --------------------------------------------------------------------------- install
def install_pack(cfg: dict, target: str | None = None) -> dict:
    target_dir = Path(target or cfg["install_dir"])
    if not TEMPLATE_DIR.exists():
        return {"ok": False, "error": "pack_template/ is missing - run build_pack.py"}
    written, skipped = [], []
    for src in sorted(TEMPLATE_DIR.rglob("*")):
        if not src.is_file():
            continue
        rel = src.relative_to(TEMPLATE_DIR)
        dst = target_dir / rel
        if dst.exists() and rel.as_posix() not in ("specs/_TEMPLATE_5_MCQ.json",):
            skipped.append(rel.as_posix())
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        written.append(rel.as_posix())
    if str(target_dir) != cfg["install_dir"]:
        cfg = save_config({"install_dir": str(target_dir)})
    return {"ok": True, "target": str(target_dir), "written": written,
            "skipped": skipped, "status": pack_status(cfg)}


# --------------------------------------------------------------------------- schedules
SCHEDULE_ROWS = [
    {"id": "materials", "when_en": "Every day 07:00", "when_ar": "كل يوم ٧:٠٠ ص",
     "cron": "0 7 * * *",
     "cmd": 'python "{scripts}\\upload_materials.py" auto',
     "name_en": "Every day at 7:00 AM upload new LMS materials",
     "name_ar": "كل يوم ٧ صباحاً — رفع مواد LMS الجديدة",
     "task": "LMS Auto Upload", "sc": "/SC DAILY /ST 07:00"},
    {"id": "assessment", "when_en": "Sun-Thu 08:00", "when_ar": "الأحد–الخميس ٨:٠٠ ص",
     "cron": "0 8 * * 0-4",
     "cmd": 'python "{scripts}\\create_assessment.py" "{specs}\\<today>.json"',
     "name_en": "Every school day 8:00 AM make the assessment",
     "name_ar": "كل يوم دراسي ٨ صباحاً — إنشاء التقييم",
     "task": "LMS Assessment", "sc": "/SC WEEKLY /D SUN,MON,TUE,WED,THU /ST 08:00"},
    {"id": "booklet", "when_en": "Sunday 07:00", "when_ar": "الأحد ٧:٠٠ ص",
     "cron": "0 7 * * 0",
     "cmd": 'python "{scripts}\\upload_booklet.py" auto',
     "name_en": "Every Sunday 7:00 AM upload the weekly booklet",
     "name_ar": "كل أحد ٧ صباحاً — رفع كتيّب الأسبوع",
     "task": "LMS Booklet", "sc": "/SC WEEKLY /D SUN /ST 07:00"},
    {"id": "answer", "when_en": "Thursday 12:30", "when_ar": "الخميس ١٢:٣٠ م",
     "cron": "30 12 * * 4",
     "cmd": 'python "{scripts}\\upload_booklet.py" answer',
     "name_en": "Every Thursday 12:30 PM upload the booklet model answer",
     "name_ar": "كل خميس ١٢:٣٠ ظهراً — رفع نموذج الإجابة",
     "task": "LMS Model Answer", "sc": "/SC WEEKLY /D THU /ST 12:30"},
]


def schedules(cfg: dict) -> list:
    scripts = str(scripts_dir(cfg))
    specs = str(specs_dir(cfg))
    py = cfg.get("python_exe") or "python"
    out = []
    sep = "\\" if sys.platform.startswith("win") else "/"
    for row in SCHEDULE_ROWS:
        cmd = row["cmd"].replace("\\", sep).format(scripts=scripts, specs=specs)
        if py not in ("python", "python.exe"):
            cmd = cmd.replace("python ", f'"{py}" ', 1)
        task_cmd = cmd.replace('"', '\\"')
        out.append({
            "id": row["id"], "cron": row["cron"], "command": cmd,
            "when_en": row["when_en"], "when_ar": row["when_ar"],
            "name_en": row["name_en"], "name_ar": row["name_ar"],
            "schtasks": f'schtasks /Create {row["sc"]} /TN "{row["task"]}" /TR "{task_cmd}"',
            "zcode": (f'name: {row["name_en"]}\n'
                      f'schedule: {row["cron"]}\n'
                      f'command: {cmd}'),
        })
    return out


def schedule_bat(cfg: dict) -> str:
    lines = ["@echo off",
             "REM Run this file in an ADMIN Command Prompt to register the four tasks.",
             "REM Generated by the LMS Automation web app.",
             ""]
    for row in schedules(cfg):
        lines.append(f"REM {row['name_en']}")
        lines.append(row["schtasks"])
        lines.append("")
    lines.append("echo Done. Open Task Scheduler to verify the four tasks.")
    lines.append("pause")
    return "\r\n".join(lines) + "\r\n"


# --------------------------------------------------------------------------- runner
class Run:
    def __init__(self, kind: str, argv: list, cwd: str, env_extra: dict, confirm: bool):
        self.id = uuid.uuid4().hex[:12]
        self.kind = kind
        self.argv = argv
        self.cwd = cwd
        self.env_extra = env_extra
        self.confirm = confirm
        self.lines: list[str] = []
        self.status = "starting"      # starting | running | done | failed | killed
        self.exit_code = None
        self.started = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.finished = None
        self.process: subprocess.Popen | None = None
        self._lock = threading.Lock()

    def add(self, line: str) -> None:
        with self._lock:
            self.lines.append(line.rstrip("\r\n"))
            if len(self.lines) > 4000:
                del self.lines[:1000]

    def tail(self, since: int = 0) -> dict:
        with self._lock:
            lines = self.lines[since:]
            total = len(self.lines)
        return {"id": self.id, "status": self.status, "exit_code": self.exit_code,
                "lines": lines, "next": total, "command": self.display(),
                "started": self.started, "finished": self.finished,
                "confirmed": self.confirm}

    def display(self) -> str:
        return " ".join(f'"{a}"' if " " in a else a for a in self.argv)


class RunManager:
    def __init__(self):
        self.runs: dict[str, Run] = {}
        self.order: list[str] = []
        self._lock = threading.Lock()

    def start(self, kind: str, argv: list, cwd: Path, env_extra: dict,
              confirm: bool) -> Run:
        run = Run(kind, argv, str(cwd), env_extra, confirm)
        with self._lock:
            self.runs[run.id] = run
            self.order.insert(0, run.id)
            self.order = self.order[:50]
        thread = threading.Thread(target=self._pump, args=(run,), daemon=True)
        thread.start()
        return run

    def _pump(self, run: Run) -> None:
        env = dict(os.environ)
        env.update({k: v for k, v in run.env_extra.items() if v})
        env.setdefault("PYTHONUNBUFFERED", "1")
        run.add(f"$ {run.display()}")
        run.add(f"  (working folder: {run.cwd})")
        run.add("")
        try:
            proc = subprocess.Popen(
                run.argv, cwd=run.cwd, env=env, stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                text=True, bufsize=1, encoding="utf-8", errors="replace")
        except FileNotFoundError as e:
            run.status = "failed"
            run.exit_code = -1
            run.add(f"cannot start: {e}")
            run.finished = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            return
        run.process = proc
        run.status = "running"
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                run.add(line)
        finally:
            code = proc.wait()
            run.exit_code = code
            if run.status != "killed":
                run.status = "done" if code == 0 else "failed"
            run.finished = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self._persist(run)

    def _persist(self, run: Run) -> None:
        try:
            data = load_json(RUNS_PATH, [])
            data.insert(0, {"id": run.id, "kind": run.kind, "command": run.display(),
                            "status": run.status, "exit_code": run.exit_code,
                            "started": run.started, "finished": run.finished,
                            "confirmed": run.confirm})
            RUNS_PATH.write_text(json.dumps(data[:60], indent=2), encoding="utf-8")
        except Exception:
            pass

    def active_of_kind(self, kind: str) -> "Run | None":
        """v6.2: return the still-running run of the same kind, if any."""
        for rid in self.order:
            r = self.runs.get(rid)
            if r and r.kind == kind and r.status in ("starting", "running"):
                return r
        return None

    def get(self, run_id: str) -> Run | None:
        return self.runs.get(run_id)

    def kill(self, run_id: str) -> dict:
        run = self.runs.get(run_id)
        if not run or not run.process:
            return {"ok": False, "error": "no such run"}
        run.status = "killed"
        try:
            run.process.terminate()
        except Exception as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True}

    def history(self) -> list:
        return load_json(RUNS_PATH, [])


MANAGER = RunManager()


def start_run_safely(kind: str, argv: list, cwd: Path, env_extra: dict,
                     confirm: bool) -> dict:
    """v6.2 FIX (duplicate uploads): starting the same task twice ran two Playwright
    sessions in parallel; both read the same log, both saw the same files as "new" and
    both uploaded them (a real duplicate happened on the LMS: Week 4 material uploaded
    at 08:13 and again at 08:14). Now a second start of the same kind while one is
    still running is refused with a clear message instead."""
    busy = MANAGER.active_of_kind(kind)
    if busy:
        return {"ok": False,
                "error": (f"There is already a '{kind}' task running (started "
                          f"{busy.started}). Wait for it to finish before starting "
                          f"another one — running two at the same time causes "
                          f"duplicate uploads. في مهمة شغّالة بالفعل من نفس النوع — "
                          f"استنى انتهاءها قبل ما تبدأ واحدة جديدة.")}
    return {"ok": True, "run": MANAGER.start(kind, argv, cwd, env_extra, confirm)}


# --------------------------------------------------------------------------- command building
def build_command(cfg: dict, kind: str, action: str, opts: dict) -> dict:
    """Return {'argv': [...], 'env': {...}, 'needs_confirm': bool, 'warnings': [...]}."""
    scripts = scripts_dir(cfg)
    warnings = []
    if kind == "materials":
        argv = [cfg["python_exe"], str(scripts / SCRIPTS["materials"])]
        if action == "scan":
            return {"argv": [], "env": {}, "needs_confirm": False, "warnings": [],
                    "dry": True}
        argv.append("auto")
        if opts.get("no_pdf"):
            argv.append("--no-pdf")
        if opts.get("limit"):
            argv += ["--limit", str(int(opts["limit"]))]
        if opts.get("show"):
            argv.append("--show")
        if not opts.get("no_pdf"):
            warnings.append("PowerPoint must be installed for the PPT->PDF step; "
                            "use --no-pdf if it is not.")
        env = {"LMS_FOLDER": cfg["term_folder"], "LMS_COURSE": cfg.get("course", ""),
               "LMS_CLASSES": cfg.get("classes", ""),
               "LMS_MINUTES_AHEAD": str(int(cfg.get("publish_minutes") or 5)),
               "LMS_FORCE_TITLES": str(cfg.get("reupload") or "")}
        return {"argv": argv, "env": env, "needs_confirm": True, "warnings": warnings}

    if kind == "booklet":
        argv = [cfg["python_exe"], str(scripts / SCRIPTS["booklet"])]
        mode = action if action in ("auto", "answer", "status", "file") else "status"
        if mode == "file":
            path = opts.get("file_path", "")
            title = opts.get("file_title", "")
            if not path or not title:
                return {"argv": [], "env": {}, "needs_confirm": False,
                        "error": "file mode needs a PDF path and a title"}
            argv += ["file", path, title]
        else:
            argv.append(mode)
        if opts.get("limit") and mode in ("auto", "answer"):
            argv += ["--limit", str(int(opts["limit"]))]
        if opts.get("respect_sunday"):
            argv.append("--respect-sunday-rule")
        if opts.get("show"):
            argv.append("--show")
        if opts.get("yes"):
            argv.append("--yes")   # ignored by the script; kept out below
            argv = [a for a in argv if a != "--yes"]
        env = {"LMS_FOLDER": cfg["booklet_folder"], "LMS_COURSE": cfg.get("course", ""),
               "LMS_CLASSES": cfg.get("classes", ""),
               "LMS_MINUTES_AHEAD": str(int(cfg.get("publish_minutes") or 5))}
        return {"argv": argv, "env": env, "needs_confirm": mode != "status",
                "warnings": warnings}

    if kind == "assessment":
        spec = opts.get("spec", "")
        if not spec:
            return {"argv": [], "env": {}, "needs_confirm": False,
                    "error": "choose a spec JSON first"}
        spec_path = spec if Path(spec).is_absolute() else str(specs_dir(cfg) / spec)
        argv = [cfg["python_exe"], str(scripts / SCRIPTS["assessment"]), spec_path]
        if opts.get("dry_run"):
            argv.append("--dry-run")
        if opts.get("resume"):
            argv += ["--resume", str(opts["resume"])]
        if opts.get("show"):
            argv.append("--show")
        return {"argv": argv, "env": _alk_timing_env(cfg),   # ALKIFAH-FIX-CONVENTIONS
                "needs_confirm": not opts.get("dry_run"), "warnings": warnings}

    if kind == "login":
        nologin = str(Path(cfg["install_dir"]) / "scripts" / "check_login.py")
        argv = [cfg["python_exe"], nologin]
        if opts.get("show"):
            argv.append("--show")
        return {"argv": argv, "env": {}, "needs_confirm": False, "warnings": []}

    if kind == "assign":
        ids = str(opts.get("exam_ids", "")).replace(",", " ").split()
        if not ids:
            return {"argv": [], "env": {}, "needs_confirm": False,
                    "error": "give at least one exam id"}
        argv = [cfg["python_exe"], str(scripts / SCRIPTS["assign"]), *ids]
        if opts.get("show"):
            argv.append("--show")
        return {"argv": argv, "env": _alk_timing_env(cfg),   # ALKIFAH-FIX-CONVENTIONS
                "needs_confirm": True, "warnings": warnings}

    return {"argv": [], "env": {}, "needs_confirm": False, "error": "unknown kind"}


def run_action(cfg: dict, kind: str, action: str, opts: dict, confirmed: bool) -> dict:
    built = build_command(cfg, kind, action, opts)
    if built.get("error"):
        return {"ok": False, "error": built["error"]}
    if built.get("dry"):
        return {"ok": True, "dry": True}
    if built["needs_confirm"] and not confirmed:
        return {"ok": False, "needs_confirm": True, "command": " ".join(built["argv"])}
    if not built["argv"]:
        return {"ok": False, "error": "nothing to run"}

    # credentials + folders of the active teacher profile are injected for this run only;
    # the password is never written into any script or log file.
    prof = cfg.get("profile") if "profile" in cfg else profiles.active()
    env = dict(built.get("env") or {})
    if prof:
        env.update(profiles.env_for(prof))
        if not env.get("LMS_FOLDER"):
            env["LMS_FOLDER"] = (cfg.get("booklet_folder") if kind == "booklet"
                                 else cfg.get("term_folder")) or ""
        if prof.get("course"):
            env.setdefault("LMS_COURSE", prof["course"])
        if prof.get("classes"):
            env.setdefault("LMS_CLASSES", prof["classes"])
    built["env"] = {k: v for k, v in env.items() if v}
    warnings = list(built.get("warnings") or [])

    script = Path(built["argv"][1])
    if not script.exists():
        return {"ok": False, "error": f"script not found: {script} "
                                      f"(install the pack first, or fix the install folder)"}
    missing = [k for k in ("LMS_USERNAME", "LMS_PASSWORD") if not built["env"].get(k)]
    needs_login = not (kind == "assessment" and opts.get("dry_run"))
    if missing and needs_login:
        return {"ok": False, "needs_profile": True,
                "error": "This needs the teacher account first: open the name button at the "
                         "top of the page and save the LMS email and password (or set "
                         + " and ".join(missing) + " with setx)."} 
    started = start_run_safely(kind, built["argv"], script.parent, built["env"],
                               confirmed)          # v6.2: refuse concurrent same-kind runs
    if not started.get("ok"):
        return {"ok": False, "error": started.get("error"),
                "busy_kind": kind}
    run = started["run"]
    return {"ok": True, "run": run.tail(0), "warnings": warnings,
            "command": run.display()}


def dashboard(cfg: dict) -> dict:
    status = pack_status(cfg)
    fixes = verify_fixes(cfg)
    logs = logs_overview(cfg)
    materials = scan_materials(cfg)
    booklets = scan_booklets(cfg)
    return {
        "config": cfg,
        "pack": status,
        "fixes": fixes,
        "env": env_status(cfg),
        "profile": profiles.summary(),
        "profiles": profiles.list_profiles(),
        "counts": {
            "materials_uploaded": len(logs["uploaded_log.json"] or {}),
            "assessments": len(logs["assessment_log.json"] or {}),
            "booklets": len([k for k in (logs["booklet_log.json"] or {}) if "Model Answer" not in k]),
            "answers": len([k for k in (logs["booklet_log.json"] or {}) if "Model Answer" in k]),
            "materials_pending": materials.get("new", 0),
            "booklets_pending": (len(booklets.get("missing_booklets", [])) +
                                 len(booklets.get("missing_answers", []))),
        },
        "latest_lesson": latest_lesson(cfg),
        "last_report": (logs["upload_report.txt"] or "").splitlines()[-6:],
        "materials_error": materials.get("error"),
        "booklets_error": booklets.get("error"),
        "now": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
