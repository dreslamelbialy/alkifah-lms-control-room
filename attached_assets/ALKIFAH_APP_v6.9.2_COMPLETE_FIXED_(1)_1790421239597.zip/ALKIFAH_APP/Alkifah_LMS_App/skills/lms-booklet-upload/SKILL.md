---
name: lms-booklet-upload
description: Upload weekly booklet assessments and their model answers from
  First Term\Booklet to the Alkifah LMS as Materials. Use whenever the user mentions
  booklets, booklet uploads, model answers, Sunday booklet upload, Thursday model answer,
  or asks what booklets are uploaded or missing.
---

## LMS Booklet Upload (v2, fixed)

Uploads the weekly booklet (student version) and its model answer to the LMS as Materials
for Science 3 - Grade 9, all classes (G9A/G9B/G9C).

### What changed in v2 (fixes)

- **Login bug fixed** — the original `upload_booklet.py` did
  `page.fill("#passwordInput", PASSWORD)` but the login form uses `#Input_Password`.
  Login would time out. v2 uses `fill_first()` with multiple candidate selectors.
- The misleading "Week 3 not uploaded until its Sunday" rule was claimed in SKILL.md but
  never enforced in code. v2 adds an explicit `--respect-sunday-rule` flag (off by
  default) so the behaviour actually matches the documentation.
- `--show` flag to debug in a visible browser.
- `--limit N` (default 1) controls how many booklets/answers to upload per run.
- Env-var credential overrides (`LMS_USERNAME`, `LMS_PASSWORD`, `LMS_FOLDER`).
- `mode_answer` rewritten — the original only ever uploaded the answer of the newest
  booklet week, silently skipping any older week whose answer was missing. v2 iterates
  from newest to oldest so missing answers are filled in order, up to `--limit`.
- Better progress reporting when there's nothing to do.

### Canonical script

    D:\Alkifah academy\2026-2027\LMS Booklet Upload\scripts\upload_booklet.py

Log: `booklet_log.json` next to it. Booklet PDFs live in

    D:\Alkifah academy\2026-2027\First Term\Booklet\

with EXACT names: `Week N booklet.pdf`, `Week N booklet (Model Answer).pdf`,
`Orientation booklet.pdf` (week 0). No trailing spaces.

### Modes

- `python <script> auto` — uploads the next not-yet-uploaded booklet in week order as
  Material "Week N Booklet Assessment" (Sunday 07:00 automation runs this).
- `python <script> answer` — uploads the model answer of the newest booklet that has one
  missing, as Material "Week N Booklet Model Answer" (Thursday 12:30 automation runs
  this).
- `python <script> status` — completeness sweep: prints every booklet/answer and whether
  it is uploaded; report missing ones to the user.
- `python <script> file "<pdf path>" "<title>"` — one-off manual upload.
- Add `--show` to any mode to see the browser.
- Add `--limit N` to `auto` / `answer` to upload up to N items per run.

Scheduled runs are headless; each run logs in, opens Materials → Create directly, fills
title/description/course/classes, attaches the PDF, sets publish ~5 min ahead, saves, and
records ONLY confirmed saves in `booklet_log.json`. Retries twice on failure and exits
non-zero with the reason.

### When invoked manually

1. Run `status` first and tell the user what is uploaded/missing.
2. Then run `auto` and/or `answer` per the user's request.
3. To force a re-upload, delete its line from `booklet_log.json` and re-run the mode.

### Rules

- Only ever upload files from the Booklet folder (or a path the user explicitly gave).
- Week 3 booklet is intentionally NOT uploaded until its Sunday arrives — but ONLY when
  you pass `--respect-sunday-rule`. By default the script will upload whatever is next in
  week order, so the schedule (Sunday 07:00) is what guarantees the timing.
- **Never create exams/homework with this skill — materials only.**
- LMS limit: 25 MB per file.
