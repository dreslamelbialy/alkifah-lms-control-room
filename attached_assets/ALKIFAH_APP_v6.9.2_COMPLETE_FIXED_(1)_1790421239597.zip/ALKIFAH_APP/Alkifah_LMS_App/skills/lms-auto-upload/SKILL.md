---
name: lms-auto-upload
description: Upload new PowerPoint lesson materials from a watched folder to the Alkifah
  Academy LMS (lms.alkifah.edu.sa) Materials section, converting them to PDF first,
  skipping already-uploaded lessons, and writing a report. Use whenever the user asks to
  upload materials/lessons to the LMS, run the material uploader, schedule daily material
  uploads, or asks what was uploaded (check the report).
---

## LMS Auto Upload (v5, fixed)

Automates uploading lesson PowerPoints to the Alkifah Academy LMS "Materials" section.

### What changed in v5 (fixes)

- No more hardcoded `PREVIOUSLY_UPLOADED` list — the upload log (`uploaded_log.json`) is
  now the single source of truth. The old list duplicated entries that already lived in
  the log and was easy to forget when adding new lessons.
- Env-var overrides for `LMS_USERNAME`, `LMS_PASSWORD`, `LMS_FOLDER`, `LMS_COURSE`,
  `LMS_CLASSES` so secrets don't have to live inside the .py file.
- `--show` flag forces a visible browser for local debugging.
- `--no-pdf` flag uploads the .pptx as-is if PowerPoint conversion is failing.
- `--limit N` only uploads the first N new items per run.
- PowerPoint COM fallback removed — the old code fell back to opening the file WITH a
  visible window when `WithWindow=False` failed, which broke headless scheduled runs.
  Now it raises a clear error with the HRESULT so you can decide.
- Numbered-pagination fallback in `check_repetition` (not just "Next" link) — some LMS
  installs render numbered pagination only.
- Removed the `n = radios.count()` shadowing bug — that was in `create_assessment.py`
  (also fixed there).

### How it works

`scripts/upload_materials.py` does everything:

1. Scans the watched folder (`FOLDER` in SETTINGS) for `Week*` sub-folders, unzips any
   ZIPs, and finds all `.pptx` / `.ppt` files.
2. Names each one `Week N - Session NN - <file name>` based on its folder.
3. Converts each to PDF with the installed Microsoft PowerPoint (skips files already
   converted).
4. Logs into `https://lms.alkifah.edu.sa`, opens Materials → Create, fills
   title/description, selects the course and classes, sets publish time ~5 minutes ahead,
   attaches the PDF, saves.
5. Duplicate check before every run: reads the full Materials list from the LMS (all
   pages, "Next" link or numbered pagination) and skips any lesson already online — even
   if `uploaded_log.json` lost its entry.
6. Records every confirmed upload in `scripts/uploaded_log.json` and skips those titles
   forever. Writes `scripts/upload_report.txt` after every run.

### Running it

Scheduled / daily (no questions asked, invisible browser):

    python "<path>\scripts\upload_materials.py" auto

Manual (shows the browser, asks ALL or pick numbers):

    python "<path>\scripts\upload_materials.py"

Show the browser even in auto mode:

    python "<path>\scripts\upload_materials.py" auto --show

Upload only the first 2 new items (rate-limited runs):

    python "<path>\scripts\upload_materials.py" auto --limit 2

Skip PowerPoint conversion (troubleshooting):

    python "<path>\scripts\upload_materials.py" auto --no-pdf

The script prints progress and exits 0 on success. After any run, read
`upload_report.txt` next to the script and summarize it for the user (uploaded OK /
skipped / failed with reasons).

### First-time setup (new laptop)

1. Install Python 3.10+ and Microsoft PowerPoint (needed for PPT→PDF).
2. `pip install playwright comtypes` then `playwright install chromium`.
3. Open the script in Notepad and edit only the SETTINGS block: `FOLDER`, `COURSE`,
   `CLASSES`, `USERNAME`, `PASSWORD`.
4. (Recommended) Set env vars instead of editing the script:

       setx LMS_USERNAME "your.email@alkifahacademy.edu.sa"
       setx LMS_PASSWORD "your-password"
       setx LMS_FOLDER "D:\Alkifah academy\2026-2027\First Term"

5. Run once manually to test before scheduling.

### Daily schedule

- ZCode automation: a Cron automation named "Every day at 7:00 AM upload new LMS
  materials" runs the script with `auto` and reports the result. Recreate it with cron
  `0 7 * * *`.
- Windows Task Scheduler (no ZCode needed):

      schtasks /Create /SC DAILY /ST 07:00 /TN "LMS Auto Upload" /TR "python \"<path>\scripts\upload_materials.py\" auto"

### Rules and limits

- LMS limit: max 25 MB per file, max 5 files — bigger files are reported as SKIPPED
  (compress or split them first, or run with `--no-pdf`).
- Only upload from the configured FOLDER. **Never create exams, homework, classworks, or
  projects with this skill — materials only.**
- To force re-uploading a lesson, delete its line from `scripts/uploaded_log.json`.
- Failed items are retried automatically on the next run.
