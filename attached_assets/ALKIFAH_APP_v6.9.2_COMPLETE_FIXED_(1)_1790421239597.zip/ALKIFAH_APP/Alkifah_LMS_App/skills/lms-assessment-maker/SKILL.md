---
name: lms-assessment-maker
description: Create the daily electronic assessment on the Alkifah LMS — 5 MCQ questions
  (1 mark each) written from the latest uploaded lesson's PPT content, exam titled
  "<lesson> assessment". Use whenever the user asks to make the assessment, today's
  assessment, lesson assessment, daily MCQs, or electronic exam for the latest lesson.
---

## LMS Assessment Maker (v2, fixed)

Creates one electronic exam per lesson on `lms.alkifah.edu.sa`: 5 multiple-choice
questions, 1 mark each (total 5.0), questions WRITTEN BY THE AGENT strictly from the
lesson PPT's content, typed manually into the LMS question form (never a file
import/upload of the questions).

### What changed in v2 (fixes)

- **Login bug fixed** — the original `create_assessment.py` did
  `page.fill("#passwordInput", PASSWORD)` but the login form uses `#Input_Password`.
  Login would time out. v2 uses `fill_first()` with multiple candidate selectors (same
  pattern as `upload_materials.py`).
- **Variable shadowing fixed** — the original had `n = radios.count()` inside `add_mcq`,
  which overwrote the `n` parameter (the question index). Renamed to `radio_count`.
- **Verification bug fixed** — the original did `ok = ("5" in body)` and
  `("5.0" in body or "5.00" in body or "5.00" in body)` which is way too loose (any "5"
  character passes) AND had a duplicate `"5.00"`. v2 parses `Questions Count: N` and
  `Total Mark: N.N` with regex.
- **Per-question retry** — a single failing question no longer aborts the whole exam.
  Each question is retried up to 2 times, then reported as failed; the script continues
  and the failed question numbers are saved in the log so you can re-run with
  `--resume`.
- **Status + assignment step made robust** — the inline code in the original used
  `el.checked` on toggle IDs that may not actually be checkboxes (some are buttons). v2
  uses the same `btnChangeStatus` / `btnDisplayResult` / ... pattern, but verifies the
  assignment toast appeared.
- `--show` flag to debug in a visible browser.
- `--dry-run` flag loads the spec and prints the plan without touching the LMS.
- Env-var credential overrides (`LMS_USERNAME`, `LMS_PASSWORD`).

### Inputs and dedup (do these first, in order)

1. **Latest lesson**: read `D:\Alkifah academy\2026-2027\LMS Auto Upload\scripts\uploaded_log.json`
   and take the entry with the newest timestamp → lesson title like
   `Week 2 - Session 03 - Cell_Cycle_SRL_Lesson`.
2. **Dedup (hard rule)**: check
   `D:\Alkifah academy\2026-2027\LMS Assessment Maker\assessment_log.json` AND the LMS
   list at `/Assessments/Exams` (filter course Science 3). If an exam titled
   `<lesson> assessment` already exists → STOP and report "already exists".
3. **Materials actually uploaded?** If the lesson is NOT visible in
   `/CourseManagement/Materials`, run the materials uploader first
   (`python "...\LMS Auto Upload\scripts\upload_materials.py" auto`) and re-check.

### Question writing rules

1. Extract text from the lesson source first: find the matching file under
   `D:\Alkifah academy\2026-2027\First Term\Week*\` (`.pptx` via `python-pptx` is NOT
   installed — use `pymupdf` on the converted `.pdf` instead):

       python -c "import pymupdf,sys; d=pymupdf.open(r'<pdf>'); print('\n'.join(p.get_text() for p in d))"

2. Write exactly **5 MCQs**, each with 4 options (A–D) and exactly one correct answer,
   1 mark each (set Question Mark = 1; total 5.0).
3. Content must come ONLY from the lesson material — no outside facts, no NAFS-bank
   copying.
4. Mix levels: **3 Easy, 2 Medium** (the form's Choose Level: Easy/Medium/Hard).
5. Clear, unambiguous stems; plausible distractors taken from common misconceptions in
   the lesson.

### LMS steps (browser)

1. Go to `/Assessments/Exams/Create`. Fill: Course = the option starting with
   "Science 3", Exam Title = `<Lesson Title> assessment`, Duration = 10, Exam Type =
   Quiz (or Homework if that's what the existing exams use). Click Save.
2. Open the new exam's Add Questions page, click Add Question → choose Full Question →
   in the form click Add Question → choose **Multiple Choice**.
3. Per question: Choose Level, Question Mark = 1, question text into the second TinyMCE
   editor (editors are iframes — use `tinymce.editors` via `page.evaluate` in Playwright;
   editor order = creation order: `[0]` header, `[1]` question), fill option Text boxes,
   tick **Correct** on the right one, use **Add Option** to reach 4 options, then
   **Save Question**. Repeat for all 5.
4. Verify the exam shows `Questions Count = 5` and `Total Mark = 5.0`.

### Status + assignment (automatic, on the exam Details page)

After the questions are saved the script applies, on the Details page:

- **Status toggles**: Active ON, Show Exam Result ON, Shuffle Question ON, Shuffle Answer
  ON, Allow Practice ON; Available-on-mobile-only OFF, Other-teachers-edit OFF, Public
  OFF.
- **Assign Student/Class**: radio All Students, classes G9A, G9B, G9C selected, then
  click Assign Exam.
- The teacher sets the Exam Start/End dates manually on each exam's Details page (the
  automation leaves dates empty on purpose). Header of every question is "choose the
  correct answer" (required field).

### Logging

Append to `D:\Alkifah academy\2026-2027\LMS Assessment Maker\assessment_log.json`:

    {
      "<Lesson Title> assessment": {
        "date": "<YYYY-MM-DD HH:MM>",
        "exam_url": "<details url>",
        "verified": true,
        "assigned": true,
        "failed_questions": [],
        "questions": ["q1", "q2", "q3", "q4", "q5"]
      }
    }

If any step fails, report the exact failure and do NOT log it.

### Running it

- Full flow: `python "...\create_assessment.py" "<spec.json>"`
- Resume an exam (re-add only failed questions):
  `python "...\create_assessment.py" "<spec.json>" --resume <examId>`
- Visible browser: add `--show`
- Dry run (no LMS): `python "...\create_assessment.py" "<spec.json>" --dry-run`
- After the assessment is created, you can also re-apply just the status/assignment step
  with `python "...\assign_exam.py" <examId>`.

### Schedule

Sun–Thu 08:00 automation runs this flow (after the 07:00 materials upload). Manual runs:
user asks "make today's assessment" (or names a specific lesson — then use that lesson
instead of the latest).


---

## Academy conventions (set by ALKIFAH_FIXES — change them in config.json)

- An assessment is **named after its lesson**: `<Lesson> assessment`. If the title box is
  still empty when the app checks it, the name is filled from the lesson automatically, so
  files on the platform and in the app carry the same words.
- **5 questions, all Easy** — `"level_mix": {"Easy": 5}` in config.json. The local relay is
  also told `AI_LEVEL = easy`, so the model writes recall questions instead of mixing levels.
- On the platform an assessment **opens 5 minutes after it is created** and **closes 2
  calendar months later** (`LMS_OPEN_MINUTES`, `LMS_CLOSE_MONTHS`, `LMS_CLOSE_DAYS`).
- **Homework needs no sheet from you.** When a homework spec has no sheet file, the app
  prints the student sheet and the model-answer key itself from the same questions.
- Deletions are followed: `python alkifah_upload.py --sync` removes anything that is gone
  from the tracking log, so re-uploading keeps the SAME name instead of creating " (2)".
