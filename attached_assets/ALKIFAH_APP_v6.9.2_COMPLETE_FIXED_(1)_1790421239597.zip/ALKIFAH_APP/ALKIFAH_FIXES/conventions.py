#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
conventions.py — the academy's own rules, applied to the editable python side of the app.

Four things the teacher asked for, none of which needs rebuilding the compiled app:

  1. an assessment is always NAMED AFTER ITS LESSON   ("<Lesson> assessment"),
     so "title is empty" cannot happen and names stop drifting.
  2. on the platform it OPENS 5 minutes after creation and CLOSES 2 calendar months
     later (both are env knobs, not numbers welded into the code).
  3. the difficulty rule is 5 questions, ALL EASY - read from config.json, and the
     local relay tells the model so as well (AI_LEVEL = easy).
  4. HOMEWORK: if the homework has no sheet file, the AI makes the printable sheet
     from the questions that are already in the spec. She never builds one by hand.

Every touched file gets a .bak-DATE copy first (apply_fixes.py restores them on --revert).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

MARK_CONV = "ALKIFAH-FIX-CONVENTIONS"
SKILL_MARKER = "ALKIFAH_FIXES"

# ------------------------------------------------------------------ inserted into pack.py
CONV_PACK_HELPERS = r'''
# --- ALKIFAH-FIX-CONVENTIONS begin --------------------------------------------
# The academy's rules, all readable from config.json so they can change later
# without touching code again:
#    "level_mix"   : {"Easy": 5}   what a finished assessment should look like
#    "force_level" : "Easy"        how generated questions are labelled
def _alk_cfg_get(key, default=None):
    try:
        return (load_config() or {}).get(key, default)
    except Exception:
        return default


def _alk_clean(stem):
    # the platform already shows a lesson as "Week 1 - Session 03 - Cell Cycle",
    # so a generated name is written the same way - never with new wording
    stem = re.sub(r"\.(pdf|pptx?|docx?)$", "", str(stem), flags=re.I)
    stem = re.sub(r"[_\-\.]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    stem = re.sub(r"(?i)\bweeks?\s*(\d+)", lambda m: "Week " + m.group(1), stem)
    stem = re.sub(r"(?i)\bsessions?\s*(\d+)", lambda m: "Session " + m.group(1), stem)
    m = re.match(r"(?i)^Week (\d+) Session (\d+) (.+)$", stem)
    if m:
        stem = "Week %s - Session %s - %s" % (m.group(1), m.group(2), m.group(3))
    else:
        m = re.match(r"(?i)^Session (\d+) (.+)$", stem)
        if m:
            stem = "Session %s - %s" % (m.group(1), m.group(2))
    return stem


def _alk_lesson_name(spec):
    # the app does not store a path in the spec, so look for any hint of one and
    # fall back to the newest lesson the picker can see
    for key in ("lesson", "source_pdf", "pdf", "path", "file", "source", "lesson_path"):
        raw = str(spec.get(key) or "").strip()
        if raw:
            name = _alk_clean(Path(raw).stem)
            if name and "template" not in name.lower():
                return name
    try:                    # the upload log IS the platform's own record of the name
        cfg = load_config() or {}
        log = json.loads((Path(cfg.get("install_dir") or ".") / "scripts" /
                          "uploaded_log.json").read_text(encoding="utf-8"))
        dated = sorted((str(v or ""), str(t)) for t, v in (log or {}).items())
        if dated:
            return _alk_clean(dated[-1][1])      # the most recently uploaded lesson
    except Exception:
        pass
    try:                    # last resort: the newest lesson file the app can see
        for item in reversed(list(lesson_pdfs(load_config() or [])) or []):
            path = item.get("path") if isinstance(item, dict) else item
            name = _alk_clean(Path(str(path or "")).stem)
            if name:
                return name
    except Exception:
        pass
    return ""


def _alk_title(spec):
    # UNIFIED name (the teacher asked for one place, one name): whenever the lesson can
    # be identified, the assessment is called '<Week N - Session M - lesson> assessment'
    # - the same words the platform already uses for the material, so a re-run can never
    # create a second copy under a drifted name. A title typed by hand survives only
    # when nothing else can name the assessment.
    try:
        stem = _alk_lesson_name(spec)
        if stem:
            return stem if stem.lower().endswith("assessment") else stem + " assessment"
    except Exception:
        pass
    name = str(spec.get("title") or "").strip()
    if name:
        return name
    return ""


def _alk_timing_env(cfg):
    # what the platform should do with the dates: open a few minutes from now,
    # close a couple of months from now.  The script reads these env values.
    env = {}
    try:
        env["LMS_MINUTES_AHEAD"] = str(int((cfg or {}).get("publish_minutes") or 5))
    except Exception:
        env["LMS_MINUTES_AHEAD"] = "5"
    try:
        env["LMS_OPEN_MINUTES"] = env["LMS_MINUTES_AHEAD"]
    except Exception:
        pass
    try:
        env["LMS_CLOSE_MONTHS"] = str(int((cfg or {}).get("close_months") or 2))
    except Exception:
        env["LMS_CLOSE_MONTHS"] = "2"
    try:
        days = int((cfg or {}).get("close_days") or 0)
        if days > 0:                      # exact day count, if she ever wants one
            env["LMS_CLOSE_DAYS"] = str(days)
    except Exception:
        pass
    return env


def _alk_fix_spec(cfg, spec):
    # name it after the lesson, then keep the difficulty the academy asked for
    try:
        want = _alk_title(spec)           # ALKIFAH-FIX-CONVENTIONS: unified lesson name
        if want:
            spec["title"] = want
        want = ""
        if isinstance(cfg, dict):
            want = str(cfg.get("force_level") or "")
        want = want or str(_alk_cfg_get("force_level", "") or "")
        # only a MISSING level is filled in. A level that is there is left alone -
        # stamping "Easy" on a Medium question would only fool the checker, and the
        # panel would stop telling you the AI ignored the rule.
        if want:
            for q in spec.get("questions") or []:
                if isinstance(q, dict) and not str(q.get("level") or "").strip():
                    q["level"] = want.strip().capitalize()
    except Exception:
        pass
    return spec
# --- ALKIFAH-FIX-CONVENTIONS end ----------------------------------------------


'''

TITLE_OLD = '''    title = str(spec.get("title", "")).strip()
    if not title:
        problems.append("title is empty")'''

TITLE_NEW = '''    title = str(spec.get("title", "")).strip()
    want = _alk_title(spec)               # ALKIFAH-FIX-CONVENTIONS: one unified name
    if want and want != title:
        spec["title"] = want
        title = want
    if not title:
        problems.append("title is empty")'''

MIX_OLD = '''    if levels and (levels.get("Easy", 0) != 3 or levels.get("Medium", 0) != 2):
        warnings.append("the skill asks for 3 Easy + 2 Medium")'''

MIX_NEW = '''    want_mix = _alk_cfg_get("level_mix") or {"Easy": 5}   # ALKIFAH-FIX-CONVENTIONS
    if levels and isinstance(want_mix, dict) and want_mix:
        off = any(levels.get(k, 0) != v for k, v in want_mix.items())
        off = off or sum(levels.values()) != sum(want_mix.values())
        if off:
            warnings.append("the skill asks for " + " + ".join(
                "%d %s" % (v, k) for k, v in sorted(want_mix.items())))'''

MAT_ENV_OLD = """        if not opts.get("no_pdf"):
            warnings.append("PowerPoint must be installed for the PPT->PDF step; "
                            "use --no-pdf if it is not.")
        env = {"LMS_FOLDER": cfg["term_folder"], "LMS_COURSE": cfg.get("course", ""),
               "LMS_CLASSES": cfg.get("classes", ""),
               "LMS_MINUTES_AHEAD": str(int(cfg.get("publish_minutes") or 5))}"""

MAT_ENV_NEW = """        if not opts.get("no_pdf"):
            warnings.append("PowerPoint must be installed for the PPT->PDF step; "
                            "use --no-pdf if it is not.")
        env = {"LMS_FOLDER": cfg["term_folder"], "LMS_COURSE": cfg.get("course", ""),
               "LMS_CLASSES": cfg.get("classes", ""),
               "LMS_MINUTES_AHEAD": str(int(cfg.get("publish_minutes") or 5)),
               "LMS_FORCE_TITLES": str(cfg.get("reupload") or "")}"""

ASSESS_ENV_OLD = """        return {"argv": argv, "env": {},
                "needs_confirm": not opts.get("dry_run"), "warnings": warnings}"""

ASSESS_ENV_NEW = """        return {"argv": argv, "env": _alk_timing_env(cfg),   # ALKIFAH-FIX-CONVENTIONS
                "needs_confirm": not opts.get("dry_run"), "warnings": warnings}"""

ASSIGN_ENV_OLD = """        return {"argv": argv, "env": {}, "needs_confirm": True, "warnings": warnings}"""

ASSIGN_ENV_NEW = """        return {"argv": argv, "env": _alk_timing_env(cfg),   # ALKIFAH-FIX-CONVENTIONS
                "needs_confirm": True, "warnings": warnings}"""

SHEET_WARN_OLD = """        sheet = str(spec.get("sheet_path", "") or "").strip()
        if not sheet:
            warnings.append("homework without a sheet file — you will upload "
                            "the sheet manually from the platform")"""

SHEET_WARN_NEW = """        sheet = str(spec.get("sheet_path", "") or "").strip()
        if not sheet and not (APP_DIR / "homework_maker.py").exists():
            warnings.append("homework without a sheet file, and the sheet printer is "
                            "missing - run INSTALL_FIXES.bat once (it prints the sheet "
                            "from these questions by itself)")"""

SAVE_OLD = '''def save_spec(cfg: dict, spec: dict, filename: str) -> dict:
    name = Path(filename'''

SAVE_NEW = '''def save_spec(cfg: dict, spec: dict, filename: str) -> dict:
    spec = _alk_fix_spec(cfg, spec)       # ALKIFAH-FIX-CONVENTIONS: title + level
    name = Path(filename'''

# ------------------------------------------------------------------ assign_exam.py
CONV_ASSIGN_HELPERS = r'''
# --- ALKIFAH-FIX-CONVENTIONS begin --------------------------------------------
# When an assessment opens and when it closes on the platform.
#   LMS_OPEN_MINUTES (or LMS_MINUTES_AHEAD) : open N minutes after creation - default 5
#   LMS_CLOSE_MONTHS                       : stay open that many calendar months - default 2
#   LMS_CLOSE_DAYS                         : exact day count instead, if you prefer
def _alk_open_minutes():
    for key in ("LMS_OPEN_MINUTES", "LMS_MINUTES_AHEAD"):
        try:
            v = int(os.environ.get(key) or 0)
            if v > 0:
                return v
        except Exception:
            continue
    return 5


def _alk_close_date():
    import calendar
    now = datetime.now()
    try:
        days = int(os.environ.get("LMS_CLOSE_DAYS") or 0)
    except Exception:
        days = 0
    if days > 0:
        return now + timedelta(days=days)
    try:
        months = int(os.environ.get("LMS_CLOSE_MONTHS") or 2)
    except Exception:
        months = 2
    y = now.year + (now.month - 1 + months) // 12
    m = (now.month - 1 + months) % 12 + 1
    return now.replace(year=y, month=m, day=min(now.day, calendar.monthrange(y, m)[1]))
# --- ALKIFAH-FIX-CONVENTIONS end ----------------------------------------------


'''

OPEN_OLD = 'datetime.now() + timedelta(minutes=3)'
OPEN_NEW = 'datetime.now() + timedelta(minutes=_alk_open_minutes())'
CLOSE_OLD = 'datetime.now() + timedelta(days=14)'
CLOSE_NEW = '_alk_close_date()'

# ------------------------------------------------------------------ create_assessment.py
CONV_SHEET_HELPER = r'''
def _alk_ai_sheet(spec):
    """ALKIFAH-FIX-CONVENTIONS: no sheet chosen for a homework? The AI makes one from
    the questions already in this spec, so the teacher never builds a sheet by hand."""
    import subprocess
    import tempfile
    try:
        qs = spec.get("questions") or []
        if not qs:
            print("  sheet: this spec has no questions yet, so there is nothing to print.")
            return ""
        here = Path(__file__).resolve().parent
        maker = here.parent / "app" / "homework_maker.py"
        if not maker.exists():
            print("  sheet: homework_maker.py is missing - run INSTALL_FIXES.bat once.")
            return ""
        qf = Path(tempfile.gettempdir()) / "alkifah_homework_questions.json"
        qf.write_text(json.dumps(qs, ensure_ascii=False), encoding="utf-8")
        title = str(spec.get("title") or "Homework").strip() or "Homework"
        out_dir = Path(spec.get("homework_dir") or (here.parent / "First Term" / "Homework"))
        out_dir.mkdir(parents=True, exist_ok=True)
        cmd = [sys.executable, str(maker), "--from-json", str(qf), "--no-lesson",
               "--title", title, "--out", str(out_dir),
               "--lang", str(spec.get("lang") or "en")]
        print("  sheet: making it with the local AI now (no download, no cost)...")
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
        for line in (r.stdout or "").splitlines():
            if "student sheet" in line and ":" in line:
                found = line.split(":", 1)[1].strip().strip('"')
                if found and Path(found).exists():
                    return found
        made = sorted(out_dir.glob("* - Homework.pdf"), key=lambda q: q.stat().st_mtime)
        if made:
            return str(made[-1])
        print("  sheet: the maker returned no file (%s)"
              % ((r.stderr or r.stdout or "")[-200:]))
    except Exception as e:
        print("  sheet: could not make one automatically (%s) - attach it by hand if you want." % e)
    return ""


'''

SHEET_OLD = '''    sheet = str(spec.get("sheet_path", "") or "").strip()
    is_homework = str(exam_type).strip().casefold() == "homework"'''

SHEET_NEW = '''    sheet = str(spec.get("sheet_path", "") or "").strip()
    is_homework = str(exam_type).strip().casefold() == "homework"
    if is_homework and not sheet and not ARGS.resume:   # ALKIFAH-FIX-CONVENTIONS
        sheet = _alk_ai_sheet(spec)
        if sheet:
            spec["sheet_path"] = sheet'''

SYNC_HELPER = r"""
def _alk_sync_tracking():
    # ALKIFAH-FIX-CONVENTIONS: right before the app decides what counts as "new", let its
    # own tracker forget lessons that no longer exist on this laptop. That is what keeps
    # names identical after a deletion on the platform: no " (2)", no new wording.
    # Silent if anything is missing - it can never stop or break an upload.
    try:
        helper = Path(__file__).resolve().parent.parent / "app" / "alkifah_upload.py"
        if not helper.exists():
            return
        import subprocess
        r = subprocess.run([sys.executable, str(helper), "--sync"],
                           capture_output=True, text=True, timeout=240)
        for line in (r.stdout or "").splitlines():
            if any(k in line for k in ("tracking log  :", "forgotten by this sync",
                                       "cleared because", "no lesson file could be read")):
                print("   " + line.strip())
    except Exception:
        pass


"""

UPLOAD_OLD = """def main():
    if not PASSWORD:
        sys.exit("No login details."""

UPLOAD_NEW = """def main():
    _alk_sync_tracking()      # ALKIFAH-FIX-CONVENTIONS
    if not PASSWORD:
        sys.exit("No login details."""

FORCE_OLD = """    new_items = [it for it in items if it[\"title\"] not in log]"""

FORCE_NEW = """    def _alk_forced(title):          # ALKIFAH-FIX-CONVENTIONS: re-upload on purpose
        _f = str(os.environ.get("LMS_FORCE_TITLES") or "").strip()
        if not _f:
            return False
        if _f.casefold() in ("*", "all", "كل"):
            return True
        t = str(title).casefold()
        return any(part.strip() and part.strip() in t for part in re.split(r"[,;|]", _f))

    new_items = [it for it in items
                 if it[\"title\"] not in log or _alk_forced(it[\"title\"])]
    if str(os.environ.get(\"LMS_FORCE_TITLES\") or \"\").strip():
        print(\"  re-upload is ON (%s) - remembered lessons are sent again, same name. \"
              \"If one is still online you will get two copies of it.\"
              % os.environ[\"LMS_FORCE_TITLES\"])"""

VERIFY_FLAG_OLD = """    p.add_argument("--no-pdf", action="store_true","""

VERIFY_FLAG_NEW = """    p.add_argument("--no-verify", action="store_true",
                   help="skip the look at the platform that repairs the "
                        "'already uploaded' memory after a deletion (LMS_MEMORY_CHECK=0 "
                        "does the same)")
    p.add_argument("--no-pdf", action="store_true","""

CALL_OLD = """    items = find_materials(FOLDER)
    log = load_log()"""

CALL_NEW = """    items = find_materials(FOLDER)
    _alk_memory_repair(items)      # ALKIFAH-FIX-CONVENTIONS: follow deletions online
    log = load_log()"""

MEM_HOOK = """
def _alk_memory_repair(items=None):
    # ALKIFAH-FIX-CONVENTIONS: after something is deleted ON THE PLATFORM the app's
    # memory (uploaded_log.json) still says 'uploaded', so the lesson never goes back
    # up. One quiet headless look at the Materials list fixes the memory: a remembered
    # title that is not online anymore is dropped, so the normal upload sends it again
    # under the SAME name - no ' (2)', nothing deleted. --no-verify or
    # LMS_MEMORY_CHECK=0 skips the look, and any problem leaves the log untouched.
    try:
        if ARGS.no_verify or str(os.environ.get("LMS_MEMORY_CHECK") or "1").strip() == "0":
            return 0
    except Exception:
        pass
    log = load_log()
    if not isinstance(log, dict) or not log:
        return 0
    if not USERNAME or not PASSWORD:
        return 0
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app"))
        import alkifah_memory
    except Exception as e:
        print("  [!] the platform memory check could not run (%s) - nothing was changed."
              % type(e).__name__)
        return 0
    if items is not None:
        # only worth a browser when something remembered is also on the shelf - the
        # names are compared loosely, because a renamed file must still be recognised
        try:
            keys = set(alkifah_memory.norm(k) for k in log)
            hit = any(alkifah_memory.norm(it.get("title")) in keys for it in items)
        except Exception:
            hit = any(str(it.get("title")) in log for it in items)
        if not hit:
            return 0
    try:
        dropped, note = alkifah_memory.repair(log, LOG_PATH, BASE_URL, USERNAME, PASSWORD,
                                              login)
    except BaseException as e:
        if isinstance(e, KeyboardInterrupt):
            raise
        print("  [!] the platform memory check could not run (%s) - nothing was changed."
              % (getattr(e, "code", None) or type(e).__name__))
        return 0
    if note:
        print("      " + note)
    if not dropped:
        return 0
    for t in dropped:
        log.pop(t, None)
    save_log(log)
    print("  [OK] memory fixed: %d lesson(s) deleted on the platform go up again under"
          % len(dropped))
    print("       their SAME names:")
    for t in list(dropped)[:12]:
        print("         - " + str(t))
    return len(dropped)


"""

# ------------------------------------------------------------------ config + skill note
WANT_CONFIG = {"publish_minutes": 5, "level_mix": {"Easy": 5}, "force_level": "Easy",
               "close_months": 2, "close_days": 0, "reupload": ""}

SKILL_NOTE = r"""

---

## Academy conventions (set by ALKIFAH_FIXES — change them in config.json)

- An assessment is **named after its lesson**: `<Lesson> assessment`. If the title box is
  still empty when the app checks it, the name is filled from the lesson automatically, so
  files on the platform and in the app carry the same words.
- **5 questions, all Easy** — `"level_mix": {"Easy": 5}` in config.json. The local relay is
  also told `AI_LEVEL = easy`, so the model writes recall questions instead of mixing levels.
- On the platform an assessment **opens 5 minutes after it is created** and **closes 2
  calendar months later** (`LMS_OPEN_MINUTES`, `LMS_CLOSE_MONTHS`, `LMS_CLOSE_DAYS`).
- **Homework needs no sheet from you.** When a homework spec has no sheet file, the app
  prints the student sheet and the model-answer key itself from the same questions.
- Deletions are followed: `python alkifah_upload.py --sync` removes anything that is gone
  from the tracking log, so re-uploading keeps the SAME name instead of creating " (2)".
"""


# ------------------------------------------------- create_assessment.py (edit #12)
# The save-on-platform step, made to survive the platform itself:
#  - the title is the unified lesson name (filled, or re-unified, in the script)
#  - the platform's overlay popups (the "Welcome to a New School Year" banner that
#    covers the Save button and swallows every click) are closed before the work
#  - a rejected submit is read back from the page (the platform's own words), fixed
#    (empty Title box, missing dates) and submitted once more
#  - "the name is already there" is resolved by FINDING the existing exam, never by
#    creating a second copy
#  - every run (ok or failed) is written to scripts\ASSESS_run_log.txt
CONV_PLATFORM_HELPER = r'''
# --- ALKIFAH-FIX-12 begin --------------------------------------------------------
_ALK_TITLE = None
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "app"))
    import alkifah_title as _ALK_TITLE
except Exception:
    _ALK_TITLE = None


def generated_title(spec, spec_path):
    """The unified name for this run, from the best source available:
    an explicit lesson file in the spec, else the spec file's name, else the
    app's upload log (the platform's own record of the material's name). When two
    sources name the SAME lesson (same week + session), the platform's own words
    win; when they name different lessons, this run's file name wins."""
    c = {}
    if _ALK_TITLE is not None:
        try:
            c["spec"] = _ALK_TITLE.title_for(spec, None, None)
            c["file"] = _ALK_TITLE.title_for({}, str(spec_path), None)
            c["log"] = _ALK_TITLE.title_for({}, None, str(Path(__file__).resolve().parent))
        except Exception:
            pass
    if c.get("spec"):
        return c["spec"]
    f, l = c.get("file", ""), c.get("log", "")
    if f and l:
        try:
            wkf, wkl = _ALK_TITLE._week_session(f), _ALK_TITLE._week_session(l)
        except Exception:
            wkf = wkl = ("", "")
        if wkf and wkl:
            return l if wkf == wkl else f
        return l if (wkl and not wkf) else f
    return f or l


def _alk_run_log(lines):
    try:
        if _ALK_TITLE is not None:
            _ALK_TITLE.run_log(Path(__file__).resolve().parent, lines)
            return
    except Exception:
        pass
    try:
        import time as _t
        f = Path(__file__).resolve().parent / "ASSESS_run_log.txt"
        with f.open("a", encoding="utf-8") as fh:
            fh.write("%s  %s\n" % (_t.strftime("%Y-%m-%d %H:%M:%S"),
                                   " | ".join(str(x) for x in lines)))
    except Exception:
        pass


def _alk_dismiss_popups(page):
    """The platform puts overlays in front of the forms - the biggest one is the
    'Welcome to a New School Year' banner (id=scolaireWelcomeModal), which swallows
    every click until it is closed. Close it with its own button when it has one,
    remove it (and the mouse-blocking backdrop) when it does not. Returns what was
    closed, so the caller can say so out loud."""
    done = []
    try:
        done = page.evaluate("""() => {
            const out = [];
            const closeIn = (el) => {
                const cands = Array.from(el.querySelectorAll(
                    '.btn-close, [data-dismiss="modal"], [aria-label="Close"]'))
                    .concat(Array.from(el.querySelectorAll('button, a')));
                for (const b of cands) {
                    const t = ((b.innerText || '') + ' ' +
                               (b.getAttribute('aria-label') || '')).trim();
                    if (b.classList.contains('btn-close') ||
                        /close|dismiss|got it|continue|ok|later|next/i.test(t)) {
                        try { b.click(); out.push('closed via "' + (t || 'close') + '"'); }
                        catch (e) {}
                        return true;
                    }
                }
                return false;
            };
            document.querySelectorAll('#scolaireWelcomeModal, .scolaire-welcome-popup')
                .forEach(el => {
                    if (!closeIn(el)) {
                        try { el.remove(); out.push('removed ' + (el.id || el.className)); }
                        catch (e) {}
                    }
                });
            document.querySelectorAll('.modal-backdrop.show').forEach(b => {
                try { b.remove(); out.push('removed backdrop'); } catch (e) {}
            });
            return out;
        }""")
        done = [str(d) for d in (done or []) if str(d).strip()]
    except Exception:
        pass
    try:
        page.keyboard.press("Escape")
    except Exception:
        pass
    return done


def _alk_guarded_click(page, selector, timeout=15000):
    """Click, and when the platform put a popup in front of the button, close the
    popup and try again - instead of dying after 30 seconds with a long red error."""
    try:
        page.click(selector, timeout=timeout)
        return
    except Exception:
        _alk_dismiss_popups(page)
        page.wait_for_timeout(800)
        page.click(selector, timeout=timeout)


def _alk_heal_submit(page, title, duration, exam_type):
    """The first submit was answered with the platform's own complaint instead of the
    Details page. Read what it said, fix what we can, submit once more. When the
    platform says the name is already on it, find the existing exam and stop - a
    second copy is worse than stopping. Returns the new exam id or None."""
    errs, fixed = [], []
    if _ALK_TITLE is not None:
        try:
            errs = _ALK_TITLE.form_errors(page)
        except Exception:
            pass
    joined = " | ".join(errs)[:300]
    has_title = ""
    try:
        has_title = page.input_value("#Title", timeout=3000)
    except Exception:
        pass
    if (not has_title) and title:
        try:
            page.fill("#Title", title, timeout=5000)
            fixed.append("filled the empty Title box with: " + title)
        except Exception:
            pass
    if _ALK_TITLE is not None:
        try:
            fixed.extend(_ALK_TITLE.fill_missing_dates(page))
        except Exception:
            pass
    if re.search(r"(?i)already (exists|there)|same title|duplicate|in use|already added",
                 joined):
        found = ""
        if _ALK_TITLE is not None:
            try:
                found = _ALK_TITLE.find_exam_id(page, BASE_URL, title)
            except Exception:
                pass
        if found:
            print("  !! the platform says this name is already on it - and it is there:")
            print(f"     {BASE_URL}/Assessments/Exams/Details?Id={found}")
            print("     nothing new was created. Open that link; if you want a FRESH")
            print("     exam under this name, delete the old one on the platform first.")
            try:
                _alk_run_log(["STOPPED (no duplicate): the exam '%s' already exists on "
                              "the platform, id %s" % (title, found)])
            except Exception:
                pass
            sys.exit(0)
        return None
    if fixed:
        print("  platform complaint: " + (joined or "(none printed on the page)"))
        for fx in fixed:
            print("  fixed: " + fx)
        try:
            _alk_run_log(["the platform rejected the first submit (" +
                          (joined or "no message") + ") - fixed: " + "; ".join(fixed) +
                          " - submitted again"])
        except Exception:
            pass
        _alk_guarded_click(page, "form[action='/Assessments/Exams/Create'] input[type='submit']")
        page.wait_for_load_state("domcontentloaded")
        page.wait_for_timeout(2500)
        m = re.search(r"Details(?:\?Id=|/)([A-Za-z0-9]+)", page.url)
        return m.group(1) if m else None
    return None


def _alk_fail_exit(page, title):
    extra = ""
    if _ALK_TITLE is not None:
        try:
            errs = _ALK_TITLE.form_errors(page)
            if errs:
                extra = " The platform said: " + " | ".join(errs)[:300]
        except Exception:
            pass
    try:
        _alk_run_log(["FAILED creating the exam '%s' - landed on %s%s"
                      % (title, page.url, extra)])
    except Exception:
        pass
    sys.exit("Could not determine the new exam id. Landed on: %s%s" % (page.url, extra))
# --- ALKIFAH-FIX-12 end ----------------------------------------------------------
'''


CA_BASE_OLD = 'BASE_URL = "https://lms.alkifah.edu.sa"'
CA_BASE_NEW = ('BASE_URL = os.environ.get("LMS_BASE_URL", "https://lms.alkifah.edu.sa")'
               '  # ALKIFAH-FIX-12: another academy (or the test platform) can set the host')

CA_IMPORT_ANCHOR = "from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout"

CA_TITLE_OLD = '''    spec = json.loads(Path(ARGS.spec).read_text(encoding="utf-8"))
    title = spec["title"]'''
CA_TITLE_NEW = '''    spec = json.loads(Path(ARGS.spec).read_text(encoding="utf-8"))
    title = str(spec.get("title") or "").strip()
    want = generated_title(spec, ARGS.spec)        # ALKIFAH-FIX-12: one unified name
    if want and want != title:
        print(("  title: unified with the lesson's name -> " if title
               else "  title: the lesson's name -> ") + want)
        title = want
        spec["title"] = want
    try:
        _alk_run_log(["RUN '%s'  spec=%s" % (title or "(no title)", ARGS.spec)])
    except Exception:
        pass'''

CA_LOGIN_OLD = '''        login(page)
        if ARGS.resume:'''
CA_LOGIN_NEW = '''        login(page)
        try:                                         # ALKIFAH-FIX-12: popups on arrival
            _closed = _alk_dismiss_popups(page)
            if _closed:
                print("  closed the platform's popup on arrival: " + ", ".join(_closed))
        except Exception:
            pass
        if ARGS.resume:'''

CA_POP_OLD = '''    page.wait_for_selector("#CourseId", timeout=15000)'''
CA_POP_NEW = '''    page.wait_for_selector("#CourseId", timeout=15000)
    _alk_dismiss_popups(page)      # ALKIFAH-FIX-12: the welcome banner covers the form'''

CA_CLICK_OLD = '''    page.click("form[action='/Assessments/Exams/Create'] input[type='submit']")'''
CA_CLICK_NEW = '''    _alk_guarded_click(page, "form[action='/Assessments/Exams/Create'] input[type='submit']")   # ALKIFAH-FIX-12'''

CA_CONFIRM_OLD = '''    if not m:
        sys.exit(f"Could not determine the new exam id. Landed on: {page.url}")
    return m.group(1), course_guid'''
CA_CONFIRM_NEW = '''    if not m:
        m = _alk_heal_submit(page, title, duration, exam_type)   # ALKIFAH-FIX-12
    if not m:
        _alk_fail_exit(page, title)                              # ALKIFAH-FIX-12
    return m.group(1), course_guid'''

CA_DONE_OLD = '''    print(f"DONE — {title}  verified={verified}  assigned={assign_ok}{extra}  url={details_url}")'''
CA_DONE_NEW = '''    try:
        _alk_run_log(["DONE '%s' verified=%s assigned=%s url=%s"
                      % (title, verified, assign_ok, details_url)])
    except Exception:
        pass
    print(f"DONE — {title}  verified={verified}  assigned={assign_ok}{extra}  url={details_url}")'''


def _once(src: str, old: str, new: str, label: str, say, log) -> str | None:
    n = src.count(old)
    if n != 1:
        say("[X] %s - found the text %d time(s) instead of once, so nothing was changed "
            "there." % (label, n), log)
        return None
    return src.replace(old, new)


def run(root: Path, dry: bool, log, say, backup) -> None:
    app = root / "Alkifah_LMS_App" / "app"
    scripts = root / "Alkifah_LMS_App" / "scripts"

    # ---------------- pack.py : naming + difficulty --------------------------
    f = app / "pack.py"
    if not f.exists():
        say("[!] pack.py not found - naming and difficulty rules were not applied.", log)
    else:
        src = f.read_text(encoding="utf-8")
        if MARK_CONV in src:
            say("[=] pack.py already carries the academy conventions. Skipping.", log)
            src = None
        out = src
        if out is not None:
            anchor = "def validate_spec(spec: dict) -> dict:"
            if out.count(anchor) != 1:
                say("[X] pack.py: validate_spec() not found - conventions skipped there.", log)
                out = None
        if out is not None:
            out = out.replace(anchor, CONV_PACK_HELPERS.lstrip("\n") + anchor, 1)
            out = _once(out, TITLE_OLD, TITLE_NEW, "pack.py: the empty title", say, log)
        if out is not None:
            out = _once(out, MIX_OLD, MIX_NEW, "pack.py: the difficulty rule", say, log)
        if out is not None:
            out = _once(out, SAVE_OLD, SAVE_NEW, "pack.py: save_spec", say, log)
        if out is not None:
            out = _once(out, MAT_ENV_OLD, MAT_ENV_NEW,
                        "pack.py: the app's upload button gets the re-upload switch", say, log)
        if out is not None:
            out = _once(out, SHEET_WARN_OLD, SHEET_WARN_NEW,
                        "pack.py: the homework sheet note", say, log)
        if out is not None:
            out = _once(out, ASSESS_ENV_OLD, ASSESS_ENV_NEW,
                        "pack.py: the assessment run gets the date settings", say, log)
        if out is not None:
            out = _once(out, ASSIGN_ENV_OLD, ASSIGN_ENV_NEW,
                        "pack.py: the assign run gets the date settings", say, log)
        if out is not None:
            try:
                compile(out, str(f), "exec")
            except SyntaxError as e:
                say("[X] the patched pack.py would not compile (%s) - left untouched." % e, log)
                out = None
            if out is not None:
                if dry:
                    say("[dry-run] would put the naming + difficulty rules into pack.py", log)
                else:
                    backup(f, log)
                    f.write_text(out, encoding="utf-8")
                    say("[OK] pack.py: an assessment gets its lesson's name, and the level "
                        "rule now comes from config.json.", log)

    # ---------------- assign_exam.py : open +5 min, close +2 months ----------
    f = scripts / "assign_exam.py"
    if not f.exists():
        say("[!] scripts/assign_exam.py not found - the open/close dates stay as they are.", log)
    elif MARK_CONV in f.read_text(encoding="utf-8"):
        say("[=] assign_exam.py already uses the academy timing. Skipping.", log)
    elif dry:
        say("[dry-run] would change the opening and closing dates in assign_exam.py", log)
    else:
        out = f.read_text(encoding="utf-8")
        anchor = "def fill_first(page, selectors, value):"
        if out.count(anchor) != 1:
            say("[X] assign_exam.py: fill_first() not found - dates left alone.", log)
            out = None
        if out is not None:
            out = out.replace(anchor, CONV_ASSIGN_HELPERS.lstrip("\n") + anchor, 1)
            out = _once(out, OPEN_OLD, OPEN_NEW, "assign_exam.py: opening time", say, log)
        if out is not None:
            out = _once(out, CLOSE_OLD, CLOSE_NEW, "assign_exam.py: closing time", say, log)
        if out is not None:
            try:
                compile(out, str(f), "exec")
            except SyntaxError as e:
                say("[X] the patched assign_exam.py would not compile (%s) - untouched." % e, log)
                out = None
            if out is not None:
                backup(f, log)
                f.write_text(out, encoding="utf-8")
                say("[OK] assign_exam.py: opens 5 minutes after creation, closes 2 calendar "
                    "months later.", log)

    # ---------------- create_assessment.py : the AI makes the sheet ----------
    f = scripts / "create_assessment.py"
    if not f.exists():
        say("[!] scripts/create_assessment.py not found - homework sheets stay manual.", log)
    elif MARK_CONV in f.read_text(encoding="utf-8"):
        say("[=] create_assessment.py already makes its own homework sheet. Skipping.", log)
    elif dry:
        say("[dry-run] would let the AI build the homework sheet in create_assessment.py", log)
    else:
        out = f.read_text(encoding="utf-8")
        if out.count(SHEET_OLD) != 1 or out.count("def main():") != 1:
            say("[X] create_assessment.py does not look like the expected version - left "
                "untouched.", log)
            out = None
        if out is not None:
            out = out.replace(SHEET_OLD, SHEET_NEW, 1)
            out = out.replace("def main():", CONV_SHEET_HELPER.lstrip("\n") + "def main():", 1)
            try:
                compile(out, str(f), "exec")
            except SyntaxError as e:
                say("[X] the patched create_assessment.py would not compile (%s) - untouched."
                    % e, log)
                out = None
            if out is not None:
                backup(f, log)
                f.write_text(out, encoding="utf-8")
                say("[OK] create_assessment.py: a homework with no sheet gets a printed one "
                    "made by the local AI.", log)

    # ---------------- create_assessment.py : the save step, healed (edit #12) -----
    f = scripts / "create_assessment.py"
    if f.exists():
        src = f.read_text(encoding="utf-8")
        if "_alk_heal_submit" in src:
            say("[=] create_assessment.py already heals the save-on-platform step. "
                "Skipping.", log)
        elif dry:
            say("[dry-run] would make create_assessment.py name the exam after its "
                "lesson, close the platform's popups, and heal rejected saves", log)
        else:
            out = src
            for label, old, new in (("the platform host", CA_BASE_OLD, CA_BASE_NEW),
                                    ("the unified title", CA_TITLE_OLD, CA_TITLE_NEW),
                                    ("popups after login", CA_LOGIN_OLD, CA_LOGIN_NEW),
                                    ("popups on the create page", CA_POP_OLD, CA_POP_NEW),
                                    ("the guarded save click", CA_CLICK_OLD, CA_CLICK_NEW),
                                    ("the rejected submit", CA_CONFIRM_OLD, CA_CONFIRM_NEW),
                                    ("the run log", CA_DONE_OLD, CA_DONE_NEW)):
                out = _once(out, old, new, "create_assessment.py: " + label, say, log)
            if out is not None:
                if out.count(CA_IMPORT_ANCHOR) == 1:
                    out = out.replace(CA_IMPORT_ANCHOR,
                                      CA_IMPORT_ANCHOR + "\n" + CONV_PLATFORM_HELPER, 1)
                else:
                    say("[X] create_assessment.py: the import anchor moved - the heal "
                        "was skipped.", log)
                    out = None
            if out is not None:
                try:
                    compile(out, str(f), "exec")
                except SyntaxError as e:
                    say("[X] the patched create_assessment.py would not compile (%s) - "
                        "untouched." % e, log)
                    out = None
                if out is not None:
                    backup(f, log)
                    f.write_text(out, encoding="utf-8")
                    say("[OK] create_assessment.py: the exam is named after its lesson "
                        "automatically (the platform's own words), the 'Welcome to a New "
                        "School Year' popup that covers the Save button is closed, a "
                        "rejected save is read, fixed and retried once, an existing "
                        "name is found instead of duplicated, and every run is written "
                        "to scripts\\ASSESS_run_log.txt.", log)

    # ---------------- platform memory repair (follows deletions on the site) -----
    f = scripts / "upload_materials.py"
    if f.exists():
        src = f.read_text(encoding="utf-8")
        if "_alk_memory_repair" in src:
            say("[=] upload_materials.py already checks the platform before skipping.", log)
        elif dry:
            say("[dry-run] would make upload_materials.py re-check the platform for "
                "deleted uploads", log)
        else:
            out = src
            if out.count(CALL_OLD) != 1 or out.count(VERIFY_FLAG_OLD) != 1 \
               or out.count("def main():") != 1:
                say("[X] upload_materials.py is not the expected version - the platform "
                    "memory check was skipped.", log)
                out = None
            if out is not None:
                out = out.replace(VERIFY_FLAG_OLD, VERIFY_FLAG_NEW, 1)
                out = out.replace(CALL_OLD, CALL_NEW, 1)
                out = out.replace("def main():", MEM_HOOK.lstrip("\n") + "def main():", 1)
                try:
                    compile(out, str(f), "exec")
                except SyntaxError as e:
                    say("[X] the memory check would not compile (%s) - untouched." % e, log)
                    out = None
                if out is not None:
                    backup(f, log)
                    f.write_text(out, encoding="utf-8")
                    say("[OK] upload_materials.py: if you deleted a lesson on the platform, "
                        "it notices and uploads it again under the same name.", log)

    # ---------------- the re-upload switch (config.json + LMS_FORCE_TITLES) --------
    f = scripts / "upload_materials.py"
    if f.exists():
        src = f.read_text(encoding="utf-8")
        if "LMS_FORCE_TITLES" in src:
            say("[=] upload_materials.py already knows the re-upload switch. Skipping.", log)
        elif dry:
            say("[dry-run] would add the re-upload switch to upload_materials.py", log)
        else:
            out = _once(src, FORCE_OLD, FORCE_NEW, "upload_materials.py: the re-upload switch",
                        say, log)
            if out is not None:
                try:
                    compile(out, str(f), "exec")
                    backup(f, log)
                    f.write_text(out, encoding="utf-8")
                    say("[OK] upload_materials.py: a remembered upload can now be sent again "
                        "(LMS_FORCE_TITLES / \"reupload\" in config.json) - same name.", log)
                except SyntaxError as e:
                    say("[X] the re-upload switch would not compile (%s) - untouched." % e, log)

    # ---------------- upload_materials.py : the tracking memory corrects itself
    f = scripts / "upload_materials.py"
    if not f.exists():
        say("[!] scripts/upload_materials.py not found - the upload memory stays as it is.", log)
    elif "_alk_sync_tracking" in f.read_text(encoding="utf-8"):
        say("[=] upload_materials.py already refreshes the tracking memory. Skipping.", log)
    elif dry:
        say("[dry-run] would make upload_materials.py refresh the tracking memory first", log)
    else:
        out = f.read_text(encoding="utf-8")
        if out.count(UPLOAD_OLD) != 1:
            say("[X] upload_materials.py does not look like the expected version - left "
                "untouched.", log)
            out = None
        if out is not None:
            out = out.replace(UPLOAD_OLD, UPLOAD_NEW, 1)
            out = out.replace("def main():", SYNC_HELPER.strip() + "\n\n\ndef main():", 1)
            try:
                compile(out, str(f), "exec")
            except SyntaxError as e:
                say("[X] the patched upload_materials.py would not compile (%s) - untouched."
                    % e, log)
                out = None
            if out is not None:
                backup(f, log)
                f.write_text(out, encoding="utf-8")
                say("[OK] upload_materials.py: it now forgets lessons that are gone, so a "
                    "re-upload keeps the SAME name - even when you upload from inside the app.",
                    log)

    # ---------------- config.json : merge the knobs, keep everything else ----
    f = app / "config.json"
    if not f.exists():
        say("[!] config.json not found - the rules stay at their built-in defaults.", log)
    else:
        try:
            cfg = json.loads(f.read_text(encoding="utf-8"))
        except Exception as e:
            cfg = None
            say("[!] config.json could not be read (%s) - left exactly as it is." % e, log)
        if isinstance(cfg, dict):
            added = {k: v for k, v in WANT_CONFIG.items() if k not in cfg}
            if not added:
                say("[=] config.json already has the academy settings. Skipping.", log)
            elif dry:
                say("[dry-run] would add %s to config.json (your other settings untouched)"
                    % ", ".join(sorted(added)), log)
            else:
                cfg.update(added)
                backup(f, log)
                f.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
                say("[OK] config.json: " + ", ".join("%s = %s" % (k, json.dumps(v))
                                                      for k, v in sorted(added.items()))
                    + "  (nothing else touched)", log)

    # ---------------- the relay : tell the model which level to write --------
    f = app / "ai_gateway_settings.txt"
    if f.exists():
        txt = f.read_text(encoding="utf-8", errors="replace")
        add = []
        if "AI_LEVEL" not in txt:
            add.append("# 5 questions, all Easy (the academy rule). Delete the line to let "
                       "the model mix levels again.\nAI_LEVEL = easy")
        if "AI_QUESTIONS" not in txt:
            add.append("# never save fewer than this many questions: if the model answers "
                       "with 3, the app asks it for the rest (0 = obey the number in the app)\n"
                       "AI_QUESTIONS = 5")
        if "AI_LESSON_CHARS" not in txt:
            add.append("# how much of the lesson text the model is shown. The MIDDLE is cut, "
                       "the beginning and the end stay. Smaller = sooner (the lesson text is "
                       "what costs the seconds on a laptop).\nAI_LESSON_CHARS = 2600")
        if "AI_MAX_TOKENS" not in txt:
            add.append("# how long one answer may be - about 5 short questions fit in 900. "
                       "Bigger means slower, not better.\nAI_MAX_TOKENS = 900")
        if "AI_MAX_SECONDS" not in txt:
            add.append("# how long the app is waited for. When it passes, the questions that "
                       "are ready are sent at once (the writing keeps going in the "
                       "background, so the next press is answered instantly).\n"
                       "AI_MAX_SECONDS = 45")
        if "AI_AGAIN_SECONDS" not in txt:
            add.append("# how long finished questions stay remembered for the NEXT press "
                       "(seconds). After that a new press writes fresh ones - so the memory "
                       "is only for the press you just made.\nAI_AGAIN_SECONDS = 90")
        if "AI_JOB_SECONDS" not in txt:
            add.append("# how long the background writing may take in total before it stops "
                       "and waits for you to press again.\nAI_JOB_SECONDS = 240")
        if not add:
            say("[=] ai_gateway_settings.txt already sets the AI knobs.", log)
        elif dry:
            say("[dry-run] would add " + ", ".join(k.split(" =")[0] for k in add)
                + " to ai_gateway_settings.txt", log)
        else:
            f.write_text(txt.rstrip() + "\n\n" + "\n\n".join(add) + "\n", encoding="utf-8")
            say("[OK] ai_gateway_settings.txt: AI_LEVEL = easy, AI_QUESTIONS = 5 and the "
                "speed knobs (AI_LESSON_CHARS / AI_MAX_TOKENS / AI_MAX_SECONDS / "
                "AI_AGAIN_SECONDS / AI_JOB_SECONDS) - every one of them is editable in "
                "Notepad and takes effect on the very next press.", log)

    # ---------------- SKILL.md : keep the written rules in step --------------
    f = root / "Alkifah_LMS_App" / "skills" / "lms-assessment-maker" / "SKILL.md"
    if f.exists():
        txt = f.read_text(encoding="utf-8", errors="replace")
        if SKILL_MARKER in txt:
            say("[=] the skill note already lists the conventions. Skipping.", log)
        elif dry:
            say("[dry-run] would append the academy conventions to the skill note", log)
        else:
            backup(f, log)
            f.write_text(txt.rstrip() + "\n" + SKILL_NOTE, encoding="utf-8")
            say("[OK] SKILL.md: the written convention now says the same as the app.", log)
    else:
        say("[!] the skill note was not found - nothing to update there.", log)
