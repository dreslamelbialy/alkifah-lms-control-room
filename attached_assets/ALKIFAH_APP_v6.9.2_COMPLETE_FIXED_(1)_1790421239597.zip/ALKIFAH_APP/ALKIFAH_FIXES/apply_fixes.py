#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ALKIFAH_FIXES — installer.  Run it with INSTALL_FIXES.bat (double-click).

What it changes (every touched file is backed up first; --revert puts it all back):

  1. pack.py         -> the AI file picker lists ONLY lessons already on the LMS
                        (read from uploaded_log.json), not every PDF in the folder.
  2. .z-ai-config    -> the dead/borrowed AI address is replaced by the local gateway,
                        and the leaked token is deleted from the app folder.
  3. ai_gateway.py   -> installed; the small relay that talks to a real AI provider
                        with YOUR key (Alkifah_LMS_App/app/ai_gateway.py).
  4. homework_maker.py -> lesson PDF -> printable homework sheet + model answer.
  5. the two .bat starters -> they now launch the gateway automatically.

Usage:  python apply_fixes.py --root <path to ALKIFAH_APP> [--dry-run] [--revert]
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import time
from pathlib import Path

STAMP = time.strftime("%Y%m%d-%H%M%S")
MARK_PACK = "ALKIFAH-FIX-UPLOADED-ONLY"
MARK_BAT = "ALKIFAH-AI-GATEWAY"
HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# ------------------------------------------------------------------ replacement code
# Raw string: backslashes and braces are kept exactly as written.
_ALK_BLOCK = r'''
# --- @MARK@ (installed by ALKIFAH_FIXES) begin ------------------------------
def _alk_norm(s) -> str:
    """Case/space/underscore-insensitive key, so a file called 'Cell_Cycle' matches
    the platform title 'Cell Cycle SRL Lesson'."""
    s = re.sub(r"\s*\(\d+\)\s*$", "", str(s).strip().casefold())
    s = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "-", s)
    return s.strip("-")


def _alk_segments(s) -> list:
    """Split an LMS item title on its ' - ' separators (not on hyphens in words)."""
    return [x.strip() for x in re.split(r"\s+-\s+", str(s).strip()) if x.strip()]


def _alk_uploaded(cfg: dict) -> dict:
    """What the platform already has, straight from the uploader's own log."""
    log = load_json(scripts_dir(cfg) / "uploaded_log.json", {}) or {}
    titles, stems = set(), set()
    for key in log:
        t = _alk_norm(key)
        if not t:
            continue
        titles.add(t)
        seg = _alk_segments(key)
        if len(seg) >= 3:                      # 'Week 1 - Session 02 - <lesson title>'
            stems.add(_alk_norm(seg[-1]))
    return {"titles": titles, "stems": stems, "count": len(titles)}


def _alk_title_of(pdf: Path, root: Path) -> str:
    """Rebuild the LMS item title from the folder layout (same rule as the uploader)."""
    week = session = None
    for part in pdf.relative_to(root).parts[:-1]:
        if week is None:
            week = num(part)
        if session is None:
            session = session_number(part)
    stem = re.sub(r"(?i)^\s*week\s*\d+\s*-?\s*session\s*\d+\s*-?\s*", "", pdf.stem)
    stem = re.sub(r"(?i)^\s*week\s*\d+\s*-?\s*", "", stem)
    if week and session:
        return "Week %s - Session %02d - %s" % (week, session, stem)
    if week:
        return "Week %s - %s" % (week, stem)
    return pdf.stem


def lesson_pdfs(cfg: dict) -> list:
    """Files offered to the assessment / homework maker.

    @MARK@: only lessons that are ALREADY on the platform (uploaded_log.json) are
    offered, so the AI never writes questions from a draft the students have not seen.
    Generated homework sheets are never offered as lessons. When the log is empty
    (brand-new install) nothing is hidden, so the tool can never be left unusable.
    """
    root = Path(cfg["term_folder"])
    if not root.exists():
        return []
    up = _alk_uploaded(cfg)
    gate = up["count"] > 0
    out = []
    for p in sorted(root.rglob("*.pdf")):
        low = (str(p.parent) + " " + p.stem).lower()
        if "booklet" in low or "model answer" in low or "homework" in low:
            continue
        title = _alk_title_of(p, root)
        seg = _alk_segments(title)
        stem_n = _alk_norm(seg[-1]) if seg else _alk_norm(p.stem)
        n = _alk_norm(title)
        on_lms = ((not gate) or n in up["titles"] or stem_n in up["titles"]
                  or stem_n in up["stems"])
        if gate and not on_lms:
            continue
        out.append({"path": str(p), "name": p.name,
                    "folder": str(p.parent.relative_to(root)),
                    "size": human_size(p.stat().st_size), "on_lms": True})
    return out
# --- @MARK@ end ----------------------------------------------------------------
'''

NEW_LESSON_PDFS = _ALK_BLOCK.replace("@MARK@", MARK_PACK)

GATEWAY_BLOCK = """rem === ALKIFAH-AI-GATEWAY (added by ALKIFAH_FIXES) ===
netstat -ano | findstr /C:":8799" | findstr /C:"LISTENING" >nul 2>&1
if errorlevel 1 (
  echo starting the AI gateway...
  start "Alkifah AI Gateway" /min %PY% "%~dp0Alkifah_LMS_App\\app\\ai_gateway.py"
  timeout /t 2 /nobreak >nul
)
rem === end ALKIFAH-AI-GATEWAY ===
""".replace("ALKIFAH-AI-GATEWAY", MARK_BAT)

CONFIG_NEW = {"baseUrl": "http://127.0.0.1:8799/v1", "apiKey": "local-gateway"}

SETTINGS_TXT_FREE = """# Alkifah AI gateway - FREE local model (Ollama), no key, no internet.
# Change AI_MODEL if you download a bigger model (see: ollama list)
AI_PROVIDER = ollama
AI_MODEL = llama3.2:3b
"""

SETTINGS_TXT = """# Alkifah AI gateway - optional settings. Edit in Notepad, save, restart the app.
# Leave it as-is to use OpenAI with gpt-4o-mini. The key goes in ai_gateway_key.txt.
AI_PROVIDER = openai
#AI_PROVIDER = groq
#AI_PROVIDER = openrouter
#AI_PROVIDER = ollama
#AI_MODEL = gpt-4o-mini
#AI_MODEL = llama-3.3-70b-versatile
#AI_BASE = https://my-proxy.example.com/v1     (only for AI_PROVIDER = custom)
"""


def say(msg: str, log: list) -> None:
    print(msg)
    log.append(msg)


def backup(path: Path, log: list) -> None:
    """Copy a file aside before touching it.  The FIRST copy of a run is kept: when two
    steps patch the same file, --revert must go back to the file as it was before any
    of this, not to the half-patched state in between."""
    bak = path.with_name(path.name + ".bak-" + STAMP)
    if bak.exists():
        say("   backup -> " + bak.name + " (kept, already saved by an earlier step)", log)
        return
    shutil.copy2(path, bak)
    say("   backup -> " + bak.name, log)


def safety_backup(root: Path, dry: bool, log: list) -> None:
    """Snapshot accounts + logs + specs BEFORE any file is touched, so a fix can
    never cost you data. Failure here must not stop the install."""
    tool = root / "Alkifah_LMS_App" / "app" / "alkifah_backup.py"
    if dry:
        say("[dry-run] would save a backup of your data first (via alkifah_backup.py)", log)
        return
    if not tool.exists():
        say("[!] backup tool missing - continuing, but save your data by hand if you can.", log)
        return
    try:
        import subprocess
        r = subprocess.run([sys.executable, str(tool), "--backup", "--quiet"],
                           capture_output=True, text=True, timeout=600)
        for line in (r.stdout or "").strip().splitlines()[:4]:
            say("   " + line, log)
        if r.returncode != 0:
            say("[!] the safety backup did not finish (continuing anyway): "
                + (r.stderr or "").strip()[:200], log)
    except Exception as e:
        say("[!] the safety backup failed (%s) - continuing with the fixes." % e, log)


def patch_pack(root: Path, dry: bool, log: list) -> None:
    f = root / "Alkifah_LMS_App" / "app" / "pack.py"
    if not f.exists():
        say("[X] pack.py not found - nothing patched.", log)
        return
    src = f.read_text(encoding="utf-8")
    if MARK_PACK in src:
        say("[=] pack.py already patched (uploaded-only picker). Skipping.", log)
        return
    m = re.search(r"^def lesson_pdfs\(cfg: dict\) -> list:.*?(?=^def |^# ---|\Z)",
                  src, re.S | re.M)
    if not m:
        say("[X] could not find lesson_pdfs() in pack.py - no change made.", log)
        return
    new = src[:m.start()] + NEW_LESSON_PDFS.strip() + "\n\n\n" + src[m.end():]
    if dry:
        say("[dry-run] would replace lesson_pdfs() in pack.py", log)
        return
    try:
        compile(new, str(f), "exec")
    except SyntaxError as e:
        say("[X] the patched pack.py would not compile (%s) - nothing was written." % e, log)
        return
    backup(f, log)
    f.write_text(new, encoding="utf-8")
    say("[OK] pack.py: AI picker now lists only lessons already on the LMS.", log)


def patch_config(root: Path, dry: bool, log: list) -> None:
    f = root / "webapp" / ".z-ai-config"
    if dry:
        say("[dry-run] would rewrite %s -> localhost gateway" % f, log)
        return
    if f.exists():
        try:
            old = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            old = {}
        if old.get("token"):
            backup(f, log)
            say("[OK] leaked AI token deleted from the app folder (old file backed up).", log)
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(CONFIG_NEW, indent=2), encoding="utf-8")
    say("[OK] .z-ai-config -> local gateway (http://127.0.0.1:8799/v1).", log)
    home = Path.home() / ".z-ai-config"
    if home.exists():
        say("[!] there is also a copy at %s - the app reads the folder one first, "
            "but delete it to be safe." % home, log)


def install_gateway(root: Path, dry: bool, log: list) -> None:
    src = HERE / "app" / "ai_gateway.py"
    dst = root / "Alkifah_LMS_App" / "app" / "ai_gateway.py"
    if not src.exists():
        say("[X] payload missing: app/ai_gateway.py", log)
        return
    if dry:
        say("[dry-run] would copy ai_gateway.py to %s" % dst, log)
        return
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    say("[OK] ai_gateway.py installed.", log)
    for extra in ("homework_maker.py", "alkifah_upload.py", "alkifah_backup.py",
                  "alkifah_ai_setup.py", "alkifah_bot.py",
                  "alkifah_assess.py", "alkifah_memory.py", "alkifah_title.py"):
        src2 = HERE / "app" / extra
        if src2.exists():
            shutil.copy2(src2, dst.parent / extra)
            say("[OK] %s installed." % extra, log)
    # webapi.py is an APP file (not ours) - it gets replaced with the version
    # that carries the new sheet/preview commands, backed up first like everything
    srcw = HERE / "app" / "webapi.py"
    if srcw.exists():
        dstw = dst.parent / "webapi.py"
        if dry:
            say("[dry-run] would replace webapi.py with the version that has the "
                "sheet + preview commands", log)
        else:
            backup(dstw, log)
            shutil.copy2(srcw, dstw)
            say("[OK] webapi.py replaced (same commands + the new sheet/preview "
                "ones; a copy of the old one is saved next to it).", log)
    for bat in ("FREE_AI.bat", "AI_STATUS.bat", "HOMEWORK_NOW.bat", "UPLOAD_NOW.bat",
                "UPLOAD_LOOP.bat", "REUPLOAD_NOW.bat", "BACKUP_NOW.bat",
                "RESTORE_BACKUP.bat", "BOT_CHECK.bat", "ASSESS_NOW.bat", "FAST_AI.bat"):
        src3 = HERE / "app" / bat
        if src3.exists():
            shutil.copy2(src3, root / bat)
            say("[OK] %s is now in the ALKIFAH_APP folder (double-click it any time)." % bat, log)
    keyfile = dst.parent / "ai_gateway_key.txt"
    if not keyfile.exists():
        keyfile.write_text("", encoding="utf-8")
        say("[!] put your AI key inside: Alkifah_LMS_App\\app\\ai_gateway_key.txt", log)
    setfile = dst.parent / "ai_gateway_settings.txt"
    free = False
    try:
        import urllib.request
        with urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=1.5):
            free = True
    except Exception:
        free = False
    if not setfile.exists():
        setfile.write_text(SETTINGS_TXT_FREE if free else SETTINGS_TXT, encoding="utf-8")
        say("[OK] ai_gateway_settings.txt created (%s)." %
            ("using your local Ollama - free, no key" if free else
             "no Ollama found - double-click FREE_AI.bat for a free local model"), log)


def patch_webapp(root: Path, dry: bool, log: list) -> None:
    """The compiled UI (no rebuild): the title box fills itself with the exact
    platform name, and the Homework type gets the 'make the sheet with the AI'
    button + a preview before any upload.

    Two chunk files are replaced WHOLE, only after their md5 matches the
    expected v6.9.2 build (or the already-patched one, when re-running) - so an
    updated app is never half-patched, and the step is idempotent.
    """
    import hashlib
    man_file = HERE / "webapp_patch" / "manifest.json"
    if not man_file.exists():
        say("[!] webapp_patch/manifest.json missing - the UI patch was skipped.", log)
        return
    try:
        man = json.loads(man_file.read_text(encoding="utf-8"))
    except Exception as e:
        say("[!] could not read the UI patch manifest (%s) - skipped." % e, log)
        return
    def md5_of(p: Path) -> str:
        return hashlib.md5(p.read_bytes()).hexdigest()

    # the chunks live in the compiled website; the website is normally at the
    # app root (webapp\) but some copies keep it one floor down
    bases = [root, root / "Alkifah_LMS_App"]
    if not any((b / "webapp" / "server.js").exists() or (b / "webapp" / ".next").is_dir()
               for b in bases):
        say("[!] the webapp folder was not found - the UI patch was skipped "
            "(everything else is installed).", log)
        return

    for item in man["files"]:
        target = None
        for b in bases:
            cand = b / item["target_rel"]
            if cand.exists():
                target = cand
                break
        patched = HERE / "webapp_patch" / item["patched_file"]
        if not patched.exists():
            say("[!] missing patch file %s - skipped." % item["patched_file"], log)
            continue
        if target is None:
            target = bases[0] / item["target_rel"]
        cur = md5_of(target) if target.exists() else None
        if cur == item["patched_md5"]:
            say("[=] %s: already in place. Skipping." % item["role"], log)
            continue
        if cur != item["orig_md5"]:
            say("[!] %s: the app's file is not the expected v6.9.2 build (md5 %s) - "
                "it was left alone, nothing half-patched. If the app itself was "
                "updated, the UI additions (auto title + sheet preview) are not "
                "applied - the rest of the fixes still work."
                % (item["role"], (cur or "missing")[:8]), log)
            continue
        if dry:
            say("[dry-run] would replace %s" % target, log)
            continue
        backup(target, log)
        shutil.copy2(patched, target)
        say("[OK] %s installed (%s)." % (item["role"], target.name), log)


def bind_localhost(root: Path, dry: bool, log: list) -> None:
    """v6.9.3 security: the app listened on 0.0.0.0, so anyone on the school Wi-Fi
    could open the control panel and press its buttons. 127.0.0.1 = only this laptop.
    (The Telegram bot and the Drive sign-in both work unchanged.)"""
    for name in ("1-START-APP.bat", "ALKIFAH-BACKGROUND.bat"):
        f = root / name
        if not f.exists():
            continue
        txt = f.read_text(encoding="utf-8", errors="replace")
        if "AL-KIFAH-LOCALHOST" in txt:
            say("[=] %s already bound to 127.0.0.1. Skipping." % name, log)
            continue
        anchor = 'cd /d "%~dp0webapp"'
        if anchor not in txt:
            say("[!] %s: anchor not found - left unchanged." % name, log)
            continue
        block = ('rem AL-KIFAH-LOCALHOST: app reachable from this laptop only\r\n'
                 'set "HOSTNAME=127.0.0.1"\r\n')
        txt = txt.replace(anchor, block + anchor, 1)
        if dry:
            say("[dry-run] would bind the app to 127.0.0.1 in %s" % name, log)
            continue
        backup(f, log)
        f.write_bytes(txt.encode("utf-8", "replace"))
        say("[OK] %s: the app now answers on 127.0.0.1 only (was open on the network)." % name, log)


def patch_bats(root: Path, dry: bool, log: list) -> None:
    for name in ("1-START-APP.bat", "ALKIFAH-BACKGROUND.bat"):
        f = root / name
        if not f.exists():
            continue
        txt = f.read_text(encoding="utf-8", errors="replace")
        if MARK_BAT in txt:
            say("[=] %s already starts the gateway. Skipping." % name, log)
            continue
        anchor = 'cd /d "%~dp0webapp"'
        if anchor not in txt:
            say("[!] %s: anchor not found - add the gateway lines by hand "
                "(see README_FIXES.txt)." % name, log)
            continue
        block = GATEWAY_BLOCK.replace("\n", "\r\n")
        txt = txt.replace(anchor, block + anchor, 1)
        if dry:
            say("[dry-run] would add gateway start to %s" % name, log)
            continue
        backup(f, log)
        f.write_bytes(txt.encode("utf-8", "replace"))
        say("[OK] %s: gateway starts with the app." % name, log)


def revert(root: Path, log: list) -> None:
    """Restore the OLDEST .bak-* (your file as it was before any fix) and drop new scripts."""
    import glob as _glob
    for rel in ("Alkifah_LMS_App/app/pack.py", "webapp/.z-ai-config",
                "1-START-APP.bat", "ALKIFAH-BACKGROUND.bat",
                "Alkifah_LMS_App/scripts/assign_exam.py",
                "Alkifah_LMS_App/scripts/create_assessment.py",
                "Alkifah_LMS_App/scripts/upload_materials.py",
                "Alkifah_LMS_App/skills/lms-assessment-maker/SKILL.md",
                "Alkifah_LMS_App/app/config.json",
                "Alkifah_LMS_App/app/webapi.py",
                "webapp/.next/static/chunks/e551b8f760b42b5c.js",
                "webapp/.next/server/chunks/[root-of-the-server]__d71a05d5._.js"):
        f = root / rel
        # glob.escape: the chunk file name contains [ ], which are wildcards
        baks = sorted(f.parent.glob(_glob.escape(f.name) + ".bak-*"))
        if f.exists() and baks:
            shutil.copy2(baks[0], f)
            say("[OK] reverted %s from %s" % (rel, baks[0].name), log)
        else:
            say("[=] nothing to revert for %s" % rel, log)
    for junk in ("ai_gateway.py", "homework_maker.py", "alkifah_upload.py",
                 "alkifah_backup.py", "alkifah_ai_setup.py", "alkifah_bot.py",
                 "alkifah_assess.py", "alkifah_memory.py", "alkifah_title.py"):
        g = root / "Alkifah_LMS_App" / "app" / junk
        if g.exists():
            g.unlink()
            say("[OK] removed " + junk, log)
    # the question cache the relay keeps so the same lesson is not written twice:
    # it is only a cache, and it rebuilds itself on the next press.
    g = root / "Alkifah_LMS_App" / "app" / "ai_gateway_cache.json"
    if g.exists():
        g.unlink()
        say("[OK] removed the question cache (it rebuilds itself on the next press)", log)
    for junk in ("FREE_AI.bat", "AI_STATUS.bat", "HOMEWORK_NOW.bat", "UPLOAD_NOW.bat",
                 "UPLOAD_LOOP.bat", "REUPLOAD_NOW.bat", "BACKUP_NOW.bat",
                 "RESTORE_BACKUP.bat", "BOT_CHECK.bat", "ASSESS_NOW.bat", "FAST_AI.bat"):
        (root / "FREE_AI_log.txt").unlink(missing_ok=True)
        (root / "Alkifah_LMS_App" / "scripts" / "ASSESS_run_log.txt").unlink(missing_ok=True)
        (root / "FAST_AI_log.txt").unlink(missing_ok=True)
        (root / "BOT_CHECK_log.txt").unlink(missing_ok=True)
        (root / "ASSESS_now_log.txt").unlink(missing_ok=True)
        (root / "Alkifah_LMS_App" / "scripts" / "LMS_MEMORY_log.txt").unlink(missing_ok=True)
        g = root / junk
        if g.exists():
            g.unlink()
            say("[OK] removed " + junk, log)



def looks_like_app_root(p: Path) -> bool:
    r"""The app folder is the one that holds the compiled website (webapp\server.js).
    A few copies keep it under Alkifah_LMS_App instead - both count."""
    if not p or not p.is_dir():
        return False
    if (p / "webapp" / "server.js").exists():
        return True
    return (p / "Alkifah_LMS_App" / "webapp" / "server.js").exists()


def search_path(start: Path) -> list[Path]:
    start = start.resolve()
    out = [start] + [p for p in list(start.parents)[:8]]
    return out


def find_root(start: Path | None) -> Path | None:
    r"""Find ALKIFAH_APP no matter how the fix folder was extracted: walking up out of
    it, and one level down (ALKIFAH_APP\ALKIFAH_FIXES\ALKIFAH_FIXES, or the fixes
    sitting next to ALKIFAH_APP). This is what makes a wrong nesting harmless."""
    if not start:
        return None
    path = search_path(start)
    for cand in path:
        if looks_like_app_root(cand):
            return cand
    # only look a few floors down, so an unrelated "ALKIFAH_APP" far away (an old copy
    # in Downloads, another teacher's folder) can never be patched by mistake
    for cand in path[:3]:
        for sub in ("ALKIFAH_APP", "ALKIFAH-APP", "alkifah_app"):
            kid = cand / sub
            if looks_like_app_root(kid):
                return kid
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=None, help="the ALKIFAH_APP folder")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()

    root = Path(a.root) if a.root else None
    if root is not None:
        fixed = find_root(root)
        if fixed and fixed != root:
            say("--root did not point at the app folder - using %s instead" % fixed, [])
            root = fixed
    else:
        root = find_root(HERE) or find_root(Path.cwd())
    if root is None or not looks_like_app_root(root):
        print("[X] Could not find the ALKIFAH_APP folder from here.")
        print(r"    I look for a folder that contains  webapp\server.js  (that is the app).")
        print("    Where I looked:")
        for cand in search_path(HERE):
            print("      -", cand)
        print("")
        print("    Fix: put the ALKIFAH_FIXES folder inside (or right next to) ALKIFAH_APP,")
        print("    then run INSTALL_FIXES.bat again. Nothing else needs moving - the order of")
        print("    files inside ALKIFAH_FIXES stays as it is, and a doubled ALKIFAH_FIXES")
        print("    ALKIFAH_FIXES folder is fine too, I search upwards and downwards.")
        return 2

    log: list = []
    say("Your ALKIFAH_APP folder:  %s" % root, log)
    say("Fixes coming from:       %s" % HERE, log)
    try:
        sys.path.insert(0, str(root / "Alkifah_LMS_App" / "app"))
        import ai_gateway
        free_ai = ai_gateway.installed_ollama()
    except Exception:
        free_ai = False
    if a.revert:
        revert(root, log)
    else:
        install_gateway(root, a.dry_run, log)     # copies the tools first
        safety_backup(root, a.dry_run, log)        # then snapshot your data
        patch_pack(root, a.dry_run, log)
        try:
            import conventions
            conventions.run(root, a.dry_run, log, say, backup)
        except Exception as e:                     # never lose the other fixes over this
            say("[!] the academy-conventions step could not run (%s)." % e, log)
        patch_config(root, a.dry_run, log)
        patch_bats(root, a.dry_run, log)
        patch_webapp(root, a.dry_run, log)
        bind_localhost(root, a.dry_run, log)
        if not a.dry_run:
            say("", log)
            say("FREE_AI.bat is at:  %s" % (root / "FREE_AI.bat"), log)
            say("AI_STATUS.bat (looks only, changes nothing) is next to it. Every line of", log)
            say("both is saved in:   %s" % (root / "FREE_AI_log.txt"), log)
            if free_ai:
                say("NEXT STEP: double-click FREE_AI.bat (in the ALKIFAH_APP folder) - it", log)
                say("installs the free local model. Then start 1-START-APP.bat and press", log)
                say("the 'Generate Questions' button in the Assessment tab.", log)
            else:
                say("NEXT STEP: double-click FREE_AI.bat (installed for you) - it sets up a", log)
                say("FREE local AI model on this laptop. Or, if you already have a key, put", log)
                say("it in Alkifah_LMS_App\\app\\ai_gateway_key.txt and edit", log)
                say("Alkifah_LMS_App\\app\\ai_gateway_settings.txt.", log)
    out = root / "ALKIFAH_FIXES"
    out.mkdir(exist_ok=True)
    (out / "apply_fixes_report.txt").write_text("\n".join(log), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
