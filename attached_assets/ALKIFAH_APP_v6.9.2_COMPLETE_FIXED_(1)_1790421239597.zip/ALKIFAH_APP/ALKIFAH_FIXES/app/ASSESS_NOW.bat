@echo off
rem ============================================================
rem  ASSESS_NOW.bat - creates the assessment (or homework) on the platform
rem  from the spec you already saved in the app. No hunting for buttons:
rem  it lists what is saved, shows what it will do, and then does it.
rem  It uses the app's own scripts, so names and rules stay identical.
rem ============================================================
title Alkifah - create assessment now
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_assess.py" (
  echo [X] The assessment helper is not installed yet.
  echo     Run ALKIFAH_FIXES\INSTALL_FIXES.bat once, then try again.
  pause & exit /b 1
)

echo.
echo  First: a look at what will run (nothing is sent yet)...
echo.
%PY% "Alkifah_LMS_App\app\alkifah_assess.py" --dry --show
echo.
echo  If the lines above look right, run it for real:
echo     python "Alkifah_LMS_App\app\alkifah_assess.py" --show
echo.
set /p GO=Type go and press Enter to create it on the platform now: 
if /i "%GO%"=="go" %PY% "Alkifah_LMS_App\app\alkifah_assess.py" --show
echo.
pause
