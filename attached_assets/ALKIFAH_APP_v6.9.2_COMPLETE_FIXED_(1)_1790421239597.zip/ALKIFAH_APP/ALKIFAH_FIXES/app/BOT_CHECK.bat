@echo off
rem ============================================================
rem  BOT_CHECK.bat - looks at the Telegram bot and says in plain
rem  words what is missing. It changes nothing unless you add --link.
rem ============================================================
title Alkifah - telegram bot check
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_bot.py" (
  echo [X] The bot checker is not installed yet.
  echo     Run ALKIFAH_FIXES\INSTALL_FIXES.bat once, then try again.
  pause & exit /b 1
)

echo.
echo  Checking the bot now (takes a few seconds)...
echo.
%PY% "Alkifah_LMS_App\app\alkifah_bot.py"
echo.
echo  To link your chat so the app answers you, run this once:
echo     python "Alkifah_LMS_App\app\alkifah_bot.py" --link
echo.
pause
