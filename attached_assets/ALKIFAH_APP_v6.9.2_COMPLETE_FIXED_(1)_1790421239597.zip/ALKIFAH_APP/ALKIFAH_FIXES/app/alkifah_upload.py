#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alkifah_upload.py — one smooth pass: laptop folder -> Google Drive + -> the LMS.

Why this exists: the app's two upload paths are separate, and the LMS one is slow
(PowerPoint conversion + page-by-page duplicate check). This script makes it one
action and reorders it so you SEE results immediately:

    1. mirror the lesson files to your Google Drive folder   (seconds, no browser)
    2. then run the real LMS upload through the app's own scripts (the slow part)
    3. print one short report, and keep a log so nothing is ever copied twice

It does NOT replace the app: it calls the same pack.py / upload_materials.py code the
app calls, so the duplicate check, the naming rules, the 25 MB limit and the publish
date logic stay exactly as they are. Nothing is ever deleted.

    python alkifah_upload.py --status          what is waiting right now
    python alkifah_upload.py --all             Drive first, then the LMS  (double-click)
    python alkifah_upload.py --drive           only the Drive mirror
    python alkifah_upload.py --lms             only the LMS upload (one retry on failure)
    python alkifah_upload.py --lms --limit 3   upload 3 lessons now, the rest next run
    python alkifah_upload.py --watch 15        repeat --all every 15 minutes
    python alkifah_upload.py --drive-folder "D:\\Drive\\Alkifah 2026-2027"   remember a folder
    python alkifah_upload.py --all --dry-run   show the plan, change nothing

Settings live in upload_settings.txt (next to this file): drive_folder, retry, limit.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import pack                                    # the app's own backend module  # noqa: E402

SETTINGS = APP_DIR / "upload_settings.txt"
MIRROR_LOG = APP_DIR / "drive_mirror_log.json"
REPORT = APP_DIR / "upload_flow_report.txt"
DEFAULTS = {
    "drive_folder": "",          # local folder that Google Drive syncs (mapped in the app)
    "lms_limit": "6",            # lessons per LMS run, keeps each run short
    "retry": "1",                # extra LMS passes for failed items
    "copy_pptx": "yes",          # send the PowerPoint too, not only the PDF
    "overwrite_changed": "yes",  # a re-saved lesson replaces the old Drive copy
}


# ------------------------------------------------------------------ settings / log
def load_settings() -> dict:
    s = dict(DEFAULTS)
    if SETTINGS.exists():
        for line in SETTINGS.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            s[k.strip().lower()] = v.strip().strip("\"'")
    return s


def save_setting(key: str, value: str) -> None:
    lines = [f"# Alkifah upload-flow settings - edited {datetime.now():%Y-%m-%d %H:%M}"]
    cur = load_settings()
    cur[key.lower()] = value
    for k, v in cur.items():
        lines.append(f"{k} = {v}")
    SETTINGS.write_text("\n".join(lines) + "\n", encoding="utf-8")


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def drive_folders(cfg: dict, s: dict) -> list[Path]:
    """The local folder(s) that Google Drive syncs.

    Priority: what you saved here, then the app's own Drive mapping (drive_routes.json),
    then the folder the app's Drive tab shows. Anything that is not an existing folder
    is ignored, so a wrong path can never make the script delete or move files.
    """
    out: list[Path] = []

    def add(p) -> None:
        try:
            q = Path(str(p).strip().strip("\"'"))
            if q and q.is_dir() and q not in out:
                out.append(q)
        except Exception:
            pass

    if s.get("drive_folder"):
        add(s["drive_folder"])
    for cand in (APP_DIR / "drive_routes.json",
                 Path(os.environ.get("APPDATA", "")) / "Alkifah" / "drive_routes.json"):
        try:
            data = json.loads(cand.read_text(encoding="utf-8"))
        except Exception:
            continue
        seen: list[str] = []

        def walk(node) -> None:
            if isinstance(node, dict):
                for k, v in node.items():
                    if isinstance(v, str) and re.search(r"(?i)local|path|folder|dir", str(k)):
                        seen.append(v)
                    else:
                        walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)

        walk(data)
        for v in seen:
            add(v)
    return out


# ------------------------------------------------------------------ 1. drive mirror
def mirror_items(cfg: dict) -> list[Path]:
    """Every lesson file worth putting on Drive (sources + their converted PDFs,
    plus booklets and generated homework). The LMS list is not touched here."""
    root = Path(cfg["term_folder"])
    if not root.exists():
        return []
    files: list[Path] = []
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.name.startswith("~$"):
            continue
        ext = p.suffix.lower()
        if ext in (".pptx", ".ppt") or ext == ".pdf":
            files.append(p)
    return files


def mirror(cfg: dict, s: dict, dry: bool) -> dict:
    targets = drive_folders(cfg, s)
    root = Path(cfg["term_folder"])
    log = load_json(MIRROR_LOG, {})
    res = {"targets": [str(t) for t in targets], "copied": [], "skipped": 0,
           "updated": [], "errors": [], "no_target": not targets}
    if not targets:
        return res
    allow_overwrite = s.get("overwrite_changed", "yes").lower() in ("yes", "1", "true")
    want_pptx = s.get("copy_pptx", "yes").lower() in ("yes", "1", "true")
    for src in mirror_items(cfg):
        if src.suffix.lower() in (".pptx", ".ppt") and not want_pptx:
            res["skipped"] += 1
            continue
        try:
            rel = src.relative_to(root)
        except ValueError:
            continue
        size = src.stat().st_size
        key = f"{rel.as_posix()}|{size}"
        for tgt in targets:
            dst = tgt / rel
            try:
                if dst.exists() and dst.stat().st_size == size:
                    res["skipped"] += 1
                    continue
                if dst.exists() and not allow_overwrite:
                    res["skipped"] += 1
                    continue
                tag = "updated" if dst.exists() else "copied"
                if not dry:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(src, dst)
                    log[key] = datetime.now().strftime("%Y-%m-%d %H:%M")
                res[tag].append(str(rel))
            except Exception as e:
                res["errors"].append(f"{rel}: {type(e).__name__}: {e}")
    if not dry:
        try:
            MIRROR_LOG.write_text(json.dumps(log, ensure_ascii=False, indent=1),
                                  encoding="utf-8")
        except Exception:
            pass
    return res


# ------------------------------------------------------------------ 2. lms upload
def lms_command(cfg: dict, s: dict, limit: int | None, no_pdf: bool) -> dict:
    opts = {"no_pdf": no_pdf}
    lim = limit if limit is not None else int(s.get("lms_limit") or 0)
    if lim:
        opts["limit"] = lim
    cmd = pack.build_command(cfg, "materials", "auto", opts)
    creds = {}
    try:
        import profiles
        creds = {k: v for k, v in (profiles.env_for(profiles.active()) or {}).items() if v}
    except Exception as e:
        creds = {}
        cmd.setdefault("warnings", []).append(f"could not read the saved account: {e}")
    cmd["env_full"] = creds
    return cmd


def run_lms(cfg: dict, s: dict, limit, no_pdf: bool, dry: bool) -> dict:
    cmd = lms_command(cfg, s, limit, no_pdf)
    argv = cmd.get("argv") or []
    out = {"argv": [str(a) for a in argv], "runs": [], "returncode": None,
           "warnings": cmd.get("warnings", [])}
    if dry or not argv:
        return out
    env = dict(os.environ)
    env.update({k: str(v) for k, v in (cmd.get("env") or {}).items()})
    env.update(cmd.get("env_full") or {})
    tries = 1 + max(0, int(s.get("retry") or 0))
    for attempt in range(1, tries + 1):
        print(f"--- LMS pass {attempt}/{tries} ---")
        p = subprocess.run(argv, env=env, cwd=str(Path(argv[0]).parent if argv[0] else "."))
        out["runs"].append(p.returncode)
        out["returncode"] = p.returncode
        if p.returncode == 0:
            break
        if attempt < tries:
            print("    something failed - waiting 20s and trying the leftovers once more")
            time.sleep(20)
    return out


# ------------------------------------------------------------------ status / report
def status(cfg: dict, s: dict) -> dict:
    scan = pack.scan_materials(cfg)
    items = scan.get("items", [])
    pending = [i for i in items if not i.get("uploaded")]
    return {
        "root": scan.get("root"), "total": scan.get("total", 0),
        "new_for_lms": len(pending), "already_on_lms": scan.get("already", 0),
        "need_conversion": scan.get("to_convert", []), "oversize": scan.get("oversize", []),
        "drive_targets": [str(t) for t in drive_folders(cfg, s)],
        "pending": [{"title": i["title"], "size": i["size"], "pdf_ready": i["pdf_ready"]}
                    for i in pending],
    }


def write_report(text: str) -> None:
    try:
        REPORT.write_text(text, encoding="utf-8")
    except Exception:
        pass


# --------------------------------------------------------- the "what is still there" check
STOP_WORDS = {"lesson", "lessons", "notes", "slides", "slide", "pdf", "pptx", "final",
              "copy", "new", "updated", "the", "and", "of", "in", "for", "assessment",
              "assessments", "hw", "homework"}


def _norm(t: str) -> str:
    """A comparable form of a lesson name: "Week1_Session03_Cell_Cycle" and
    "Week 1 - Session 03 - Cell Cycle" must be recognised as the SAME lesson,
    otherwise a re-upload would get a new name on the platform."""
    t = re.sub(r"(?i)[.\-]", " ", str(t).lower())
    t = re.sub(r"(?i)[_ ]+", " ", t).strip()
    t = re.sub(r"(?<=[a-z])(?=\d)", " ", t)
    t = re.sub(r"(?<=\d)(?=[a-z])", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def _key(t: str) -> frozenset:
    return frozenset(w for w in _norm(t).split() if w and w not in STOP_WORDS)


SKIP_DIRS = ("homework", "booklet", "model answer", "answer key", "answer", "key")


def _disk_titles(cfg: dict) -> dict:
    """Titles the term folder still has a file for.

    The app's own scan counts PowerPoint only (a PDF sitting next to it is usually the
    converted copy), but a lesson may also be handed over as PDF or Word - so all of
    them are looked at here. This only decides whether a remembered title is still
    real: nothing is renamed and nothing is deleted."""
    out: dict[str, dict] = {}

    def add(name: str, path: str = "") -> None:
        raw = Path(path).stem if path else str(name)
        n = _norm(raw)
        title = (str(name or "").strip() or raw).strip()
        if n:
            out.setdefault(n, {"title": title, "path": str(path or "")})

    try:
        for it in (pack.scan_materials(cfg) or {}).get("items", []) or []:
            path = str(it.get("path") or it.get("file") or "")
            add(str(it.get("title") or Path(path).stem), path)
    except Exception:
        pass
    try:
        root = Path(cfg.get("term_folder") or "")
        if root.exists():
            for q in root.rglob("*"):
                try:
                    if not q.is_file() or q.name.startswith("~$"):
                        continue
                    if q.suffix.lower() not in (".pdf", ".pptx", ".ppt", ".docx", ".doc"):
                        continue
                    low = [part.lower() for part in q.relative_to(root).parts[:-1]]
                    if any(part in SKIP_DIRS for part in low):
                        continue
                except OSError:
                    continue
                add(q.stem, str(q))
    except Exception:
        pass
    return out


def sync_tracking(cfg: dict, dry: bool, forget: list[str] | None = None) -> dict:
    """Keep uploaded_log.json honest, so a name never changes and nothing is stuck.

    The log is the only memory the app has of what it already put on the platform.
    Two things go wrong with it:

      * a lesson file was deleted from the laptop  -> the log keeps saying "uploaded"
        forever; the entry is stale and is removed here (a dated copy is kept).
      * the material was deleted ON THE PLATFORM but the file is still here -> the log
        still says uploaded, so the app never re-uploads it. `--forget "title"` clears
        exactly those, and the next upload puts the SAME title back (no " (2)" suffix).

    Nothing on disk is renamed or deleted by this function - only the log is rewritten,
    and the old log is saved next to it.
    """
    forget = forget or []
    try:
        sd = pack.scripts_dir(cfg)
    except Exception:
        sd = Path(cfg.get("install_dir") or ".") / "scripts"
    log_path = sd / "uploaded_log.json"
    log = load_json(log_path, {})
    res = {"log": str(log_path), "had": len(log) if isinstance(log, dict) else 0,
           "pruned": [], "forgotten": [], "waiting": [], "changed": False, "error": ""}
    if not isinstance(log, dict):
        res["error"] = "the tracking log could not be read - nothing was touched."
        return res

    have = _disk_titles(cfg)
    if not have:
        res["error"] = ("no lesson file could be read in %s - the log was left EXACTLY as "
                        "it is (nothing was removed). If that folder is on a USB drive or "
                        "in OneDrive/Google Drive, open it first and run this again."
                        % (cfg.get("term_folder") or "the term folder"))
        return res
    forget_n = [_norm(f) for f in forget if str(f).strip()]

    disk_keys = {k: _key(k) for k in have}
    for title in sorted(log):
        n = _norm(title)
        k = _key(title)
        on_disk = bool(k) and any(
            n == dk or k <= dk or dk <= k for dk in disk_keys.values() if dk)
        wanted = any(_key(f) and (_key(f) <= k or k <= _key(f)) for f in forget_n)
        if wanted:
            res["forgotten"].append(title)
        elif not on_disk:
            res["pruned"].append(title)
        else:
            continue
        log.pop(title, None)
        res["changed"] = True

    log_keys = [_key(t) for t in log]
    waiting = set()
    for it in (have or {}).values():
        title = str(it.get("title") or "").strip()
        k = _key(title)
        if k and not any(k <= lk or lk <= k for lk in log_keys if lk):
            waiting.add(title)
    # the same lesson can show up twice here (its file name and the app's own title);
    # keep the fuller one so the list reads cleanly
    kept = []
    for t in sorted(waiting, key=lambda q: (-len(q), q)):
        kt = _key(t)
        if any(kt <= _key(o) for o, _ in kept):
            continue
        kept.append((t, kt))
    res["waiting"] = [t for t, _ in kept]


    if res["changed"] and not dry and log_path.exists():
        try:
            keep = log_path.with_name(log_path.name + ".pruned-" +
                                       datetime.now().strftime("%Y%m%d-%H%M%S"))
            shutil.copy2(log_path, keep)
            res["kept"] = str(keep)
            log_path.write_text(json.dumps(log, indent=2, ensure_ascii=False),
                                encoding="utf-8")
        except Exception as e:
            res["error"] = "the log could not be written (%s) - it is unchanged." % e
            res["changed"] = False
    return res


def sync_lines(r: dict) -> list[str]:
    removed = len(r.get("pruned", [])) + len(r.get("forgotten", []))
    out = ["tracking log  : %d title(s) remembered before this check, %d of them still "
           "have a lesson file" % (r.get("had", 0), r.get("had", 0) - removed)]
    if r.get("error"):
        out.append("   [!] " + r["error"])
        return out
    if r.get("pruned"):
        out.append("   forgotten by this sync (the lesson file is gone from the laptop): "
                   + "; ".join(r["pruned"][:8]) + (" ..." if len(r["pruned"]) > 8 else ""))
    if r.get("forgotten"):
        out.append("   cleared because you asked (they will be uploaded again, SAME name): "
                   + "; ".join(r["forgotten"][:8]))
    if r.get("waiting"):
        out.append("   on the laptop but not online yet (%d): %s"
                   % (len(r["waiting"]), ", ".join(r["waiting"][:6])))
    if r.get("kept"):
        out.append("   the previous log is saved as " + Path(r["kept"]).name)
    if not removed:
        out.append("   the log already matches the lessons on this laptop - nothing was "
                   "corrected. Names stay exactly as they are.")
    return out


# ------------------------------------------------------------------ re-upload option
def remembered_titles(cfg: dict) -> list:
    """What the app currently believes is already on the platform."""
    try:
        sd = pack.scripts_dir(cfg)
    except Exception:
        sd = Path(cfg.get("install_dir") or ".") / "scripts"
    log = load_json(sd / "uploaded_log.json", {})
    if not isinstance(log, dict):
        return []
    return sorted(log)


def resolve_reupload(cfg: dict, again: list, all_flag: bool, ask: bool,
                     assume_yes: bool) -> str:
    """What LMS_FORCE_TITLES should be for this run.

    Normally a lesson whose title sits in uploaded_log.json is skipped, which is right
    until a material is deleted on the platform (or the class needs it again). This
    option says "upload it again" without touching names, folders or the log."""
    if again:
        force = ",".join(str(t).strip() for t in again if str(t).strip())
    elif all_flag:
        force = "*"
    elif ask:
        titles = remembered_titles(cfg)
        if not titles:
            print("nothing is remembered as uploaded, so everything in the folder will "
                  "go up normally - no re-upload needed.")
            return ""
        if not sys.stdin or not sys.stdin.isatty():
            print("the picker needs a real window: use --again \"title\" or --again-all")
            return ""
        print("What the app thinks is already on the platform:")
        for i, t in enumerate(titles, 1):
            print(f"   {i:2}. {t}")
        print("Type the numbers to upload again (e.g. 1,3), or 'all', or just Enter: ")
        try:
            ans = input("  > ").strip()
        except Exception:
            return ""
        if not ans:
            print("ok, nothing forced - the normal run will skip what is already online.")
            return ""
        if ans.lower() in ("all", "all*", "كل", "*"):
            force = "*"
        else:
            picked = []
            for part in re.split(r"[,\s]+", ans):
                if part.isdigit() and 0 < int(part) <= len(titles):
                    picked.append(titles[int(part) - 1])
            if not picked:
                print("no number matched - nothing forced.")
                return ""
            force = ",".join(picked)
    else:
        return ""
    if not assume_yes and sys.stdin and sys.stdin.isatty():
        print("")
        print("RE-UPLOAD is ON for: " + ("everything remembered" if force == "*" else force))
        print("Anything still online will be sent a SECOND time (the platform will show "
              "two copies) - that is what you want after deleting it there.")
        try:
            if input("type yes to continue: ").strip().lower() not in ("y", "yes"):
                print("cancelled - nothing was uploaded.")
                return "__NO__"
        except Exception:
            pass
    return force


def main() -> int:
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--status", action="store_true")
    g.add_argument("--sync", action="store_true",
                   help="reconcile the tracking log with the files on disk (removes entries "
                        "for lessons that are gone; nothing on disk is renamed or deleted)")
    g.add_argument("--drive", action="store_true")
    g.add_argument("--lms", action="store_true")
    g.add_argument("--all", action="store_true")
    ap.add_argument("--watch", type=int, default=0, metavar="MINUTES")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--no-pdf", action="store_true")
    ap.add_argument("--forget", action="append", default=[], metavar="TITLE",
                   help="clear one remembered title so the next upload re-creates it on the "
                        "platform under the SAME name. Repeat the flag per title.")
    ap.add_argument("--again", action="append", default=[], metavar="TITLE",
                   help="upload this title again even though the app remembers it "
                        "(use it after something was deleted on the platform)")
    ap.add_argument("--again-all", action="store_true",
                   help="same, for everything remembered as uploaded")
    ap.add_argument("--reupload", action="store_true",
                   help="pick from a list which uploads to repeat (needs a window)")
    ap.add_argument("--yes", action="store_true", help="do not ask before re-uploading")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--drive-folder", default=None)
    ap.add_argument("--json", action="store_true", help="machine-readable output")
    a = ap.parse_args()

    if a.sync or a.forget:
        cfg0 = pack.load_config()
        r = sync_tracking(cfg0, a.dry_run, a.forget)
        print("Syncing the upload tracking - %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M"))
        for line in sync_lines(r):
            print(line)
        print("\n%s" % ("(dry run - the log was not written)" if a.dry_run and r["changed"]
                        else "log: " + r["log"]))
        if not (a.drive or a.lms or a.all or a.status or a.watch):
            return 0

    if a.drive_folder:
        save_setting("drive_folder", a.drive_folder)
        print("Drive folder remembered:", a.drive_folder)
        if not a.status and not a.drive and not a.lms and not a.all:
            return 0

    cfg = pack.load_config()
    s = load_settings()
    loop = max(0, a.watch)
    force = "" if a.sync else resolve_reupload(cfg, a.again, a.again_all, a.reupload, a.yes)
    if force == "__NO__":
        return 0
    if force:
        os.environ["LMS_FORCE_TITLES"] = force
        s["force_note"] = ("re-upload ON: " +
                           ("everything remembered" if force == "*" else force.replace(",", ", ")))

    while True:
        lines: list[str] = []
        data: dict = {}
        do_all = a.all or not (a.status or a.drive or a.lms)
        if do_all and not a.status:
            sr = sync_tracking(cfg, a.dry_run)
            data["sync"] = sr
            lines.extend(sync_lines(sr))
        st = status(cfg, s)
        lines.append(f"term folder   : {st['root']}")
        lines.append(f"lessons total : {st['total']}   waiting for LMS: {st['new_for_lms']}"
                     f"   already online: {st['already_on_lms']}")
        if st["need_conversion"]:
            lines.append(f"still need a PPT->PDF conversion: {len(st['need_conversion'])} "
                         f"(this is the slow part; a PDF is kept next to the lesson, so each "
                         f"lesson is converted only once)")
        if st["oversize"]:
            lines.append("OVER 25 MB (the LMS will refuse these): " + ", ".join(st["oversize"]))

        if do_all or a.drive:
            m = mirror(cfg, s, a.dry_run)
            data["drive"] = m
            if m["no_target"]:
                lines.append("")
                lines.append("[!] Drive folder is not known yet. Pick the Google Drive folder "
                              "that sits on this laptop:")
                lines.append('      python alkifah_upload.py --drive-folder "D:\\Drive\\Alkifah"')
                lines.append("    (or use the app's Google Drive tab - this script reads that "
                             "mapping too).")
            else:
                lines.append("")
                verb = "would copy" if a.dry_run else "copied"
                lines.append(f"Drive: {verb} {len(m['copied'])} file(s), "
                             f"replaced {len(m['updated'])}, skipped {m['skipped']} "
                             f"already identical -> {', '.join(m['targets'])}")
                for e in m["errors"][:5]:
                    lines.append("   ! " + e)

        if s.get("force_note"):
            lines.append("")
            lines.append("[!] " + s["force_note"])
        if (do_all or a.lms) and not a.status:
            c = run_lms(cfg, s, a.limit, a.no_pdf, a.dry_run)
            data["lms"] = c
            lines.append("")
            if a.dry_run:
                lines.append("LMS: would run -> " + " ".join(c["argv"]))
            elif not c["argv"]:
                lines.append("LMS: nothing to do (all lessons are already online).")
            else:
                lines.append(f"LMS: finished, exit code {c['returncode']} "
                             f"(passes: {len(c['runs'])})")
            for w in c.get("warnings") or []:
                lines.append("   (note) " + w)

        report = f"Alkifah upload flow - {datetime.now():%Y-%m-%d %H:%M}\n" + "\n".join(lines) + "\n"
        if a.json:
            print(json.dumps({"report": report, **data}, ensure_ascii=False, indent=1))
        else:
            print(report, end="")
        if not a.dry_run:
            write_report(report)

        if not loop:
            return 0
        print(f"\n(next pass in {loop} minute(s) - press Ctrl+C to stop)")
        time.sleep(loop * 60)


if __name__ == "__main__":
    sys.exit(main())
