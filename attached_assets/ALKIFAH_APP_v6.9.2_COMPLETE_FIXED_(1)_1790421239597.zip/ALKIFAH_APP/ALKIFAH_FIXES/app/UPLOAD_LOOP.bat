@echo off
rem ============================================================
rem  UPLOAD_LOOP.bat - keeps the upload flow running quietly:
rem  every 30 minutes it mirrors new lessons to Google Drive and pushes the
rem  ones that are ready to the LMS. Close this window to stop it.
rem  To start it automatically at sign-in: press Win+R, type shell:startup,
rem  and put a shortcut to this file in that folder.
rem ============================================================
title Alkifah - upload loop (every 30 min)
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_upload.py" (
  echo [X] Run ALKIFAH_FIXES\INSTALL_FIXES.bat once first.
  pause & exit /b 1
)

%PY% "Alkifah_LMS_App\app\alkifah_upload.py" --all --watch 30
echo.
pause
