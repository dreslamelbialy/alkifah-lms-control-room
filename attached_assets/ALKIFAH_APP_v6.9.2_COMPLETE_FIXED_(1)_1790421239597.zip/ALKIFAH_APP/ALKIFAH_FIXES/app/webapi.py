#!/usr/bin/env python3
"""
Alkifah LMS Automation — web bridge for the Next.js web app.

The web app (Next.js) calls this script as:

    python3 webapi.py <command>          # JSON payload on stdin (optional)

and reads a single JSON document from stdout. Every command reuses the SAME
functions the Flask control room used (pack.py / profiles.py), so behaviour,
folder-scanning rules, logs and the encrypted profile store stay identical.

Commands
--------
dashboard | config-get | config-set | pack-status | fixes | env
scan-materials | scan-booklets | logs | logs-forget
specs | spec-get | spec-validate | spec-save | spec-delete
lesson-pdfs | latest-lesson | lesson-extract | pdf-from-text
profiles | profiles-save | profiles-activate | profiles-delete
profiles-password | profile-env | schedules
bot-config | bot-status | bot-env           (v6.8 telegram)
drive-token-save | drive-token-read | drive-token-clear  (v6.8 drive)
preview-run (kind, action, opts)   -> build_command without running
spec-title (spec?, name?)          -> the exact title the platform will carry
sheet-make (spec)                  -> print the homework sheet + preview pages
file-view (path)                   -> a file's bytes, for in-app previews

The password is never printed. profile-env returns it only so the web app's
process runner can inject it into the environment of a single script run —
it must never be stored client-side or logged.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

# v6.9 FIX: on Windows the stdout of a piped process uses the ANSI codepage
# (cp1252/cp1256) — Arabic printed with ensure_ascii=False then reached the
# web app as mojibake ("كلام عربي مش متظبط"). Force UTF-8 on every stream.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8")
    except Exception:
        pass

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

import pack        # noqa: E402
import profiles    # noqa: E402

BOT_FILE = APP_DIR / "bot.json"                 # v6.8: telegram bot settings (token encrypted)
DRIVE_TOKEN_FILE = APP_DIR / "drive_token.json"  # v6.8: google drive refresh token (encrypted)


def _read_payload() -> dict:
    try:
        raw = sys.stdin.read()
        if not raw.strip():
            return {}
        data = json.loads(raw)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _out(obj) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, default=str))
    sys.stdout.flush()


def _bot_load() -> dict:
    try:
        data = json.loads(BOT_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _bot_status(data: dict) -> dict:
    has_token = bool(data.get("token"))
    tok = str(data.get("chat_id") or "")
    return {
        "configured": has_token,
        "enabled": bool(data.get("enabled", True)),
        "chat_id": tok,
        "chat_linked": bool(tok),
        "saved_at": data.get("saved_at", ""),
    }


def _cfg() -> dict:
    return pack.effective_config()


# --------------------------------------------------------------------------- v6.9.4
# The title the UI shows MUST be the title the platform will carry, computed the
# same way the patched create_assessment.py computes it (its generated_title):
#   1) the lesson file named inside the spec
#   2) the spec file's own name
#   3) the app's upload log - the platform's own words for the newest lesson
# with the same tie-breaks: when two sources name the SAME lesson (same week +
# session) the platform's own words win; different lessons -> the file name wins.
def _alk_platform_title(cfg: dict, spec=None, name: str = "") -> str:
    spec = spec if isinstance(spec, dict) else {}
    try:
        if name:
            p = Path(pack.specs_dir(cfg)) / Path(name).name
            if p.exists():
                disk = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(disk, dict):
                    spec = {**disk, **{k: v for k, v in spec.items()
                                        if v not in (None, "")}}
    except Exception:
        pass
    c = {}
    try:
        import alkifah_title
        scripts_dir = str(pack.scripts_dir(cfg))
        c["spec"] = str(alkifah_title.title_for(spec, None, None) or "")
        c["file"] = str(alkifah_title.title_for({}, str(name) if name else None, None) or "")
        c["log"] = str(alkifah_title.title_for({}, None, scripts_dir) or "")
    except Exception:
        pass
    if c.get("spec"):
        return c["spec"]
    f, l = c.get("file", ""), c.get("log", "")
    if f and l:
        try:
            wkf, wkl = alkifah_title._week_session(f), alkifah_title._week_session(l)
        except Exception:
            wkf = wkl = ("", "")
        if wkf and wkl:
            return l if wkf == wkl else f
        return l if (wkl and not wkf) else f
    if f or l:
        return f or l
    return str(spec.get("title") or "").strip()


def _alk_pdf_preview_pages(pdf: str, max_pages: int = 3) -> list:
    """PNGs of the first pages of a PDF, so the app can show a preview without
    the teacher ever having to open the file. Failures just mean 'no preview'."""
    try:
        import pymupdf
        doc = pymupdf.open(str(pdf))
        out = []
        base = Path(str(pdf)).stem
        for i in range(min(int(max_pages), doc.page_count)):
            pix = doc[i].get_pixmap(dpi=110)
            p = Path(str(pdf)).with_name(f"{base}.preview-{i + 1}.png")
            pix.save(str(p))
            out.append(str(p))
        doc.close()
        return out
    except Exception:
        return []


def _alk_sheet_make(spec: dict) -> dict:
    """Print the homework sheet from the spec's questions (the SAME printer the
    platform-creation step uses: homework_maker.py --from-json), then attach
    preview pages. The file lands where the creation step would put it, so the
    preview and the upload can never be two different sheets."""
    qs = [q for q in (spec.get("questions") or [])
          if isinstance(q, dict) and str(q.get("text") or "").strip()]
    if not qs:
        return {"ok": False, "error": "this spec has no questions yet - generate "
                                      "them first (Generate Questions from a "
                                      "lesson), then press again."}
    maker = APP_DIR / "homework_maker.py"
    if not maker.exists():
        return {"ok": False, "error": "the sheet printer (homework_maker.py) is "
                                      "missing - run INSTALL_FIXES.bat once."}
    title = str(spec.get("title") or "Homework").strip() or "Homework"
    out_dir = Path(str(spec.get("homework_dir")
                       or (APP_DIR.parent / "First Term" / "Homework")))
    out_dir.mkdir(parents=True, exist_ok=True)
    import subprocess
    import tempfile
    qf = Path(tempfile.gettempdir()) / "alkifah_homework_questions_ui.json"
    qf.write_text(json.dumps(qs, ensure_ascii=False), encoding="utf-8")
    cmd = [sys.executable, str(maker), "--from-json", str(qf), "--no-lesson",
           "--title", title, "--out", str(out_dir),
           "--lang", str(spec.get("lang") or "en")]
    r = None
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except Exception as e:
        return {"ok": False, "error": "the sheet printer stopped: %s" % e}
    sheet = ""
    for line in (r.stdout or "").splitlines():
        if "student sheet" in line and ":" in line:
            found = line.split(":", 1)[1].strip().strip('"')
            if found and Path(found).exists():
                sheet = found
    if not sheet:
        made = sorted(out_dir.glob("* - Homework.pdf"),
                      key=lambda q: q.stat().st_mtime)
        sheet = str(made[-1]) if made else ""
    if not sheet:
        return {"ok": False,
                "error": "no file came out of the printer (%s)"
                         % ((r.stderr or r.stdout or "")[-200:])}
    pages = _alk_pdf_preview_pages(sheet)
    key = Path(sheet).with_name(Path(sheet).stem + " (Model Answer).pdf")
    return {"ok": True, "path": sheet, "title": title, "pages": pages,
            "page_count": len(pages),
            "model_answer": str(key) if key.exists() else ""}


def _alk_safe_read_path(raw: str):
    """A file the UI may preview: it must live inside the app's own folders (or
    the temp dir) - nothing else, and never bigger than 30 MB."""
    import tempfile
    p = Path(str(raw or "")).expanduser()
    try:
        if not p.is_absolute() or not p.is_file():
            return None
        p = p.resolve()
    except Exception:
        return None
    roots = [APP_DIR.parent, Path(tempfile.gettempdir()), Path.cwd()]
    for root in roots:
        try:
            rp = root.resolve()
            if p == rp or rp in p.parents:
                if p.stat().st_size <= 30 * 1024 * 1024:
                    return p
                return None
        except Exception:
            continue
    return None


def main() -> None:
    cmd = sys.argv[1] if len(sys.argv) > 1 else "dashboard"
    body = _read_payload()
    try:
        if cmd == "dashboard":
            _out(pack.dashboard(_cfg()))

        elif cmd == "config-get":
            _out({"ok": True, "config": _cfg()})

        elif cmd == "config-set":
            scope = body.pop("scope", "auto")
            prof = profiles.active()
            prof_patch = {k: v for k, v in body.items() if k in app_profile_keys()}
            app_patch = {k: v for k, v in body.items() if k not in app_profile_keys()}
            if prof and scope in ("auto", "profile") and prof_patch:
                profiles.update(prof["id"], prof_patch)
                profiles.apply_to_config(profiles.get(prof["id"]))
            elif prof_patch and scope in ("auto", "app"):
                # v6.6: no active teacher profile yet — the grade/classes chosen
                # now (e.g. from the header grade switcher) must NOT be dropped
                # silently; keep them in the app config until a profile exists.
                app_patch.update(prof_patch)
            if app_patch:
                pack.save_config(app_patch)
            _out({"ok": True, "config": _cfg()})

        elif cmd == "pack-status":
            _out(pack.pack_status(_cfg()))

        elif cmd == "fixes":
            _out(pack.verify_fixes(_cfg()))

        elif cmd == "env":
            _out(pack.env_status(_cfg()))

        elif cmd == "scan-materials":
            _out(pack.scan_materials(_cfg()))

        elif cmd == "scan-booklets":
            _out(pack.scan_booklets(_cfg()))

        elif cmd == "logs":
            _out(pack.logs_overview(_cfg()))

        elif cmd == "logs-forget":
            if not body.get("confirmed"):
                _out({"ok": False, "needs_confirm": True,
                      "message": "This removes the entry from the log so the item "
                                 "can be uploaded/created again."})
            else:
                _out(pack.forget_log_entry(_cfg(), body.get("log", ""),
                                           body.get("key", "")))

        elif cmd == "specs":
            # new_title: the name a brand-new assessment would carry on the
            # platform (from the newest lesson), so the app can fill its title
            # box automatically - same words everywhere, nothing to type.
            _out({"ok": True, "specs": pack.list_specs(_cfg()),
                  "new_title": _alk_platform_title(_cfg(), {}, "")})

        elif cmd == "spec-get":
            name = body.get("name", "")
            path = pack.specs_dir(_cfg()) / Path(name).name
            if not path.exists():
                _out({"ok": False, "error": "spec not found"})
            else:
                _spec = json.loads(path.read_text(encoding="utf-8"))
                # platform_title: the EXACT name the platform will carry for
                # this file (the same computation the creation step uses), so
                # the editor can show it before anything is created.
                _out({"ok": True, "name": path.name, "spec": _spec,
                      "platform_title": _alk_platform_title(_cfg(), _spec,
                                                            path.name)})

        elif cmd == "spec-validate":
            _out(pack.validate_spec(body.get("spec") or {}))

        elif cmd == "spec-save":
            _res = pack.save_spec(_cfg(), body.get("spec") or {},
                                  body.get("filename", ""))
            if _res.get("ok"):
                # the file on disk now carries the unified name - show it, so
                # the editor and the platform can never drift apart
                try:
                    _saved = json.loads(Path(_res["path"]).read_text(encoding="utf-8"))
                    _res["title"] = _alk_platform_title(_cfg(), _saved,
                                                        Path(_res["path"]).name)
                except Exception:
                    pass
            _out(_res)

        elif cmd == "spec-delete":
            _out(pack.delete_spec(_cfg(), body.get("name", "")))

        elif cmd == "spec-title":
            _out({"ok": True,
                  "title": _alk_platform_title(_cfg(), body.get("spec"),
                                               body.get("name", ""))})

        elif cmd == "sheet-make":
            _out(_alk_sheet_make(body.get("spec") or {}))

        elif cmd == "file-view":
            import base64
            p = _alk_safe_read_path(body.get("path"))
            if p is None:
                _out({"ok": False,
                      "error": "file not found (or outside the app folders)"})
            else:
                mime = {".png": "image/png", ".jpg": "image/jpeg",
                        ".jpeg": "image/jpeg", ".gif": "image/gif",
                        ".webp": "image/webp", ".pdf": "application/pdf"}.get(
                            p.suffix.lower(), "application/octet-stream")
                _out({"ok": True,
                      "b64": base64.b64encode(p.read_bytes()).decode("ascii"),
                      "mime": mime, "size": p.stat().st_size, "name": p.name})

        elif cmd == "lesson-pdfs":
            _out(pack.lesson_pdfs(_cfg()))

        elif cmd == "latest-lesson":
            _out(pack.latest_lesson(_cfg()) or {})

        elif cmd == "lesson-extract":
            _out(pack.extract_pdf_text(body.get("path", ""),
                                       int(body.get("max_pages", 10))))

        elif cmd == "lesson-extract-any":
            # v6.4: PDF / PPTX / DOCX text extraction for AI question generation
            _out(pack.extract_lesson_text(body.get("path", ""),
                                          int(body.get("max_pages", 14)),
                                          int(body.get("max_chars", 20000))))

        elif cmd == "pdf-from-text":
            text = body.get("text", "")
            out = Path(body.get("path") or
                       (Path(_cfg()["term_folder"]) / "lesson_from_text.pdf"))
            try:
                try:
                    import pymupdf as fitz
                except ImportError:
                    import fitz
                doc = fitz.open()
                page = doc.new_page()
                y = 60
                for raw_line in text.splitlines():
                    for chunk in [raw_line[i:i + 90]
                                  for i in range(0, max(len(raw_line), 1), 90)]:
                        if y > 780:
                            page = doc.new_page()
                            y = 60
                        page.insert_text((48, y), chunk, fontsize=11)
                        y += 16
                out.parent.mkdir(parents=True, exist_ok=True)
                doc.save(str(out))
                doc.close()
                _out({"ok": True, "path": str(out)})
            except Exception as e:
                _out({"ok": False, "error": str(e)})

        elif cmd == "profiles":
            _out({"profiles": profiles.list_profiles(),
                  "active_profile": profiles.active_id(),
                  "crypto": profiles.crypto_method(),
                  "defaults": {
                      "install_dir": pack.load_config().get("install_dir", ""),
                      "term_folder": pack.load_config().get("term_folder", ""),
                      "booklet_folder": pack.load_config().get("booklet_folder", ""),
                      "course": pack.load_config().get("course", ""),
                      "classes": pack.load_config().get("classes", "ALL"),
                      "python_exe": pack.load_config().get("python_exe", ""),
                  }})

        elif cmd == "profiles-save":
            pid = body.get("id")
            password = body.get("password")
            if password == "":
                password = None
            data = {k: body.get(k) for k in profiles.PROFILE_FIELDS if k in body}
            if pid:
                result = profiles.update(pid, data, password)
            else:
                result = profiles.create(data, password)
            if result.get("ok"):
                pid = result.get("id") or pid
                if body.get("activate", True) and pid:
                    profiles.set_active(pid)
                    profiles.apply_to_config(profiles.get(pid))
            _out(result)

        elif cmd == "profiles-activate":
            pid = body.get("id", "")
            if pid and not profiles.get(pid):
                _out({"ok": False, "error": "profile not found"})
            else:
                profiles.set_active(pid)
                profiles.apply_to_config(profiles.get(pid))
                _out({"ok": True, "active_profile": pid, "config": _cfg()})

        elif cmd == "profiles-delete":
            if not body.get("confirmed"):
                _out({"ok": False, "needs_confirm": True,
                      "message": "This deletes the teacher profile and its stored "
                                 "password from this computer."})
            else:
                result = profiles.delete(body.get("id", ""))
                profiles.apply_to_config()
                _out(result)

        elif cmd == "profiles-password":
            pid = body.get("id") or profiles.active_id()
            if not pid or not profiles.get(pid):
                _out({"ok": False, "error": "no teacher profile"})
            else:
                _out(profiles.set_password(pid, body.get("password", "")))

        elif cmd == "profile-env":
            """Env vars (incl. LMS_PASSWORD) for the active profile — server-side only."""
            env = profiles.env_for(profiles.active())
            _out({"ok": True, "env": {k: v for k, v in env.items() if v}})

        elif cmd == "bot-config":
            # v6.8: Telegram bot settings — token encrypted with the SAME key
            # as the LMS password, chat_id captured from the first /start.
            from datetime import datetime as _dt
            data = _bot_load()
            token = body.get("token")
            if token is not None:
                token = str(token).strip()
                if token:
                    data["token"] = profiles.encrypt(token)
                else:
                    data.pop("token", None)          # empty string clears it
            if "enabled" in body:
                data["enabled"] = bool(body.get("enabled"))
            if "chat_id" in body:
                data["chat_id"] = str(body.get("chat_id") or "").strip()
            data["saved_at"] = _dt.now().isoformat(timespec="seconds")
            try:
                BOT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2),
                                    encoding="utf-8")
            except Exception as exc:
                _out({"ok": False, "error": str(exc)})
            else:
                _out({"ok": True, **_bot_status(data)})

        elif cmd == "bot-status":
            _out({"ok": True, **_bot_status(_bot_load())})

        elif cmd == "bot-env":
            # server-side only: decrypted token for the in-app Telegram poller
            data = _bot_load()
            _out({"ok": True,
                  "token": profiles.decrypt(data.get("token") or {}),
                  "chat_id": data.get("chat_id", ""),
                  "enabled": bool(data.get("enabled", True))})

        elif cmd == "drive-token-save":
            # v6.8: Google Drive OAuth refresh token (encrypted like passwords)
            rt = str(body.get("refresh_token") or "").strip()
            if not rt:
                _out({"ok": False, "error": "missing refresh_token"})
            else:
                DRIVE_TOKEN_FILE.write_text(
                    json.dumps({"refresh": profiles.encrypt(rt)}, indent=2),
                    encoding="utf-8")
                _out({"ok": True})

        elif cmd == "drive-token-read":
            try:
                data = json.loads(DRIVE_TOKEN_FILE.read_text(encoding="utf-8"))
            except Exception:
                data = {}
            _out({"ok": True, "refresh_token": profiles.decrypt(data.get("refresh") or {})})

        elif cmd == "drive-token-clear":
            try:
                DRIVE_TOKEN_FILE.unlink()
            except Exception:
                pass
            _out({"ok": True})

        elif cmd == "preview-run":
            built = pack.build_command(_cfg(), body.get("kind", ""),
                                       body.get("action", ""), body.get("opts") or {})
            argv = built.get("argv", [])
            _out({"command": " ".join(f'"{a}"' if " " in a else a for a in argv),
                  "env_keys": sorted((built.get("env") or {}).keys()),
                  "needs_confirm": built.get("needs_confirm", False),
                  "error": built.get("error"),
                  "warnings": built.get("warnings", [])})

        elif cmd == "schedules":
            c = _cfg()
            _out({"rows": pack.schedules(c), "bat": pack.schedule_bat(c),
                  "install_dir": c["install_dir"]})

        elif cmd == "health":
            import os as _os
            import sys as _sys
            _out({"ok": True, "python": _sys.version.split()[0],
                  "cwd": str(Path.cwd()), "base": str(pack.BASE)})

        else:
            _out({"ok": False, "error": f"unknown command: {cmd}"})

    except Exception as exc:                      # noqa: BLE001
        _out({"ok": False, "error": f"{type(exc).__name__}: {exc}"})


def app_profile_keys() -> set:
    return {"install_dir", "term_folder", "booklet_folder", "course", "classes",
            "python_exe", "email", "name"}


if __name__ == "__main__":
    main()
