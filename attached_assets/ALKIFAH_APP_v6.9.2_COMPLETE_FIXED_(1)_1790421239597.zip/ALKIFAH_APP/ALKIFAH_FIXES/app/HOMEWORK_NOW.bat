@echo off
rem ============================================================
rem  HOMEWORK_NOW.bat  -  a printable homework sheet (student copy
rem  + green model-answer copy) made from the newest lesson that is
rem  ALREADY on the LMS. Needs the free local AI - nothing is uploaded
rem  or sent anywhere by this file.
rem ============================================================
title Alkifah - homework sheet
set "TOOL=%~dp0Alkifah_LMS_App\app\homework_maker.py"
if not exist "%TOOL%" set "TOOL=%~dp0homework_maker.py"

set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "%TOOL%" (
  echo.
  echo  [X] homework_maker.py was not found - run INSTALL_FIXES.bat once first.
  echo.
  pause
  exit /b 1
)

echo.
echo  It takes the newest lesson already on the platform, reads it with the local
echo  model, and writes two PDFs in your Homework folder: one for the students and
echo  one model answer (green) for you. 8 questions take about 2-4 minutes.
echo.
set "NUM=8"
set /p NUM=  How many questions?  press Enter for 8 :
set "LANG=en"
set /p LANG=  Language - en or ar?  press Enter for en :
echo.
%PY% "%TOOL%" --latest --count %NUM% --lang %LANG%
if errorlevel 1 (
  echo.
  echo  [!] it stopped early. Usual reasons, in order:
  echo      - the local model is not ready   - check with AI_STATUS.bat
  echo      - no lesson is marked as uploaded yet - run UPLOAD_NOW.bat once
  echo      - a typo in the two questions above - Enter uses 8 and en
)
echo.
echo  The exact file names are printed above, in the Homework folder next to your
echo  lesson folders. Print the student sheet; keep the green one for correcting.
echo.
pause
