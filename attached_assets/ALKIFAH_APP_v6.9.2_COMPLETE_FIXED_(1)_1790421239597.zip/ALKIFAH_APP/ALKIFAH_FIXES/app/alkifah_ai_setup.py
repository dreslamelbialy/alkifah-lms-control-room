#!/usr/bin/env python3
r"""
alkifah_ai_setup.py  —  the free, offline AI for the Alkifah app, with no disappearing window.

WHY THIS FILE EXISTS
FREE_AI.bat used to do all of this itself, and a .bat that fails halfway just vanishes -
nobody knows what happened. So the .bat is now a 6-line launcher and every step, every
error and every command that was run is printed AND written to:

      ALKIFAH_APP\FREE_AI_log.txt        (send that file if something looks wrong)

Two commands, both safe to run as often as you like:

    python alkifah_ai_setup.py --status     just look: installed? running? model downloaded?
    python alkifah_ai_setup.py --setup      fix it: install Ollama, start it, download ONE
                                            model, point the app at it
Nothing here costs money, needs an account, or sends your lesson text anywhere: the model
runs on your own laptop and the app talks to 127.0.0.1 only.
"""
from __future__ import annotations

import ctypes
import json
import os
import shutil
import subprocess
import sys
import time
import traceback
import urllib.error
import urllib.request
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOG: list[str] = []


def p(msg: str = "") -> None:
    print(msg, flush=True)
    LOG.append(msg)


def write_logs() -> None:
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    text = "FREE_AI / AI status log  -  %s\n%s\n" % (stamp, "\n".join(LOG))
    for folder in {HERE, find_root() or HERE}:
        for name in ("FREE_AI_log.txt", "FAST_AI_log.txt"):
            try:
                (folder / name).write_text(text, encoding="utf-8")
            except Exception:
                pass


# ---------------------------------------------------------------- locate the app
def looks_like_app_root(pth: Path) -> bool:
    return (pth / "webapp" / "server.js").exists() or (
        pth / "Alkifah_LMS_App" / "webapp" / "server.js").exists()


def find_root() -> Path | None:
    """ALKIFAH_APP, from wherever this file happens to be sitting."""
    start = HERE
    for cand in [start] + list(start.parents)[:8]:
        if looks_like_app_root(cand):
            return cand
    return None


# ---------------------------------------------------------------- reuse the gateway
sys.path.insert(0, str(HERE))
try:
    import ai_gateway as gw                      # the relay the app already uses
except Exception:                                  # half-copied folder: keep going
    class _Fallback:
        @staticmethod
        def ollama_root(base: str = "") -> str:
            return "http://127.0.0.1:11434"

        @staticmethod
        def reachable(root: str) -> bool:
            try:
                with urllib.request.urlopen(root + "/api/tags", timeout=1.5):
                    return True
            except Exception:
                return False

        @staticmethod
        def ollama_program():
            return shutil.which("ollama") or shutil.which("ollama.exe")

        @staticmethod
        def local_models(root: str = ""):
            return []

    gw = _Fallback()

ROOT_ADDR = gw.ollama_root()


# ---------------------------------------------------------------- ollama helpers
def find_ollama() -> str | None:
    found = gw.ollama_program()
    if found:
        return found
    spots = []
    if os.name == "nt":
        spots = [os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
                 os.path.expandvars(r"%ProgramFiles%\Ollama\ollama.exe"),
                 r"C:\Program Files\Ollama\ollama.exe"]
    else:
        spots = ["/usr/local/bin/ollama", "/usr/bin/ollama", "/opt/homebrew/bin/ollama"]
    for cand in spots:
        if cand and os.path.exists(cand):
            return cand
    return None


def run_ollama(exe: str, args: list[str], show: bool = False) -> tuple[int, str]:
    """Run the real ollama command. show=True keeps its output on screen (progress bars)."""
    try:
        if show:
            return subprocess.call([exe] + args), ""
        r = subprocess.run([exe] + args, capture_output=True, text=True, timeout=120)
        return r.returncode, ((r.stdout or "") + (r.stderr or ""))
    except Exception as e:
        return 9, "%s: %s" % (type(e).__name__, e)


def installed_models(exe: str | None) -> list[str]:
    """Model names on the machine - asked from the running server first (most truthful),
    then from `ollama list` if the server is off."""
    try:
        with urllib.request.urlopen(ROOT_ADDR + "/api/tags", timeout=3) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        names = [m.get("name", "") for m in data.get("models", []) if m.get("name")]
        if names:
            return names
    except Exception:
        pass
    if exe:
        rc, out = run_ollama(exe, ["list"])
        if rc == 0:
            names = []
            for line in out.splitlines()[1:]:
                parts = line.split()
                if parts and ":" in parts[0]:
                    names.append(parts[0])
            return names
    return []


def server_up() -> bool:
    return gw.reachable(ROOT_ADDR)


def start_server(wait: float = 10.0) -> bool:
    if server_up():
        return True
    p("  starting the local Ollama service...")
    try:
        ok = gw.wake_ollama("", wait=wait)
    except Exception:
        ok = False
    if ok:
        p("  [OK] the service is answering on " + ROOT_ADDR)
        return True
    p("  [!] it is not answering yet - that is usually only a slow first start, and the app")
    p("      will try again by itself the first time you press the AI button.")
    return server_up()


def ram_gb() -> int:
    try:
        if os.name == "nt":
            class STATEX(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            st = STATEX()
            st.dwLength = ctypes.sizeof(STATEX)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(st)):
                return int(round(st.ullTotalPhys / (1024 ** 3)))
        return int(round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / (1024 ** 3)))
    except Exception:
        return 0


def pick_model(ram: int) -> str:
    if ram >= 16:
        return "llama3.1:8b"
    if ram >= 8:
        return "llama3.2:3b"
    return "llama3.2:1b"


def settings_file() -> Path:
    return HERE / "ai_gateway_settings.txt"


def current_provider_model() -> tuple[str, str]:
    prov = model = ""
    f = settings_file()
    if f.exists():
        for line in f.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" in line and not line.strip().startswith("#"):
                k, v = [x.strip() for x in line.split("=", 1)]
                if k.upper() == "AI_PROVIDER":
                    prov = v
                if k.upper() == "AI_MODEL":
                    model = v
    return prov, model


def write_settings(model: str) -> None:
    """Point the app at a local model WITHOUT touching the lines she edited (level,
    count, speed knobs). AI_BASE is cleared, because a base left over from an internet
    provider would otherwise be used for Ollama too."""
    f = settings_file()
    p("  [OK] the app is now pointed at the local model: " + f.name)
    merge_settings({"AI_PROVIDER": "ollama", "AI_MODEL": model, "AI_BASE": ""},
                   "set up the free local model")
    if "# change AI_MODEL" not in f.read_text(encoding="utf-8", errors="replace"):
        with f.open("a", encoding="utf-8") as fh:
            fh.write("# change AI_MODEL to any name from:  ollama list\n"
                     "# for a free fast INTERNET model instead, double-click FAST_AI.bat\n")


# ---------------------------------------------------------------- switching AI engines
# Two ways to get answers, both free. "local" = a model on this laptop (nothing leaves
# the machine, slower on an old one). "cloud" = a free internet key (1-3 seconds per
# answer) - and if that one is offline or out of quota, the app answers from the local
# model anyway, so switching is never a risk.
CLOUD = {
    "groq": ("https://api.groq.com/openai/v1", "openai/gpt-oss-20b",
             "https://console.groq.com/keys"),
    "openrouter": ("https://openrouter.ai/api/v1",
                   "meta-llama/llama-3.2-3b-instruct:free",
                   "https://openrouter.ai/settings/keys"),
    "gemini": ("https://generativelanguage.googleapis.com/v1beta/openai",
               "gemini-2.5-flash", "https://aistudio.google.com/apikey"),
    "openai": ("https://api.openai.com/v1", "gpt-4o-mini", "https://platform.openai.com/keys"),
}


def merge_settings(pairs: dict, title: str = "") -> None:
    """Change the given keys, keep every other line she edited (level, count, speed
    knobs). The old file is copied first, never deleted."""
    f = settings_file()
    old = f.read_text(encoding="utf-8", errors="replace") if f.exists() else ""
    if old:
        try:
            f.with_name(f.name + ".before-switch-" + time.strftime("%Y%m%d-%H%M%S")
                        ).write_text(old, encoding="utf-8")
        except Exception:
            pass
    want = {k.upper(): str(v) for k, v in pairs.items()}
    out, seen = [], set()
    for line in old.splitlines():
        st = line.strip()
        if st and not st.startswith("#") and "=" in st:
            k = st.split("=", 1)[0].strip().upper()
            if k in want:
                out.append("%s = %s" % (k, want[k]))
                seen.add(k)
                continue
        out.append(line)
    for k, v in want.items():
        if k not in seen:
            out.append("%s = %s" % (k, v))
    head = ("# Alkifah AI gateway settings - %s %s\n"
            % (title, time.strftime("%Y-%m-%d %H:%M"))) if title else ""
    body = "\n".join(out).strip() + "\n"
    f.write_text(head + body, encoding="utf-8")
    p("  [OK] settings now say: " + ", ".join("%s = %s" % (k, want[k]) for k in sorted(want)))


BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def discover_models(base: str, key: str, exclude=()) -> str:
    """The provider's current model list (GET /models). Groq retires model names
    without warning (it did on 2026-08-16), so the tool must not trust a printed
    name - it asks the provider what works RIGHT NOW and uses that."""
    try:
        req = urllib.request.Request(base.rstrip("/") + "/models",
                                     headers={"Authorization": "Bearer " + key,
                                              "User-Agent": BROWSER_UA})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        ids = [str((m or {}).get("id") or "").strip() for m in data.get("data", [])]
        ids = [i for i in ids if i and i not in set(exclude)]
        if not ids:
            return ""
        for pref in ("openai/gpt-oss-20b", "openai/gpt-oss-120b"):
            if pref in ids:
                return pref
        for i in ids:
            low = i.lower()
            if any(k in low for k in ("gpt-oss", "llama", "qwen", "mistral", "gemma", "mixtral")):
                return i
        return ids[0]
    except Exception:
        return ""


def try_live(base: str, key: str, model: str) -> tuple[bool, str]:
    """One real 12-token question, so she hears 'ready' from the tool and not from the app."""
    body = json.dumps({"model": model, "max_tokens": 16,
                       "messages": [{"role": "user",
                                     "content": "Answer with the single word: ready"}]}).encode()
    headers = {"Content-Type": "application/json", "Authorization": "Bearer " + key}
    # sign like a normal browser: Groq's shield (Cloudflare) answers the default
    # "Python-urllib" signature with HTTP 403 "error code: 1010" even for a valid key
    headers["User-Agent"] = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                             "AppleWebKit/537.36 (KHTML, like Gecko) "
                             "Chrome/124.0.0.0 Safari/537.36")
    req = urllib.request.Request(base.rstrip("/") + "/chat/completions", data=body,
                                 headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=45) as r:
            d = json.loads(r.read().decode("utf-8", "replace"))
        txt = ((d.get("choices") or [{}])[0].get("message") or {}).get("content", "")
        return True, "the service answered: " + (txt or "(empty reply, but the key works)")
    except urllib.error.HTTPError as e:
        why = e.read().decode("utf-8", "replace")[:220]
        return False, "HTTP %s: %s" % (e.code, " ".join(why.split()))
    except Exception as e:
        return False, "%s: %s" % (type(e).__name__, e)


def cloud(provider: str = "groq", key: str = "", model: str = "") -> int:
    provider = (provider or "groq").strip().lower()
    if provider not in CLOUD:
        p("  [!] I do not know the provider '%s'. The free ones here are: %s."
          % (provider, ", ".join(sorted(CLOUD))))
        return 2
    base, def_model, site = CLOUD[provider]
    base = os.environ.get("AI_CLOUD_BASE", base).rstrip("/")   # other providers / tests
    model = (model or def_model).strip()
    f = HERE / "ai_gateway_key.txt"
    if not key:
        saved = f.read_text(encoding="utf-8").strip() if f.exists() else ""
        if saved and not saved.startswith(("paste", "YOUR")):
            key = saved
            p("  [=] using the key already saved in ai_gateway_key.txt")
    if not key:
        p("  [X] no key yet. Open this page, make a free key (no card), and put it in")
        p("      the window that asked for it, or in this file:")
        p("        " + str(f))
        p("      free keys:  " + site)
        p("      RESULT: not ready - no key")
        return 3
    if key and key not in (f.read_text(encoding="utf-8").strip() if f.exists() else ""):
        f.write_text(key.strip() + "\n", encoding="utf-8")
        p("  [OK] key saved (only in that file on this laptop): " + f.name)
    p("  key used: " + (key[:4] + "\u2022" * 6 + key[-2:] if len(key) > 8 else "\u2022" * 6))
    merge_settings({"AI_PROVIDER": provider, "AI_MODEL": model, "AI_BASE": base},
                   "switched to the free internet model")
    ok, why = try_live(base, key.strip(), model)
    if not ok and ("model_not_found" in why or "does not exist" in why):
        # the provider retired this model name (Groq did it on 2026-08-16) - ask the
        # provider what it has now, switch, and try once more
        got = discover_models(base, key.strip(), exclude=[model])
        if got and got != model:
            p("  [=] the provider says the model '%s' was retired - it switched to "
              "'%s' by itself (saved in the settings)." % (model, got))
            merge_settings({"AI_MODEL": got}, "auto-switched to the provider's current model")
            model = got
            ok, why = try_live(base, key.strip(), model)
    p("")
    if ok:
        p("  [OK] %s / %s answers.  %s" % (provider, model, why))
        p("  RESULT: ready - press Generate in the app and it should answer in seconds.")
        p("")
        p("  note: the local model on this laptop stays installed. If the internet is off,")
        p("        or the free hourly limit is reached, the app answers from it instead -")
        p("        you will not see an error, only a line in ai_gateway_debug.txt.")
        p("  to go back to fully offline:  FAST_AI.bat and choose 2")
        return 0
    p("  [X] the key did not answer: " + why)
    p("      RESULT: not ready - nothing else was changed, the app still works offline.")
    p("      most common reasons: the key was pasted with a space, or the free limit of")
    p("      the hour is used up (wait a minute and run FAST_AI.bat again). If it says")
    p("      the model no longer exists, the tool already tried to switch itself -")
    p("      run FAST_AI.bat once more and it will take the provider's current list.")
    return 4


def local(want_model: str = "") -> int:
    exe = find_ollama()
    have = installed_models(exe) if exe else []
    model = (want_model or (have[0] if have else pick_model(ram_gb()))).strip()
    merge_settings({"AI_PROVIDER": "ollama", "AI_MODEL": model, "AI_BASE": ""},
                   "switched back to the model on this laptop")
    p("")
    if have:
        p("  [OK] the app uses %s on this laptop again - no internet, nothing leaves" % model)
        p("      the machine.")
        p("  RESULT: ready")
        return 0
    p("  [=] settings now point at the local model, but nothing is downloaded on this")
    p("      laptop yet. Double-click FREE_AI.bat once (it downloads %s, one time)." % model)
    p("  RESULT: not ready - no local model downloaded yet")
    return 1


# ---------------------------------------------------------------- the two commands
def status(echo_commands: bool = True) -> int:
    p("=" * 60)
    p("  AI status on this laptop  -  nothing is changed by this check")
    p("=" * 60)
    exe = find_ollama()
    have = installed_models(exe)
    up = server_up()
    prov, model = current_provider_model()

    p("")
    p("  1. Ollama program   : " + ("found  ->  " + exe if exe else
                                    "NOT installed"))
    if not exe:
        p("     -> double-click FREE_AI.bat once, it installs it (free, no account).")
    p("  2. local service    : " + ("running on " + ROOT_ADDR if up else
                                    "not running (the app starts it by itself when needed)"))
    p("  3. models (brains)  : " + (", ".join(have) if have else "NONE downloaded yet"))
    if not have:
        p("     -> this is the slow one-time download. FREE_AI.bat does it for you.")
    p("  4. app is set to    : " + (f"{prov or 'not set'} / {model or 'no model named'}"
                                   if (prov or model) else "nothing yet (no settings file)"))
    if have and model and model not in " ".join(have):
        p("     note: settings say '%s' which you do not have - the gateway uses '%s'"
          % (model, have[0]))
    if have and exe:
        rc, out = run_ollama(exe, ["--version"])
        p("  5. Ollama version   : " + (out.strip().splitlines()[-1] if out.strip() else "?"))
    p("")
    root = find_root()
    if root:
        p("  ALKIFAH_APP folder  : " + str(root))
        for bat in ("1-START-APP.bat", "ALKIFAH-BACKGROUND.bat"):
            f = root / bat
            if f.exists():
                txt = f.read_text(encoding="utf-8", errors="replace")
                p("  gateway auto-start  : " + ("on, in " + bat if "ALKIFAH-AI-GATEWAY" in txt
                                                else "NOT in " + bat))
    p("")
    if have and (up or exe):
        p("  RESULT: ready - start the app and press 'Generate Questions'.")
        p("          You do NOT need to keep an Ollama window open.")
        return 0
    p("  RESULT: not ready yet - double-click FREE_AI.bat and let it finish once.")
    return 1


def setup(skip_install: bool = False, want_model: str = "") -> int:
    p("=" * 60)
    p("  Free AI setup (Ollama on this laptop)  -  no account, no card")
    p("=" * 60)
    p("")

    # 1) the program itself
    p("[1/4] Ollama program")
    exe = find_ollama()
    if exe:
        p("  already installed: " + exe)
    elif skip_install:
        p("  [X] --skip-install was given and Ollama is not on this laptop.")
        return 2
    else:
        winget = shutil.which("winget")
        if not winget:
            p("  not installed, and winget was not found either.")
            p("  open this page in a browser and run the installer you get:")
            p("      https://ollama.com/download/windows")
            p("  then double-click FREE_AI.bat again.")
            return 2
        p("  installing with winget now (a few minutes, nothing to choose):")
        rc, _ = run_ollama(winget, ["install", "-e", "--id", "Ollama.Ollama",
                                     "--accept-source-agreements",
                                     "--accept-package-agreements"], show=True)
        if rc != 0:
            p("  [X] winget said %s. Download and run this instead:" % rc)
            p("      https://ollama.com/download/windows")
            return 2
        exe = find_ollama()
        if not exe:
            p("  [!] installed, but the command is not on PATH in this window yet.")
            p("      close this window and double-click FREE_AI.bat one more time.")
            return 3
        p("  [OK] installed: " + exe)

    # 2) the service
    p("")
    p("[2/4] local service (the part that answers the app)")
    if server_up():
        p("  [OK] already running on " + ROOT_ADDR + " - nothing to start")
    if not start_server():
        p("  [!] Ollama is installed but the service is quiet. Open the Ollama icon")
        p("      in the taskbar (bottom right) and run this once more. Continuing -")
        p("      the app itself also tries to start it on the first button press.")

    # 3) the model = the brain
    p("")
    p("[3/4] the model (this is the one-time download, it is the big part)")
    ram = ram_gb()
    model = want_model or pick_model(ram)
    p("  RAM detected: %s GB  ->  model chosen: %s" % (ram or "?", model))
    have = installed_models(exe)
    if have:
        p("  already downloaded: " + ", ".join(have))
        if model in " ".join(have):
            p("  [=] the model you need is already here - nothing to download.")
        else:
            p("  [=] keeping the one you have (%s) instead of downloading %s."
              % (have[0], model))
            model = have[0]
    else:
        p("  nothing downloaded yet, so downloading %s now." % model)
        p("  size is a few GB - you can leave this window and come back later;")
        p("  if the internet drops, run FREE_AI.bat again and it resumes.")
        rc, _ = run_ollama(exe, ["pull", model], show=True)
        have = installed_models(exe)
        if not have:
            p("  [X] the download did not finish (rc=%s). The rest of the app still" % rc)
            p("      works - only the AI button waits. Run FREE_AI.bat again.")
            return 4
        p("  [OK] model is on the laptop: " + ", ".join(have))
        model = have[0] if model not in " ".join(have) else model

    # 4) point the app at it
    p("")
    p("[4/4] telling the Alkifah app to use it")
    write_settings(model)
    p("")
    p("  ---- what the app sees now ----")
    rc = status()
    p("")
    p("  Next: double-click 1-START-APP.bat, open 'Assessment maker',")
    p("  pick a lesson and press 'Generate Questions by AI'.")
    p("  Log of everything above: ALKIFAH_APP\\FREE_AI_log.txt")
    return rc


# ---------------------------------------------------------------- entry
def main(argv: list[str]) -> int:
    if "--help" in argv or "-h" in argv:
        print(__doc__)
        print("also:  --cloud [groq|openrouter|gemini] [--key gsk_...]   a free fast model")
        print("       --local                                            back to offline")
        return 0
    if "--local" in argv:
        return local()
    if "--cloud" in argv:
        prov = "groq"
        for i, a in enumerate(argv):
            if a == "--provider" and i + 1 < len(argv):
                prov = argv[i + 1]
            elif a in CLOUD:
                prov = a
        key = ""
        if "--key" in argv:
            i = argv.index("--key")
            if i + 1 < len(argv):
                key = argv[i + 1]
        model = ""
        if "--model" in argv:
            i = argv.index("--model")
            if i + 1 < len(argv):
                model = argv[i + 1]
        return cloud(prov, key, model)
    want_model = ""
    if "--model" in argv:
        i = argv.index("--model")
        if i + 1 < len(argv):
            want_model = argv[i + 1]
    if "--status" in argv or "--check" in argv or "--list-only" in argv:
        return status()
    return setup(skip_install="--skip-install" in argv, want_model=want_model)


if __name__ == "__main__":
    code = 1
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except Exception:
        p("")
        p("[X] something went wrong while setting up the AI. Here is exactly what:")
        p(traceback.format_exc())
        p("")
        p("    Send ALKIFAH_APP\\FREE_AI_log.txt to whoever helps you - nothing else")
        p("    needs changing by hand, and no other part of the app is affected.")
        code = 5
    finally:
        try:
            write_logs()
        except Exception:
            pass
    raise SystemExit(code)
