#!/usr/bin/env python3
"""
Alkifah gateway — the small local relay between the app and the AI model.

WHY IT EXISTS
-------------
The "ولّد الأسئلة بالذكاء الاصطناعي" button posts to whatever address is written in
ALKIFAH_APP/webapp/.z-ai-config. The copy that shipped in the Drive folder pointed at
https://internal-api.z.ai/v1 with a session token belonging to the machine that built
the app. From a teacher's laptop that host is unreachable, and the app can only say
"مفيش اتصال بخدمة الذكاء الاصطناعي".

This relay listens on 127.0.0.1 only, speaks the dialect the app already speaks
(POST /v1/chat/completions, OpenAI-shaped JSON, and note: the app sends NO model
name), fills in the model, and forwards to a real backend:

    AI_PROVIDER = ollama      <- free, offline, on your own laptop (recommended)
    AI_PROVIDER = openai      <- needs a paid key
    AI_PROVIDER = groq        <- free tier, needs a key + internet
    AI_PROVIDER = openrouter  <- has :free models, needs a key + internet
    AI_PROVIDER = custom      <- any other OpenAI-compatible address (AI_BASE)

Settings come from ai_gateway_settings.txt next to this file (KEY = value lines).
With AI_PROVIDER=ollama no key is needed at all, and Ollama's native endpoint is used
automatically when the OpenAI-style one is missing (older Ollama versions).
"""
from __future__ import annotations

import json
import os
import re
import shutil
import time
import subprocess
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent

PROVIDERS = {
    # provider: (base url, default model)
    "ollama":     ("http://127.0.0.1:11434/v1", "llama3.2:3b"),
    "openai":     ("https://api.openai.com/v1", "gpt-4o-mini"),
    "openrouter": ("https://openrouter.ai/api/v1", "meta-llama/llama-3.2-3b-instruct:free"),
    "groq":       ("https://api.groq.com/openai/v1", "llama-3.3-70b-versatile"),
}
# the app sends fields that real providers reject as unknown -> keep only these
LEVEL_WORDS = ("easy", "medium", "hard")
ALLOWED = ("model", "messages", "temperature", "max_tokens", "top_p",
           "response_format", "stop", "stream", "seed", "frequency_penalty",
           "presence_penalty")


_ENV_START = dict(os.environ)


def read_settings_file() -> None:
    """ai_gateway_settings.txt = plain 'KEY = value' lines, editable in Notepad.

    It is re-read before every single request, so when you change a line and save the
    file, the next button press already uses it - no window to close and no restart.
    A value that was genuinely in the environment when the program started keeps
    winning (that is how the .bat files pass a port)."""
    f = HERE / "ai_gateway_settings.txt"
    if not f.exists():
        return
    try:
        text = f.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip().upper(), v.strip().strip("\"'")
        if not k.startswith("AI_") or k in _ENV_START:
            continue
        if v:
            os.environ[k] = v
        else:
            os.environ.pop(k, None)      # the line was emptied or deleted -> knob is off


OLLAMA_DEFAULT = "http://127.0.0.1:11434"
_LOCK = threading.Lock()
_last_wake = 0.0
_last_wake_failed = False


def ollama_root(base: str = "") -> str:
    """Where the local Ollama server lives. AI_OLLAMA in the settings file overrides
    it (useful when Ollama runs on another port or on another machine in the room)."""
    ov = (os.environ.get("AI_OLLAMA") or "").strip().rstrip("/")
    if ov:
        return ov
    if base:
        root = base[:-3].rstrip("/") if base.endswith("/v1") else base
        if "127.0.0.1" in root or "localhost" in root:
            return root
    return OLLAMA_DEFAULT


def reachable(root: str) -> bool:
    """True when an Ollama server answers on that address."""
    try:
        with urllib.request.urlopen(root + "/api/tags", timeout=1.5):
            return True
    except Exception:
        return False


def installed_ollama(base: str = "") -> bool:
    return reachable(ollama_root(base))


def ollama_program() -> str | None:
    """The Ollama program itself (not the server) - i.e. is it installed at all."""
    found = shutil.which("ollama") or shutil.which("ollama.exe")
    if found:
        return found
    if os.name == "nt":
        spots = [os.path.expandvars(r"%LOCALAPPDATA%\Programs\Ollama\ollama.exe"),
                 os.path.expandvars(r"%ProgramFiles%\Ollama\ollama.exe"),
                 r"C:\Program Files\Ollama\ollama.exe"]
    else:
        spots = ["/usr/local/bin/ollama", "/usr/bin/ollama"]
    for cand in spots:
        if cand and os.path.exists(cand):
            return cand
    return None


def wake_ollama(base: str = "", wait: float = 20.0) -> bool:
    """The teacher's exact situation: Ollama IS installed, but nobody started it
    (the tray icon was closed / the PC was rebooted). Instead of failing, start the
    local server here and wait for the port to open.

    Guarded so a broken install cannot pile up processes: one attempt per 2 minutes,
    and the attempt runs while holding the lock so parallel requests share it."""
    global _last_wake, _last_wake_failed
    root = ollama_root(base)
    if reachable(root):
        return True
    with _LOCK:
        if time.time() - _last_wake < 120:
            return reachable(root)          # tried recently - do not spam
        _last_wake = time.time()
        if _last_wake_failed and not reachable(root):
            pass                             # still try once more after the cool-down
        exe = ollama_program()
        if not exe:
            _last_wake_failed = True
            return False
        kw = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL,
              "stderr": subprocess.DEVNULL, "cwd": os.path.dirname(exe) or None}
        try:
            if os.name == "nt":       # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
                kw["creationflags"] = 0x00000008 | 0x00000200
            else:
                kw["start_new_session"] = True
            subprocess.Popen([exe, "serve"], **kw)
        except Exception:
            _last_wake_failed = True
            return False
        deadline = time.time() + wait
        while time.time() < deadline:
            if reachable(root):
                _last_wake_failed = False
                return True
            time.sleep(0.6)
        _last_wake_failed = True
        return reachable(root)


def settings() -> tuple[str, str, str, str]:
    read_settings_file()
    provider = (os.environ.get("AI_PROVIDER") or "").strip().lower()
    model = (os.environ.get("AI_MODEL") or "").strip()
    key = (os.environ.get("AI_KEY") or "").strip()
    if not key:
        f = HERE / "ai_gateway_key.txt"
        if f.exists():
            key = f.read_text(encoding="utf-8").strip()
    if not provider:
        provider = "ollama" if installed_ollama() else "openai"
    if provider == "custom":
        base = (os.environ.get("AI_BASE") or "").rstrip("/")
        model = model or "llama3.2:3b"
    else:
        base, default_model = PROVIDERS.get(provider, PROVIDERS["openai"])
        base = (os.environ.get("AI_BASE") or base).rstrip("/")
        model = model or default_model
        if provider == "ollama":
            model = model if model != PROVIDERS["openai"][1] else PROVIDERS["ollama"][1]
            key = key or "ollama"          # Ollama needs no key; the header must exist
    return provider, base, model, key


def local_models(root: str = "") -> list[str]:
    """Model names this Ollama has actually downloaded."""
    try:
        with urllib.request.urlopen(ollama_root(root) + "/api/tags", timeout=3) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        return [m.get("name", "") for m in data.get("models", []) if m.get("name")]
    except Exception:
        return []


BROWSER_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")


def _ua_headers(extra: dict) -> dict:
    h = dict(extra)
    h.setdefault("User-Agent", BROWSER_UA)
    return h


def discover_model(base: str, key: str, exclude=()) -> str:
    """Ask the provider which models it actually has (GET /models, the same
    OpenAI-compatible family). Providers retire model names without warning
    (Groq did it on 2026-08-16), so a dead name must not be the end of the line."""
    try:
        req = urllib.request.Request(base.rstrip("/") + "/models",
                                     headers=_ua_headers({"Authorization": "Bearer " + key}))
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
        ids = [str((m or {}).get("id") or "").strip() for m in data.get("data", [])]
        ids = [i for i in ids if i and i not in set(exclude)]
        if not ids:
            return ""
        for pref in ("openai/gpt-oss-20b", "openai/gpt-oss-120b"):
            if pref in ids:
                return pref
        for i in ids:
            low = i.lower()
            if any(k in low for k in ("gpt-oss", "llama", "qwen", "mistral", "gemma", "mixtral")):
                return i
        return ids[0]
    except Exception:
        return ""


def _persist_model(model: str) -> None:
    """The relay found the provider's replacement for a retired model, so save it in
    the settings (every other line she edited is kept, the old file is backed up)."""
    try:
        f = HERE / "ai_gateway_settings.txt"
        old = f.read_text(encoding="utf-8", errors="replace") if f.exists() else ""
        if old:
            try:
                f.with_name(f.name + ".before-model-" + time.strftime("%Y%m%d-%H%M%S")
                            ).write_text(old, encoding="utf-8")
            except Exception:
                pass
        out, seen = [], False
        for line in old.splitlines():
            st = line.strip()
            if st and not st.startswith("#") and st.split("=", 1)[0].strip().upper() == "AI_MODEL":
                out.append("AI_MODEL = %s" % model)
                seen = True
            else:
                out.append(line)
        if not seen:
            out.append("AI_MODEL = %s" % model)
        f.write_text("\n".join(out).strip() + "\n", encoding="utf-8")
    except Exception:
        pass


def ask_openai(base: str, key: str, body: dict, timeout: float = 600) -> dict:
    req = urllib.request.Request(
        base + "/chat/completions", data=json.dumps(body).encode("utf-8"),
        headers=_ua_headers({"Content-Type": "application/json",
                             "Authorization": f"Bearer {key}"}),
        method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def ask_ollama_native(base: str, model: str, body: dict, timeout: float = 600) -> dict:
    """Older Ollama builds have no /v1 endpoint - /api/chat always exists.
    format:"json" is what makes small models answer in parseable JSON."""
    payload = {"model": model, "messages": body.get("messages", []),
               "stream": False, "format": "json",
               "options": {"temperature": body.get("temperature", 0.4)}}
    root = base[:-3].rstrip("/") if base.endswith("/v1") else base
    req = urllib.request.Request(
        root + "/api/chat", data=json.dumps(payload).encode("utf-8"),
        headers=_ua_headers({"Content-Type": "application/json"}), method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode("utf-8", "replace"))
    return {"choices": [{"message": data.get("message") or
                         {"role": "assistant", "content": data.get("response", "")}}]}


# ---------------------------------------------------------------- answer repair
# The compiled app parses the answer with this rule and shows
# "رد الذكاء الاصطناعي ما كانش بصيغة مفهومة" when NOTHING survives it:
#     strip ``` fences -> take the text between the first [ and the last ]
#     -> JSON.parse -> must be an ARRAY -> each item needs a non-empty "text",
#        exactly 4 non-empty "options", "correct" as 0..3, "level" in Easy/Medium/Hard.
# A 3-billion-parameter model answers in whatever shape it likes (often an OBJECT,
# because "json mode" forbids a bare array), so the relay rebuilds the answer into
# exactly that shape before handing it to the app. That is the whole point of this file.
LEVELS = {"easy": "Easy", "medium": "Medium", "hard": "Hard", "سهل": "Easy",
          "متوسط": "Medium", "متوسطه": "Medium", "متوسطة": "Medium", "صعب": "Hard"}
TEXT_KEYS = ("text", "question", "q", "body", "prompt", "السؤال", "سؤال")
OPT_KEYS = ("options", "choices", "answers", "alternatives", "option", "الخيارات")
CORR_KEYS = ("correct", "answer", "correct_index", "correctAnswer", "answer_index",
             "right", "الإجابة", "اجابة", "الإجابة")
LEVEL_KEYS = ("level", "difficulty", "bloom", "الدifficulty", "الصعوبة")
LIST_KEYS = ("questions", "items", "data", "result", "mcqs", "quiz", "array")


def _opts_of(item: dict) -> list[str]:
    for k in OPT_KEYS:
        v = item.get(k)
        if isinstance(v, list):
            return [str(x).strip() for x in v]
    letters = [str(item[k]).strip() for k in ("a", "b", "c", "d") if item.get(k)]
    if len(letters) == 4:
        return letters
    return []


def _correct_of(item: dict, opts: list[str]) -> int:
    for k in CORR_KEYS:
        if k not in item:
            continue
        v = item[k]
        if isinstance(v, bool):
            continue
        if isinstance(v, (int, float)) and 0 <= int(v) <= 3:
            return int(v)
        t = str(v).strip().strip('"\'')
        if t.isdigit() and 0 <= int(t) <= 3:
            return int(t)
        if len(t) == 1 and t.upper() in "ABCD":                  # "B"
            return "ABCD".index(t.upper())
        low = t.lower()
        for i, o in enumerate(opts[:4]):                          # the answer text
            if o and (o.lower() == low or low in o.lower()):
                return i
        break
    return 0


def _one(item) -> dict | None:
    if not isinstance(item, dict):
        if isinstance(item, str):                                  # "Q: ... ) a b c d"
            return None
        return None
    text = ""
    for k in TEXT_KEYS:
        if item.get(k):
            text = str(item[k]).strip()
            break
    opts = [o for o in _opts_of(item) if o]
    if len(opts) < 4:
        return None                                                # never invent distractors
    lvl = LEVELS.get(str(item.get("level") or "").strip().lower(), "")
    if not lvl:
        for k in LEVEL_KEYS:
            if item.get(k):
                lvl = LEVELS.get(str(item[k]).strip().lower(), "Easy")
                break
    return {"text": text, "options": opts[:4], "correct": _correct_of(item, opts),
            "level": lvl or "Easy", "mark": 1}


def _lists_inside(node, depth: int = 0) -> list[list]:
    """Find every list-of-question-shaped things, so an OBJECT answer like
    {"questions": [...]} or {"0": {...}, "1": {...}} still works."""
    out: list[list] = []
    if depth > 4 or node is None:
        return out
    if isinstance(node, list):
        if any(isinstance(x, dict) for x in node):
            out.append(node)
        for x in node:
            out.extend(_lists_inside(x, depth + 1))
    elif isinstance(node, dict):
        for k in LIST_KEYS:
            if isinstance(node.get(k), list):
                out.append(node[k])
        keyed = [(int(k), x) for k, x in node.items() if str(k).isdigit() and isinstance(x, dict)]
        if len(keyed) >= 2:                                        # {"0":{..},"1":{..}}
            out.append([x for _, x in sorted(keyed)])
        for v in node.values():
            out.extend(_lists_inside(v, depth + 1))
    return out


def _spans(t: str) -> list[str]:
    """The balanced top-level [...] and {...} pieces of a text, in order. Bracket
    matching (not "first [ to last ]") is what keeps an options array inside a single
    question object from being mistaken for the answer itself."""
    out: list[str] = []
    depth, start_i, in_str, esc = 0, -1, False, False
    for i, ch in enumerate(t):
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "[{":
            if depth == 0:
                start_i = i
            depth += 1
        elif ch in "]}":
            if depth:
                depth -= 1
                if depth == 0 and start_i >= 0:
                    out.append(t[start_i:i + 1])
                    start_i = -1
    return out


def _loads(cand: str):
    fixed = re.sub(r",\s*([}\]])", r"\1", cand)                    # trailing comma
    fixed = re.sub(r"([{[])\s*,+\s*", r"\1", fixed)                # comma right after [
    for text in (cand, fixed, re.sub(r"([{[])\s*,+\s*", r"\1", cand)):
        try:
            return json.loads(text)
        except Exception:
            continue
    return None


def _jsonish(text: str):
    """Find the JSON inside a chatty model answer. A real question array wins over
    anything else, because that is the shape the app can actually use."""
    t = (text or "").strip()
    t = re.sub(r"```(?:json|javascript)?", "", t, flags=re.I).strip()
    while len(t) > 1 and t[0] == '"' and t[-1] == '"':
        t = t[1:-1].strip()            # the whole answer wrapped as one quoted string
    for a, b in (("\u201c", "\u201d"), ("\u00ab", "\u00bb"), ("\u2018", "\u2019")):
        t = t.replace(a, '"').replace(b, '"')
    cands = _spans(t) + [t]
    for a, b in (("[", "]"), ("{", "}")):
        i, j = t.find(a), t.rfind(b)
        if 0 <= i < j:
            cands.append(t[i:j + 1])
    fallback: dict | None = None
    for c in cands:
        v = _loads(c)
        if isinstance(v, list) and any(isinstance(x, dict) for x in v):
            return v
        if isinstance(v, dict) and fallback is None:
            fallback = v
        if isinstance(v, list) and not v:
            continue
    return fallback


def clean_questions(text: str, want: int) -> list[dict]:
    """The answer, in the exact shape the app accepts (or an empty list)."""
    obj = _jsonish(text)
    if obj is None:
        return []
    items: list = []
    if isinstance(obj, dict) and any(k in obj for k in TEXT_KEYS):
        obj = [obj]                                       # {"text":...,"options":[...]}
    if isinstance(obj, list):
        items = obj
    else:
        for lst in _lists_inside(obj):
            if len(lst) > len(items):
                items = lst
    out, seen = [], set()
    for it in items:
        q = _one(it)
        if q and q["text"].lower()[:90] not in seen:
            seen.add(q["text"].lower()[:90])
            out.append(q)
        if len(out) >= max(1, want):
            break
    return out


def asked_count(messages: list) -> int:
    """The app writes "Write 5 multiple-choice questions" in its prompt - respect it."""
    for m in messages:
        t = str(m.get("content", ""))
        mm = re.search(r"(?i)write\s+(\d{1,2})\s+(?:multiple|short|questions|أسئلة)", t)
        if mm:
            return max(1, min(20, int(mm.group(1))))
    return 5


FIX_HINT = ("Your previous reply was not accepted. Reply with ONLY a JSON array of "
            "question objects and nothing else, exactly like this shape: "
            '[{"text":"...","options":["a","b","c","d"],"correct":0,"level":"Easy"}]. '
            "Rules: one object per question, always 4 non-empty options, "
            '"correct" is the number 0, 1, 2 or 3 (which option is right), '
            '"level" is Easy or Medium or Hard. No names other than these four keys.')


def debug_note(line: str) -> None:
    """A rolling log so a teacher can send ONE file instead of describing the problem."""
    f = HERE / "ai_gateway_debug.txt"
    try:
        old = f.read_text(encoding="utf-8", errors="replace").splitlines()[-160:] if f.exists() else []
        f.write_text("\n".join((old + ["%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), line)])[-160:]),
                     encoding="utf-8")
    except Exception:
        pass



# ------------------------------------------------- ALKIFAH: write in the background
# Her exact failure: llama3.1:8b on a laptop needs about a minute per answer, and the app
# stops waiting at about a minute - so the button came back empty. The relay now does the
# writing on a background thread: the press answers as soon as ANY question is ready, the
# thread keeps going after that, and finished questions are kept in ai_gateway_cache.json
# (a second press is answered at once, and a lesson already written is never paid for
# twice). Knobs: AI_MODEL_SECONDS = how long one try may take (default 300),
# AI_NO_CACHE = 1 turns the keeping off. The cache is one plain text file she can delete.
CACHE_PATH = HERE / "ai_gateway_cache.json"
CACHE_MAX = 60
_JOBS: dict = {}
_JOBS_LOCK = threading.Lock()
_CACHE_LOCK = threading.Lock()


def _flag(name: str) -> bool:
    return str(os.environ.get(name) or "").strip().lower() in ("1", "true", "yes", "on")


def job_cap() -> float:
    """How long the background writing may take in TOTAL (all its tries together)."""
    try:
        v = float(os.environ.get("AI_JOB_SECONDS") or 240)
    except Exception:
        v = 240.0
    return v if v >= 20 else 240.0


def job_timeout() -> float:
    try:
        v = float(os.environ.get("AI_MODEL_SECONDS") or 300)
    except Exception:
        v = 300.0
    return v if v >= 20 else 300.0


def again_window() -> float:
    """How long finished questions stay in memory for the NEXT press (seconds)."""
    try:
        v = float(os.environ.get("AI_AGAIN_SECONDS") or 90)
    except Exception:
        v = 90.0
    return v if 10 <= v <= 7200 else 90.0


def cache_fresh(entry: dict) -> bool:
    try:
        at = time.mktime(time.strptime(str(entry.get("at")), "%Y-%m-%d %H:%M:%S"))
    except Exception:
        return False
    return (time.time() - at) <= again_window()


def cache_key(body: dict) -> str:
    import hashlib
    try:
        raw = json.dumps(body, sort_keys=True, ensure_ascii=False)
    except Exception:
        raw = repr(body)
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:16]


def _cache_read() -> dict:
    try:
        d = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def cache_get(key: str) -> list:
    if _flag("AI_NO_CACHE"):
        return []
    entry = _cache_read().get(key) or {}
    if not cache_fresh(entry):
        return []                    # too old to be "the same generation" - ask anew
    got = entry.get("questions") or []
    return got if isinstance(got, list) else []


def cache_put(key: str, qs: list, model: str = "") -> None:
    if not qs or _flag("AI_NO_CACHE"):
        return
    with _CACHE_LOCK:
        d = _cache_read()
        d[key] = {"at": time.strftime("%Y-%m-%d %H:%M:%S"), "model": model,
                  "questions": qs}
        d = {k: d[k] for k in list(d)[-CACHE_MAX:]}
        tmp = CACHE_PATH.with_name(CACHE_PATH.name + ".tmp")
        try:
            tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
            if CACHE_PATH.exists():
                CACHE_PATH.unlink()
            tmp.rename(CACHE_PATH)
        except Exception:
            pass


def questions_json(qs: list, model, want: int) -> bytes:
    return json.dumps({
        "choices": [{"message": {"role": "assistant",
                                 "content": json.dumps(qs, ensure_ascii=False)}}],
        "model": model, "object": "chat.completion",
        "alkifah_gateway": {"kept": len(qs), "asked": want}}, ensure_ascii=False).encode("utf-8")


def publish(job: dict, qs: list, err: str = "", model: str = "") -> None:
    with _JOBS_LOCK:
        job["q"] = list(qs)
        if err:
            job["err"] = err
    if qs:
        cache_put(job["key"], list(qs), model)


def run_job(h, provider, base, apikey, out, want, want_level, job) -> None:
    """The writing itself. Publishes every question it manages - so a press that arrives
    while this is still running gets them, instead of waiting for the whole set."""
    tmo = job_timeout()
    cap = job_cap()
    began = time.time()
    with _JOBS_LOCK:
        acc: list = list(job.get("q") or [])
    data, err = h._forward(provider, base, apikey, out, tmo=tmo)
    tries = 4 if want else 3
    content = ""
    for attempt in range(tries):
        if not err:
            try:
                msg = (data.get("choices") or [{}])[0].get("message") or {}
                content = msg.get("content") or msg.get("reasoning_content") or ""
            except Exception:
                content = ""
        if not isinstance(content, str):
            content = json.dumps(content, ensure_ascii=False)
        got = clean_questions(content, max(1, (want - len(acc)) if want else 12))
        if acc:
            known = {q["text"].lower()[:70] for q in acc}
            got = [g for g in got if g["text"].lower()[:70] not in known]
        if got and want_level in LEVEL_WORDS:
            for q in got:
                q["level"] = want_level.capitalize()
        if got:
            acc.extend(got)
            debug_note("attempt %d: kept %d question(s) from a %d-char answer"
                       % (attempt + 1, len(got), len(content)))
        else:
            debug_note("attempt %d: nothing usable in the answer, raw starts with %r"
                       % (attempt + 1, content[:240]))
        publish(job, acc, err if not acc else "", str(out.get("model") or ""))
        if want and len(acc) >= want:
            break
        if err or attempt == tries - 1:
            break
        if time.time() - began > cap:
            debug_note("the background job stopped after %ds with %d question(s) "
                       "(AI_JOB_SECONDS=%g) - press Generate again for the rest"
                       % (time.time() - began, len(acc), cap))
            break
        out2 = dict(out)
        msgs = list(out2.get("messages") or [])
        if acc:
            msgs.append({"role": "assistant",
                         "content": json.dumps(acc, ensure_ascii=False)[:4000]})
            msgs.append({"role": "user", "content":
                         "Those were good. Write %d MORE questions about the SAME lesson, "
                         "in the same language, and do not repeat any of these: %s"
                         % (max(1, want - len(acc)) if want else 4,
                            "; ".join(q["text"][:60] for q in acc)[-900:])})
        else:
            msgs.append({"role": "assistant", "content": content[:1200]})
            msgs.append({"role": "user", "content": FIX_HINT})
        out2["messages"] = msgs
        data, err = h._forward(provider, base, apikey, out2, tmo=tmo)
    if not acc:
        preview = ""
        try:
            preview = " ".join(((data.get("choices") or [{}])[0].get("message") or {})
                               .get("content", "").split())[:160]
        except Exception:
            pass
        if not err:
            err = ("AL-KIFAH AI GATEWAY: the model answered %d time(s) but never in the "
                   "question shape the app needs (it wants %d questions, each with 4 "
                   "options). What it said, in short: %r. The full answer is in "
                   "ai_gateway_debug.txt next to this file - send that file if it keeps "
                   "happening. A bigger model usually fixes it (ollama pull llama3.1:8b, "
                   "then AI_MODEL = llama3.1:8b); if it is only too slow, use "
                   "AI_MODEL = llama3.2:3b instead." % (tries, want, preview))
            job["code"] = 502
        with _JOBS_LOCK:
            job["err"] = err
    with _JOBS_LOCK:
        job["done"] = True
    publish(job, acc, "", str(out.get("model") or ""))
    debug_note("background job finished: %d question(s)" % len(acc))


def start_job(h, key, provider, base, apikey, out, want, want_level) -> dict:
    with _JOBS_LOCK:
        j = _JOBS.get(key)
        if j is not None and not j.get("done"):
            return j                                     # the last press is still writing
        j = {"key": key, "q": cache_get(key), "err": "", "done": False}
        for stale in list(_JOBS)[:-39]:       # only the last lessons are worth keeping
            if _JOBS[stale].get("done"):
                _JOBS.pop(stale, None)
        _JOBS[key] = j
    threading.Thread(target=_guarded_job, daemon=True,
                     args=(j, h, provider, base, apikey, out, want, want_level)).start()
    debug_note("a background job is writing this lesson (started with %d question(s) "
               "already kept)" % len(j["q"]))
    return j


def _guarded_job(j, h, *a) -> None:
    try:
        run_job(h, *a, j)
    except BaseException as e:                    # a broken job must never kill the relay
        with _JOBS_LOCK:
            j["err"] = j.get("err") or ("AL-KIFAH AI GATEWAY: the background writing "
                                        "stopped (%s)" % type(e).__name__)
            j["done"] = True


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("[gateway] %s\n" % (fmt % args))

    def _forward(self, provider: str, base: str, key: str, body: dict, tmo=None):
        """One call to the real backend. Returns (answer, error message) - never raises,
        so a bad reply from the model can always be reported instead of crashing.

        The call is given only the time the app is still expected to wait for it
        (AI_MAX_SECONDS, 50 by default): a model that freezes must not keep the app
        hanging until the app gives up and shows 'no connection'."""
        left = float(tmo) if tmo else self._alk_left()
        try:
            return ask_openai(base, key, body, timeout=left), None
        except (socket.timeout, TimeoutError):
            return None, ("AL-KIFAH AI GATEWAY: %s did not answer within %.0f seconds. The "
                          "lesson text is probably too long for this model, or the model is "
                          "too big for this laptop. Set AI_MODEL = llama3.2:3b in "
                          "ai_gateway_settings.txt for the small fast one (it answers about "
                          "3x sooner), or AI_LESSON_CHARS = 1500 to show the model less text."
                          % (body.get("model"), left))
        except urllib.error.HTTPError as e:
            detail = e.read().decode("utf-8", "replace")[:300]
            if provider == "ollama" and e.code in (400, 404, 422):
                try:                        # /v1 missing or strict -> native endpoint
                    return ask_ollama_native(base, body.get("model", ""), body), None
                except Exception as e2:
                    return None, (f"AL-KIFAH AI GATEWAY: Ollama refused the request "
                                  f"(HTTP {e.code}: {detail}) and the native endpoint failed "
                                  f"too ({type(e2).__name__}: {e2}).")
            if provider != "ollama" and e.code == 404 and (
                    "model_not_found" in detail or "does not exist" in detail):
                dead = str(body.get("model") or "")
                found = discover_model(base, key, exclude=[dead])
                if found and found != dead:
                    _persist_model(found)
                    debug_note("the provider retired model '%s' - switched to '%s' "
                               "(saved in ai_gateway_settings.txt, nothing to restart)"
                               % (dead, found))
                    retry = dict(body)
                    retry["model"] = found
                    try:
                        return ask_openai(base, key, retry, timeout=left), None
                    except Exception:
                        pass
                return None, (f"AL-KIFAH AI GATEWAY: the provider says the model "
                              f"'{dead}' no longer exists (providers retire model names "
                              f"without warning). The current list was requested and "
                              f"nothing matching was found - re-run FAST_AI.bat and "
                              f"choose 1, it picks the provider's current free model by "
                              f"itself. (HTTP {e.code}: {detail})")
            rescued = self._rescue(body, "HTTP %s" % e.code) \
                if e.code in (408, 429, 500, 502, 503, 504) else None
            if rescued is not None:
                return rescued, None
            return None, (f"AL-KIFAH AI GATEWAY: the provider refused the request "
                          f"(HTTP {e.code}): {detail}. Model in use: {body.get('model')}. "
                          f"Check ai_gateway_key.txt / ai_gateway_settings.txt and try again.")
        except Exception as e:
            if provider == "ollama":
                try:
                    return ask_ollama_native(base, body.get("model", ""), body,
                                             timeout=left), None
                except Exception as e2:
                    wake_ollama(base, wait=6.0)      # maybe it just woke up
                    return None, (f"AL-KIFAH AI GATEWAY: cannot reach Ollama "
                                  f"({type(e).__name__}). Open Ollama (or double-click "
                                  f"FREE_AI.bat) and try again. Native endpoint also failed: {e2}")
            rescued = self._rescue(body, type(e).__name__)
            if rescued is not None:
                return rescued, None
            return None, (f"AL-KIFAH AI GATEWAY: cannot reach {base} ({type(e).__name__}) - "
                          f"check the internet connection and try again. If the internet is "
                          f"off, set AI_PROVIDER = ollama in ai_gateway_settings.txt (or "
                          f"double-click FAST_AI.bat and choose 2) and the laptop answers "
                          f"from itself.")

    def _alk_left(self) -> float:
        """Seconds still left of the app's patience - never less than 12, so one call
        always has a fair chance even when the budget was set small."""
        try:
            spent = time.time() - getattr(self, "_alk_t0", time.time())
            return max(12.0, getattr(self, "_alk_budget", 50.0) - spent)
        except Exception:
            return 600.0

    def _send(self, code: int, payload: bytes, ctype="application/json"):
        try:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, OSError):
            # the app stopped waiting (its own timeout) - nothing is broken here, the
            # answer is still kept for the next press and written to the debug file.
            try:
                debug_note("the app closed the connection before the answer was written "
                           "(%d bytes were ready)" % len(payload))
            except Exception:
                pass

    def _rescue(self, body: dict, why: str):
        """A free internet model that is throttled, quota-empty or simply unreachable must
        never be the reason the teacher gets nothing: if a local model is awake on this
        laptop, answer from it and write one line in the debug file. Returns None when
        there is nothing local to fall back to (or when the local attempt fails too)."""
        try:
            if settings()[0] == "ollama":
                return None                      # already the local one - no rescue needed
            root = ollama_root()
            if not reachable(root):
                return None
            have = local_models(root)
            if not have:
                return None
            out = dict(body)
            out["model"] = have[0]
            out.setdefault("response_format", {"type": "json_object"})
            data = ask_openai(root + "/v1", "ollama", out, timeout=job_timeout())
            debug_note("the internet model was unavailable (%s) - answered from the local "
                       "model %s on this laptop instead" % (why, have[0]))
            return data
        except Exception as e:
            debug_note("the local fallback did not work either (%s)" % type(e).__name__)
            return None

    def _fail(self, text: str, code: int = 500):
        # 5xx + plain text = the app puts THIS sentence in its red toast
        self._send(code, text.encode("utf-8", "replace"), "text/plain")

    def do_GET(self):
        provider, base, model, key = settings()
        self._send(200, json.dumps({
            "ok": True, "service": "alkifah-gateway", "provider": provider,
            "base": base, "model": model, "key_present": bool(key),
            "ollama_installed": bool(ollama_program()),
            "ollama_running": installed_ollama(base),
            "ollama_models": local_models(ollama_root(base))}).encode())

    def do_POST(self):
        # Always drain the body BEFORE answering: Node's fetch keeps the connection
        # open, and unread bytes would be parsed as the next request ("Bad request
        # version") and break every call after the first error.
        body: dict | None
        try:
            raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
            body = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            body = None
        self._alk_t0 = time.time()    # the clock the timeouts are measured against
        read_settings_file()        # an edit in Notepad works without restarting
        provider, base, model, key = settings()
        if body is None:
            return self._fail("AL-KIFAH AI GATEWAY: the request body was not valid JSON.", 400)

        out = {k: v for k, v in body.items() if k in ALLOWED}
        out.setdefault("model", model)
        if not out.get("messages"):
            return self._fail("AL-KIFAH AI GATEWAY: no messages in the request.")
        # On a small laptop the slow part is the WHOLE lesson text the app sends in
        # (up to 20.000 characters) plus an uncapped answer. Trimming the middle of the
        # lesson and capping the answer is what turns a 65 second wait into ~15.
        # Knobs in ai_gateway_settings.txt: AI_LESSON_CHARS, AI_MAX_TOKENS.
        try:
            cap = int(os.environ.get("AI_LESSON_CHARS") or 2600)
        except Exception:
            cap = 2600
        if cap > 0:
            msgs0 = list(out.get("messages") or [])
            big_i, big_n = -1, 0
            for i, m in enumerate(msgs0):
                n = len(str(m.get("content") or ""))
                if n > big_n:
                    big_i, big_n = i, n
            if big_i >= 0 and big_n > cap:
                keep = str(msgs0[big_i].get("content") or "")
                m = dict(msgs0[big_i])
                m["content"] = (keep[:cap * 3 // 5]
                                 + "\n\n[ ... وسط الدرس اتقصي عشان الرد ييجي بسرعة ... ]\n\n"
                                 + keep[-(cap * 2 // 5):])
                msgs0[big_i] = m
                out["messages"] = msgs0
                debug_note("prompt trimmed from %d to %d chars (AI_LESSON_CHARS=%d)"
                           % (big_n, len(m["content"]), cap))
        try:
            mt = int(os.environ.get("AI_MAX_TOKENS") or 900)
            if mt > 0 and int(out.get("max_tokens") or 0) > mt:
                out["max_tokens"] = mt
                debug_note("answer capped at max_tokens=%d" % mt)
        except Exception:
            pass

        # AI_LEVEL = easy  (written by the installer, editable in Notepad) makes the
        # academy's rule real: the model is TOLD it, and the answer is labelled with it.
        want_level = (os.environ.get("AI_LEVEL") or "").strip().lower()
        notes = []
        if want_level in LEVEL_WORDS:
            notes.append("every question must be level '%s'. Recall questions only - "
                         "no long reasoning, no trick options." % want_level.capitalize())
        min_q = 0
        for k in ("AI_QUESTIONS", "AI_MIN_QUESTIONS"):
            try:
                min_q = int(os.environ.get(k) or 0)
                if min_q > 0:
                    break
            except Exception:
                min_q = 0
        self._alk_min_q = min_q if 0 < min_q <= 20 else 0
        if self._alk_min_q:
            notes.append("write EXACTLY %d questions inside the array, numbered 1 to %d, "
                         "not fewer." % (self._alk_min_q, self._alk_min_q))
        if notes and out.get("messages"):
            msgs = list(out["messages"])
            last = dict(msgs[-1])
            last["content"] = (str(last.get("content", "")) +
                               "\n\nIMPORTANT: " + " Also: ".join(notes))
            msgs[-1] = last
            out["messages"] = msgs

        if provider == "ollama":
            # small local models only behave when they are forced to emit JSON
            out.setdefault("response_format", {"type": "json_object"})
            root = ollama_root(base)
            if not reachable(root) and not wake_ollama(base):
                if ollama_program():
                    return self._fail(
                        "AL-KIFAH AI GATEWAY: Ollama is installed on this laptop but not "
                        "running, and starting it from here failed. Open Ollama from the "
                        "taskbar icons (bottom right) or double-click FREE_AI.bat once, "
                        "then press Generate again. Nothing else in the app needs Ollama.")
                return self._fail(
                    "AL-KIFAH AI GATEWAY: Ollama is not installed on this laptop. "
                    "Double-click FREE_AI.bat once - it installs Ollama and downloads one "
                    "model, free, no account and no key. Until then the AI button stays "
                    "off but uploads and everything else work as usual.")
            have = local_models(root)
            if not have:
                return self._fail(
                    "AL-KIFAH AI GATEWAY: Ollama is running but no model is downloaded on "
                    "it yet - Ollama alone is only the player, the model is the brain. "
                    "Double-click FREE_AI.bat once (it runs: ollama pull llama3.2:3b, "
                    "about 2 GB, one time) and press Generate again.")
            if model not in " ".join(have):
                out["model"] = have[0]          # use what she actually downloaded
                model = out["model"]
        elif not key:
            return self._fail(
                "AL-KIFAH AI GATEWAY: no key yet. Open Alkifah_LMS_App/app/ai_gateway_key.txt "
                "in Notepad, paste your AI key there, save the file, then press the button "
                "again - or set AI_PROVIDER = ollama in ai_gateway_settings.txt for a free "
                "offline model.")

        try:
            self._alk_budget = float(os.environ.get("AI_MAX_SECONDS") or 45)
        except Exception:
            self._alk_budget = 45.0
        if self._alk_budget < 8:
            self._alk_budget = 45.0

        want = asked_count(out.get("messages") or [])
        if getattr(self, "_alk_min_q", 0) > want:
            want = self._alk_min_q     # never let a spec be saved with fewer questions

        ckey = cache_key(out)
        kept = cache_get(ckey)
        if want and len(kept) >= want:
            debug_note("answered from ai_gateway_cache.json: %d question(s) written %s for this "
                   "lesson (kept %.0fs for the next press)"
                   % (len(kept), "just now", again_window()))
            return self._send(200, questions_json(kept[:want], out.get("model"), want))

        # the writing runs on its own thread, so the app can hang up without losing it
        job = start_job(self, ckey, provider, base, key, out, want, want_level)
        with _JOBS_LOCK:
            seed_n = len(job["q"])     # what the last press already left behind
        window = max(10.0, self._alk_budget - 6.0)
        stop = time.time() + window
        while True:
            with _JOBS_LOCK:
                qs, done = list(job["q"]), bool(job["done"])
            # answer as soon as the model made something NEW (or the job is over); if it is
            # still chewing on the first question, use the whole window rather than reply
            # "the same two questions" a second early.
            if done or len(qs) > seed_n or (seed_n and time.time() >= stop) \
               or (not seed_n and (qs or time.time() >= stop)):
                break
            time.sleep(0.4)
        with _JOBS_LOCK:
            qs, err = list(job["q"]), job.get("err") or ""
        if not qs:
            if err:
                return self._fail(err, int(job.get("code") or 500))
            debug_note("no question was ready in %.0fs - the job keeps running and the "
                       "next press is answered from it" % window)
            return self._fail(
                "AL-KIFAH AI GATEWAY: the model is slow on this laptop and had not finished "
                "one whole question in %.0f seconds - so instead of throwing the work away, "
                "the relay LEFT IT RUNNING in the background. Wait about half a minute and "
                "press Generate again: the questions come to the app as soon as each one is "
                "ready, and the relay remembers them. If you want the first press to be "
                "enough, set AI_MODEL = llama3.2:3b in ai_gateway_settings.txt." % window)
        debug_note("answering the app with %d of %d question(s) %s"
                   % (len(qs), want, "(job still writing the rest)" if not job.get("done")
                      else "(job finished)"))
        return self._send(200, questions_json(qs[:want] if want else qs,
                                             out.get("model"), want))



if __name__ == "__main__":
    try:
        port = int(os.environ.get("AI_PORT") or 8799)   # ai_gateway_settings.txt can move it
    except Exception:
        port = 8799
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == "--port" and i + 1 < len(argv):
            port = int(argv[i + 1])
    if "--check" in argv:                      # a quiet self test for the .bat helpers
        provider, base, model, key = settings()
        print(f"provider={provider} base={base} model={model} key={'yes' if key else 'no'}")
        root = ollama_root(base)
        exe = ollama_program()
        print(f"  1. program:   {'found -> ' + exe if exe else 'NOT installed (double-click FREE_AI.bat)'}")
        up = reachable(root)
        if not up and exe:
            print(f"  2. service:   not running - trying to start it, wait a few seconds...")
            up = wake_ollama(base, wait=12.0)
            print(f"  2. service:   {'running now' if up else 'still not answering on ' + root}")
        else:
            print(f"  2. service:   {'running on ' + root if up else 'not running on ' + root}")
        have = local_models(root) if up else []
        if up:
            print(f"  3. models:    {', '.join(have) if have else 'NONE downloaded yet - run: ollama pull ' + model}")
            if have and model not in " ".join(have):
                print(f"              (AI_MODEL says {model}, will use {have[0]} instead)")
        # "ready" means the button will work: a live server that has a model. Whether the
        # program is on PATH only decides if the gateway can wake it up by itself.
        ready = up and bool(have)
        if ready:
            print("RESULT: ready")
        elif not up:
            print("RESULT: not ready - the local server is off" +
                  (" (the gateway will start it on the first request)" if exe else
                   " and I could not find ollama.exe to start it - run FREE_AI.bat"))
        else:
            print(f"RESULT: not ready - no model downloaded yet, run:  ollama pull {model}")
        if not exe and ready:
            print("              (note: ollama.exe was not found on PATH, so the gateway cannot")
            print("               start the server by itself - it works as long as Ollama is open)")
        raise SystemExit(0 if (provider != "ollama" or ready) else 1)
    provider, base, model, key = settings()
    print(f"[gateway] http://127.0.0.1:{port}/v1  ->  {provider} @ {base}  model={model}")
    if provider == "ollama" and not installed_ollama(base):
        print("[gateway] Ollama is not running yet - that is fine, the gateway starts it"
              " by itself on the first request. (Or start Ollama / run FREE_AI.bat now.)")
    elif not key:
        print("[gateway] no key file yet - put the provider key in ai_gateway_key.txt")
    ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
