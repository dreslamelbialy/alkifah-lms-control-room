@echo off
rem ============================================================
rem  UPLOAD_NOW.bat - one click: your lessons go to Google Drive AND to the LMS
rem  (Drive first - it takes seconds - then the slow platform upload.)
rem  Nothing is deleted and nothing is uploaded twice.
rem ============================================================
title Alkifah - upload now
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_upload.py" (
  echo [X] The upload helper is not installed yet.
  echo     Run ALKIFAH_FIXES\INSTALL_FIXES.bat once, then try again.
  pause & exit /b 1
)

echo.
echo  [1/2] checking what is waiting...
%PY% "Alkifah_LMS_App\app\alkifah_upload.py" --status
echo.
echo  [2/2] starting: Drive mirror first, then the platform upload.
echo        Leave this window open. Big PowerPoint files take the longest -
echo        each lesson is converted only once, so the next time is much faster.
echo.
%PY% "Alkifah_LMS_App\app\alkifah_upload.py" --all
echo.
echo  Done. The short report is saved in  Alkifah_LMS_App\app\upload_flow_report.txt
echo  Tip: to keep it running by itself (new files every 30 minutes), double-click
echo  UPLOAD_LOOP.bat - it sits in this same ALKIFAH_APP folder.
echo.
pause
