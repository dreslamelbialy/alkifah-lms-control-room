@echo off
rem ============================================================
rem  RESTORE_BACKUP.bat - puts your saved data back (new laptop, or after
rem  a bad update). It shows you the backups you have, lets you pick one,
rem  and FIRST makes a safety copy of the current state.
rem  Close the app window before you do this.
rem ============================================================
title Alkifah - restore my data
setlocal EnableDelayedExpansion
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"
set "BK=Alkifah_LMS_App\app\alkifah_backup.py"

if not exist "%BK%" (
  echo [X] The backup tool is not installed. Run ALKIFAH_FIXES\INSTALL_FIXES.bat first.
  pause & exit /b 1
)

echo.
echo  Backups you have in ALKIFAH_APP\backups:
echo.
set "N=0"
for %%f in ("backups\alkifah_*.zip") do (
  set /a N+=1
  echo    !N!.  %%~nf
)
if "%N%"=="0" (
  echo    none yet - run BACKUP_NOW.bat first.
  pause & exit /b 1
)
echo.
set /p "PICK=  which number do you want to restore?  "
set "I=0"
set "CHOSEN="
for %%f in ("backups\alkifah_*.zip") do (
  set /a I+=1
  if "!I!"=="%PICK%" set "CHOSEN=%%f"
)
if not defined CHOSEN (
  echo [X] That number is not in the list. Close this window and try again.
  pause & exit /b 1
)

echo.
echo  Checking the file first...
%PY% "%BK%" --verify "%CHOSEN%"
echo.
echo  Restoring now (a safety copy of your current state is made automatically).
%PY% "%BK%" --restore "%CHOSEN%" --yes
echo.
echo  Done. Close the app window and start 1-START-APP.bat again.
echo.
pause
