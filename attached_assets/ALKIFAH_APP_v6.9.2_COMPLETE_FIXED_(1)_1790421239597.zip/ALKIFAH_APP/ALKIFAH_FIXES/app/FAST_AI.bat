@echo off
rem ============================================================
rem  FAST_AI.bat  -  choose WHICH free AI writes the questions.
rem
rem    1  =  free INTERNET model (Groq)     - answers in 1 to 3 seconds
rem           needs a free key ONE time (no card):  https://console.groq.com/keys
rem    2  =  model ON THIS LAPTOP (Ollama) - offline, nothing leaves the machine
rem
rem  Nothing here costs money and nothing is deleted. If you choose 1, the model on
rem  this laptop stays installed: whenever the internet is off, or the free hourly
rem  limit is reached, the app answers from the laptop instead - you get the questions
rem  either way.
rem
rem  All the work is done by alkifah_ai_setup.py. Every line is printed AND written to
rem  FAST_AI_log.txt in this folder, so this window can never close on you without
rem  leaving a trace to read.
rem ============================================================
title Alkifah - which AI
set "TOOL=%~dp0Alkifah_LMS_App\app\alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0..\app\alkifah_ai_setup.py"
if not exist "%TOOL%" goto :notool

set "PY=python"
where python >nul 2>&1 || set "PY=py"
%PY% -c "print(1)" >nul 2>&1
if errorlevel 1 goto :nopy

echo.
echo  Two free ways to write the questions:
echo.
echo     1  =  free INTERNET model (Groq)      1 to 3 seconds per answer
echo            free key, no card:  https://console.groq.com/keys
echo     2  =  model ON THIS LAPTOP (Ollama)   offline, slower on older laptops
echo.
echo  What leaves the laptop with 1: the LESSON TEXT only. No student name, no grades,
echo  no passwords - the app never sends those to any AI.
echo.
set "CH="
set /p CH=Type 1 or 2 then Enter  (just Enter keeps things offline): 
if "%CH%"=="1" goto :cloud
if "%CH%"=="2" goto :local
if "%CH%"=="" goto :local
echo.
echo  [!] "%CH%" is not 1 or 2 - nothing was changed.
goto :end

:cloud
set "KEY="
echo.
if exist "%~dp0Alkifah_LMS_App\app\ai_gateway_key.txt" (
  echo  There is already a key file. Press Enter to keep it, or paste a new key below.
)
set /p KEY=Paste the free Groq key (starts with gsk_) - or just press Enter: 
echo.
if "%KEY%"=="" (
  %PY% "%TOOL%" --cloud groq
) else (
  %PY% "%TOOL%" --cloud groq --key "%KEY%"
)
goto :end

:local
echo.
%PY% "%TOOL%" --local
goto :end

:end
echo.
echo  ------------------------------------------------------------
echo  If you saw  RESULT: ready  - open the app with 1-START-APP.bat and press
echo  Generate. If you saw something else, the reason is printed above and in
echo  FAST_AI_log.txt in this folder.
echo  ------------------------------------------------------------
echo.
pause
exit /b 0

:nopy
echo.
echo  [!] No working python was found in this window.
echo      Run INSTALL_FIXES.bat first, or install Python from python.org and
echo      tick "Add python.exe to PATH" while installing.
echo.
pause
exit /b 1

:notool
echo.
echo  [!] alkifah_ai_setup.py was not next to this window.
echo      Unzip ALKIFAH_FIXES over the ALKIFAH_APP folder and double-click
echo      INSTALL_FIXES.bat once - it puts the tool where this button looks.
echo.
pause
exit /b 1
