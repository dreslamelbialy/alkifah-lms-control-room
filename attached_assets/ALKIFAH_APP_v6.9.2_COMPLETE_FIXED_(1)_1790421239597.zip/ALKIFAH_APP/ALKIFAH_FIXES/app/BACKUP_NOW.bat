@echo off
rem ============================================================
rem  BACKUP_NOW.bat - saves everything the Alkifah app knows about you
rem  (accounts, passwords-as-encrypted, upload logs, specs, schedules,
rem   Drive mapping) into ONE zip file inside  ALKIFAH_APP\backups\
rem  ... and puts a copy in your synced Google Drive folder too.
rem  Nothing is deleted. Nothing is sent anywhere.
rem ============================================================
title Alkifah - save my data
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_backup.py" (
  echo [X] The backup tool is not installed yet.
  echo     Run ALKIFAH_FIXES\INSTALL_FIXES.bat once, then try again.
  pause & exit /b 1
)

echo.
echo  What you have right now:
%PY% "Alkifah_LMS_App\app\alkifah_backup.py" --list
echo.
echo  Saving (data + your Drive mapping copy)...
echo.
%PY% "Alkifah_LMS_App\app\alkifah_backup.py" --backup --drive
echo.
echo  Copy it somewhere private too (USB is fine) - the zip contains the key that
echo  decrypts your saved passwords, so do NOT leave it in a shared Drive folder.
echo.
pause
