#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
homework_maker.py — turn a lesson file into a printable homework sheet (+ model answer).

Same lesson source the assessment maker uses, same AI gateway the "ولّد الأسئلة" button
uses — but the output is a clean A4 PDF you print and hand out, instead of an online quiz.

    python homework_maker.py --pdf "First Term\Week 1\Session 01\Mitosis.pdf"
    python homework_maker.py --latest                     # newest PDF already on the LMS
    python homework_maker.py --pdf x.pdf --count 8 --mcq 4 --short 4 --lang en
    python homework_maker.py --pdf x.pdf --dry-run        # no AI call, just extract

Writes (next to the lesson, unless --out is given):
    <Title> - Homework.pdf              student sheet, no answers
    <Title> - Homework (Model Answer).pdf   the key

Upload the student sheet with the tab that already works for you (الكتيبات -> رفع ملف يدوي),
or run exactly what the script prints at the end.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))

try:
    import pymupdf as fitz                      # shipped in requirements.txt
except ImportError:                             # pragma: no cover
    try:
        import fitz
    except ImportError:
        print("[X] pymupdf is missing:  pip install pymupdf")
        raise SystemExit(1)

A4 = (595, 842)
MARGIN = 48


# --------------------------------------------------------------------------- input
def gateway_url() -> tuple[str, str]:
    """baseUrl of the local relay (read from webapp/.z-ai-config, like the app does)."""
    for cand in (APP_DIR.parent.parent / "webapp" / ".z-ai-config",
                 Path.cwd() / ".z-ai-config", Path.home() / ".z-ai-config"):
        try:
            cfg = json.loads(cand.read_text(encoding="utf-8"))
            if cfg.get("baseUrl"):
                return cfg["baseUrl"].rstrip("/"), cfg.get("apiKey", "")
        except Exception:
            continue
    return "http://127.0.0.1:8799/v1", "local-gateway"


def latest_uploaded_pdf(cfg: dict) -> Path | None:
    """Newest lesson that is already on the platform (from uploaded_log.json)."""
    try:
        import pack
        lesson = pack.latest_lesson(pack.load_config()) or {}
        for p in pack.lesson_pdfs(pack.load_config()):
            if lesson.get("title") and _norm(p["name"]) in _norm(lesson["title"]):
                return Path(p["path"])
        if lesson.get("pdf"):
            return Path(lesson["pdf"])
        files = [Path(x["path"]) for x in pack.lesson_pdfs(cfg)]
        return max(files, key=lambda f: f.stat().st_mtime) if files else None
    except Exception:
        return None


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(s).casefold())


def lesson_text(path: Path, max_pages: int = 14) -> str:
    try:
        import pack
        got = pack.extract_lesson_text(str(path), max_pages)
        if got.get("ok"):
            return got["text"]
    except Exception:
        pass
    out = []
    with fitz.open(str(path)) as doc:
        for page in doc[:max_pages]:
            out.append(page.get_text("text"))
    return "\n".join(out).strip()


# --------------------------------------------------------------------------- AI
PROMPT = """You are an experienced {grade} Science teacher writing a homework sheet.
Use ONLY the lesson content below. Write {count} questions for a 20-minute written
homework: {mcq} multiple-choice and {short} short-answer.
Language of everything the student reads: {lang_name}. Difficulty mix: mostly recall,
two questions that need explaining or applying.
Answer lines must be answerable from the lesson. Avoid "all of the above"/"none of the above".
Return STRICT JSON only, no markdown fences, an array of objects shaped like:
{{"type":"mcq","text":"...","options":["a","b","c","d"],"correct":0,"mark":1,"level":"Easy"}}
{{"type":"short","text":"...","answer":"2-3 sentence expected answer","keywords":["k1","k2"],"mark":2,"level":"Medium"}}
correct = index 0-3 of the right option. Max 28 words per question.
Lesson content:
{body}
"""


def ask_ai(text: str, count: int, mcq: int, short: int, lang: str,
           model: str | None = None) -> list[dict]:
    base, key = gateway_url()
    body: dict = {"messages": [
        {"role": "system", "content": "You write school worksheets. JSON only."},
        {"role": "user", "content": PROMPT.format(
            grade="Grade 9", count=count, mcq=mcq, short=short,
            lang_name="Arabic" if lang == "ar" else "English",
            body=text[:13000])},
        {"role": "assistant", "content": "Remember: valid JSON array only."},
    ], "temperature": 0.4}
    if model:
        body["model"] = model
    req = urllib.request.Request(
        base + "/chat/completions", data=json.dumps(body).encode("utf-8"),
        headers={"Content-Type": "application/json",
                 "Authorization": f"Bearer {key}"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=240) as r:
            data = json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        sys.exit(f"[X] the AI service refused ({e.code}): {e.read().decode('utf-8','replace')[:300]}")
    except Exception as e:
        sys.exit(f"[X] cannot reach the AI service at {base} — is the app running? "
                 f"({type(e).__name__}: {e})")
    raw = (data.get("choices") or [{}])[0].get("message", {}).get("content", "") or ""
    return parse_questions(raw, count)


def parse_questions(raw: str, count: int) -> list[dict]:
    raw = raw.strip().replace("```json", "").replace("```", "").strip()
    i, j = raw.find("["), raw.rfind("]")
    if i >= 0 and j > i:
        raw = raw[i:j + 1]
    try:
        items = json.loads(raw)
    except Exception:
        sys.exit("[X] the AI answer was not valid JSON — run it again.")
    if isinstance(items, dict):
        items = items.get("questions", [])
    return normalise(items, count)


def normalise(items, count: int = 0) -> list[dict]:
    """Accept any question shape the app or the AI produces.

    The assessment specs the app saves carry text/options/correct/level/mark and NO
    "type" key; the AI is asked for "type".  Both must print, so the missing bits are
    filled in here instead of crashing halfway through the PDF."""
    if isinstance(items, dict):
        items = items.get("questions", [])
    if not isinstance(items, list):
        items = []
    out = []
    for q in (items if not count else items[:count]):
        if not isinstance(q, dict):
            continue
        text = str(q.get("text") or "").strip()
        if not text:
            continue
        kind = "mcq" if str(q.get("type", "mcq")).lower() == "mcq" else "short"
        opts = [str(o).strip() for o in (q.get("options") or []) if str(o).strip()]
        if kind == "mcq" and len(opts) != 4:
            kind, opts = "short", []
        try:
            corr = int(q.get("correct", 0))
        except Exception:
            corr = 0
        out.append({"type": kind, "text": text, "options": opts,
                    "correct": corr if kind == "mcq" else None,
                    "answer": str(q.get("answer") or "").strip(),
                    "keywords": [str(k) for k in (q.get("keywords") or [])],
                    "mark": q.get("mark") if kind == "short" else 1,
                    "level": str(q.get("level") or "Easy")})
    if not out:
        sys.exit("[X] no usable questions were found (need text, and 4 options for a "
                 "multiple-choice question).")
    return out


# --------------------------------------------------------------------------- PDF
def wrap(text: str, width: float, size: float = 10.5, bold: bool = False) -> list[str]:
    font = "hebo" if bold else "helv"
    lines, cur = [], ""
    for word in str(text).split():
        trial = (cur + " " + word).strip()
        if fitz.get_text_length(trial, fontname=font, fontsize=size) <= width or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines


def sheet(questions: list[dict], title: str, out: Path, key: bool = False) -> None:
    doc = fitz.open()
    page = doc.new_page(width=A4[0], height=A4[1])
    y = MARGIN
    W = A4[0] - 2 * MARGIN

    def space(need: float = 16) -> None:
        nonlocal page, y
        if y + need > A4[1] - MARGIN:
            page = doc.new_page(width=A4[0], height=A4[1])
            y = MARGIN

    # header
    page.draw_rect(fitz.Rect(MARGIN, MARGIN - 14, A4[0] - MARGIN, MARGIN + 30),
                   color=(0.15, 0.35, 0.3), width=1.1)
    page.insert_text((MARGIN + 8, MARGIN + 8), "Alkifah Academy - Science 3 (Grade 9)",
                     fontsize=10, fontname="hebo", color=(0.15, 0.35, 0.3))
    # only the key copy may say ANSWER KEY, and only on the page header
    page.insert_text((MARGIN + 8, MARGIN + 22),
                     (title[:58] + (" - ANSWER KEY" if key else ""))[:80],
                     fontsize=9, fontname="helv", color=(0.3, 0.3, 0.3))
    y = MARGIN + 52
    page.insert_text((MARGIN, y), "Name: ...................................................."
                                  "     Class: ..............     Date: ..............",
                     fontsize=10, fontname="helv")
    total = sum(int(q.get("mark") or 1) for q in questions)
    page.insert_text((A4[0] - MARGIN - 90, y), f"Total: {total} marks",
                     fontsize=10, fontname="hebo")
    y += 10
    page.draw_line((MARGIN, y), (A4[0] - MARGIN, y), color=(0.7, 0.7, 0.7), width=0.6)
    y += 20
    if not key:
        for ln in wrap("Answer every question in your own words. Use a pen. "
                       "Show the units and the steps in calculation questions.", W, 9.5):
            page.insert_text((MARGIN, y), ln, fontsize=9.5, fontname="heit",
                             color=(0.35, 0.35, 0.35))
            y += 12
        y += 10

    for n, q in enumerate(questions, 1):
        space(46)
        head = f"{n}. ({q.get('mark') or 1} m)"
        page.insert_text((MARGIN, y), head, fontsize=10.5, fontname="hebo")
        lines = wrap(q.get("text") or "", W - 62, 10.5)
        page.insert_text((MARGIN + 46, y), lines[0] if lines else "", fontsize=10.5)
        for extra in lines[1:]:
            y += 13
            space(14)
            page.insert_text((MARGIN + 46, y), extra, fontsize=10.5)
        y += 15
        if str(q.get("type", "mcq")) == "mcq":
            letters = "abcd"
            for oi, opt in enumerate(q.get("options") or []):
                space(13)
                marked = key and oi == int(q.get("correct") or 0)
                tag = "   [CORRECT]" if marked else ""
                page.insert_text((MARGIN + 58, y),
                                 f"({letters[oi]}) " + (opt[:80] + tag)[:112],
                                 fontsize=10, fontname="hebo" if marked else "helv",
                                 color=(0.05, 0.45, 0.12) if marked else (0, 0, 0))
                y += 13
            y += 8
        else:
            rows = 3 if not key else 1
            for _ in range(rows):
                space(20)
                page.draw_line((MARGIN + 58, y + 4), (A4[0] - MARGIN, y + 4),
                               color=(0.6, 0.6, 0.6), width=0.5)
                y += 20
            if key:
                for ln in wrap("Expected answer: " + (q.get("answer") or "—"), W - 58, 9.5):
                    space(12)
                    page.insert_text((MARGIN + 58, y), ln, fontsize=9.5,
                                     fontname="helv", color=(0.05, 0.4, 0.1))
                    y += 11
                if q.get("keywords"):
                    space(12)
                    page.insert_text((MARGIN + 58, y),
                                     "Accept any of: " + ", ".join(q["keywords"])[:150],
                                     fontsize=8.5, fontname="helv", color=(0.4, 0.4, 0.4))
                    y += 11
            y += 12
    doc.save(str(out), garbage=3, deflate=True)
    doc.close()


# --------------------------------------------------------------------------- main
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf", help="lesson file (PDF; .pptx/.docx need the app's converter)")
    ap.add_argument("--latest", action="store_true",
                    help="use the newest lesson that is already uploaded to the LMS")
    ap.add_argument("--count", type=int, default=8)
    ap.add_argument("--mcq", type=int, default=4)
    ap.add_argument("--short", type=int, default=4)
    ap.add_argument("--lang", default="en", choices=["en", "ar"])
    ap.add_argument("--model", default=None, help="only needed for AI_PROVIDER=custom")
    ap.add_argument("--title", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--dry-run", action="store_true", help="extract text only, no AI call")
    ap.add_argument("--from-json", default=None, help="questions JSON file (skip the AI)")
    ap.add_argument("--no-lesson", action="store_true",
                    help="with --from-json: build the sheet without reading any lesson file "
                         "(used by the app when the homework questions are already written)")
    a = ap.parse_args()

    src = Path(a.pdf) if a.pdf else None
    if src is None and a.latest:
        src = latest_uploaded_pdf({})
    if a.from_json and a.no_lesson:
        # the questions already exist (they came from the app) - no lesson file needed
        text = ""
        if src is None:
            src = Path("lesson:(not needed)")
    else:
        if src is None or not src.exists():
            ap.error("give --pdf <lesson.pdf> (or --latest when a lesson is already on the LMS)")
        if src.suffix.lower() != ".pdf":
            print(f"[!] {src.suffix} will be read as-is; if that fails, save the lesson as PDF first.")
        text = lesson_text(src)
        if len(text) < 120:
            sys.exit(f"[X] no readable text in '{src.name}' (scanned slides?). "
                     "Re-export the lesson to PDF from PowerPoint.")
        print(f"[OK] lesson text: {len(text)} chars from {src.name}")
        if a.dry_run:
            print(text[:1200])
            return 0

    qs = (normalise(json.loads(Path(a.from_json).read_text(encoding="utf-8"))) if a.from_json
          else ask_ai(text, a.count, a.mcq, a.short, a.lang, a.model))
    if a.lang == "ar":
        print("[!] Arabic needs a shaping font (not the built-in one). The questions are "
              "written in Arabic, but the PDF may show disconnected letters — for Arabic "
              "sheets print from Word instead, or pass --lang en.")

    title = a.title or re.sub(r"(?i)\.pdf$|\.pptx$", "", src.stem).replace("_", " ").strip()
    title = title or "Homework"
    # keep generated sheets OUT of the lesson folders, so the lesson picker can
    # never mistake a homework sheet for a lesson
    if a.out:
        out_dir = Path(a.out)
    else:
        guess = src.parents[2] / "Homework" if len(src.parents) > 2 else None
        out_dir = guess if (guess and guess.parent.exists()) else src.parent / "Homework"
        if not out_dir.parent.exists():
            out_dir = APP_DIR.parent / "First Term" / "Homework"
    out_dir.mkdir(parents=True, exist_ok=True)
    student = out_dir / f"{title} - Homework.pdf"
    answers = out_dir / f"{title} - Homework (Model Answer).pdf"
    sheet(qs, title, student, key=False)
    sheet(qs, title, answers, key=True)
    marks = sum(int(q.get("mark") or 1) for q in qs)
    print(f"[OK] {len(qs)} questions, {marks} marks")
    print(f"[OK] student sheet : {student}")
    print(f"[OK] model answer   : {answers}")
    pack_dir = APP_DIR.parent
    print("\nUpload them to the LMS with the booklet uploader (one line):\n")
    print(f'  python "{pack_dir / "scripts" / "upload_booklet.py"}" file '
          f'"{student}" "{title} Homework"')
    print(f'  python "{pack_dir / "scripts" / "upload_booklet.py"}" file '
          f'"{answers}" "{title} Homework (Model Answer)"')
    print("\n(or in the app: الكتيبات -> رفع ملف يدوي)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
