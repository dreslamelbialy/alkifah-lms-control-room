#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alkifah_backup.py — save / restore everything the Alkifah app knows about you.

WHERE YOUR DATA LIVES (nothing is stored on any server; it is all files on this laptop,
inside ALKIFAH_APP\\Alkifah_LMS_App\\):

    app\\profiles.json          the teacher accounts (name, email, folders, course, classes)
    app\\secrets.json           your LMS password + the bot/Drive tokens, encrypted
    app\\.appkey                the key that decrypts secrets.json  -> must travel together
    app\\config.json            folders, course, classes, publish minutes, active profile
    app\\schedules.json         the auto-run times (7:00 upload, 8:00 assessment, ...)
    app\\bot.json               Telegram bot settings
    app\\drive_routes.json      which laptop folder is mapped to which Google Drive folder
    app\\drive_client.json      your Google Drive app credentials
    app\\drive_token.json       your Google Drive access token (encrypted)
    app\\runs.json              history of what the app ran
    app\\uploads_feed.json      the dashboard's "latest uploads" feed
    app\\upload_settings.txt / drive_mirror_log.json / upload_flow_report.txt  (ALKIFAH_FIXES)
    scripts\\uploaded_log.json  which lesson is already on the platform (no duplicates!)
    scripts\\booklet_log.json   which booklet / model answer is uploaded
    scripts\\assessment_log.json  every exam created, with its links
    scripts\\upload_report.txt  the last upload report
    specs\\*.json               your assessment blueprints
    First Term\\...             your lesson files (only with --with-lessons)

WHAT THIS SCRIPT DOES: it copies those files into ONE zip inside
ALKIFAH_APP\\backups\\, with a checksum per file, and --restore puts them back exactly.
It never deletes anything, never touches the LMS, and never uploads by itself
(--drive only drops a copy of the zip into a folder YOU chose).

    python alkifah_backup.py --list                 what exists right now
    python alkifah_backup.py --backup               save it (default action)
    python alkifah_backup.py --backup --with-lessons --drive
    python alkifah_backup.py --verify <zip>         is the backup still intact?
    python alkifah_backup.py --restore <zip> --yes  put it back (new laptop / after a fix)
    python alkifah_backup.py --latest               path of the newest backup
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import socket
import sys
import zipfile
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent            # .../ALKIFAH_APP/Alkifah_LMS_App/app


def _find_root() -> Path:
    """ALKIFAH_APP = the folder that contains Alkifah_LMS_App. Walking up makes the
    tool work even if it is run from a copy somewhere else."""
    for cand in APP_DIR.parents:
        if (cand / "Alkifah_LMS_App").is_dir():
            return cand
    return APP_DIR.parents[1] if len(APP_DIR.parents) > 1 else APP_DIR


ROOT = _find_root()
BACKUP_DIR = ROOT / "backups"

# (path relative to ALKIFAH_APP, what it is)
DATA_FILES = [
    ("Alkifah_LMS_App/app/profiles.json", "حسابات المعلمين (الإيميل، الفولدرات، المادة، الفصول)"),
    ("Alkifah_LMS_App/app/secrets.json", "كلمة سر المنصة + توكن البوت والدرايف (مشفّرة)"),
    ("Alkifah_LMS_App/app/.appkey", "مفتاح فك التشفير — لازم يتحفظ مع secrets.json"),
    ("Alkifah_LMS_App/app/config.json", "إعدادات التطبيق (المسارات، تاريخ النشر، الحساب النشِط)"),
    ("Alkifah_LMS_App/app/schedules.json", "مواعيد الشغل التلقائي"),
    ("Alkifah_LMS_App/app/bot.json", "إعدادات بوت تيليجرام"),
    ("Alkifah_LMS_App/app/drive_routes.json", "خريطة فولدرات جوجل درايف"),
    ("Alkifah_LMS_App/app/drive_client.json", "بيانات تطبيق جوجل درايف"),
    ("Alkifah_LMS_App/app/drive_token.json", "توكن الدخول على درايف (مشفّر)"),
    ("Alkifah_LMS_App/app/runs.json", "سجل اللي التطبيق نفّذه"),
    ("Alkifah_LMS_App/app/uploads_feed.json", "فييد «آخر المرفوعات» في الداشبورد"),
    ("Alkifah_LMS_App/app/upload_settings.txt", "إعدادات الرفع السلس (ALKIFAH_FIXES)"),
    ("Alkifah_LMS_App/app/drive_mirror_log.json", "سجل النسخ اللي راح للدرايف (منع التكرار)"),
    ("Alkifah_LMS_App/app/upload_flow_report.txt", "آخر تقرير رفع"),
    ("Alkifah_LMS_App/app/ai_gateway_settings.txt", "إعدادات بوابة الذكاء الاصطناعي"),
    ("Alkifah_LMS_App/app/ai_gateway_key.txt", "مفتاح الذكاء الاصطناعي (لو حطيتي واحد)"),
    ("Alkifah_LMS_App/scripts/uploaded_log.json", "الدروس اللي اترفعت على المنصة — دي أهم حاجة عشان مفيش تكرار"),
    ("Alkifah_LMS_App/scripts/booklet_log.json", "الكتيبات ونماذج الإجابة اللي اترفعت"),
    ("Alkifah_LMS_App/scripts/assessment_log.json", "كل امتحان اتعمل + لينكه"),
    ("Alkifah_LMS_App/scripts/upload_report.txt", "آخر تقرير رفع للمواد"),
]
DATA_GLOBS = [("Alkifah_LMS_App/specs", "*.json", "ملفات التقييمات (specs)")]
LESSONS_DIR = "Alkifah_LMS_App/First Term"
SKIP_NAMES = re.compile(r"(^|/)(~\$|\.DS_Store|__pycache__|\.bak-)", re.I)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def app_version() -> str:
    for cand in (ROOT / "VERSION", ROOT / "Alkifah_LMS_App" / "VERSION"):
        try:
            return cand.read_text(encoding="utf-8", errors="replace").strip()
        except Exception:
            continue
    return "unknown"


def collect(with_lessons: bool) -> list[tuple[Path, str]]:
    """Existing files, as (absolute path, path inside the zip)."""
    found: list[tuple[Path, str]] = []
    seen: set[str] = set()
    for rel, _desc in DATA_FILES:
        p = ROOT / rel
        if p.is_file() and rel not in seen:
            seen.add(rel)
            found.append((p, rel.replace("\\", "/")))
    for rel_dir, pattern, _desc in DATA_GLOBS:
        d = ROOT / rel_dir
        if d.is_dir():
            for p in sorted(d.rglob(pattern)):
                if p.is_file() and not SKIP_NAMES.search(p.name):
                    rel = p.relative_to(ROOT).as_posix()
                    if rel not in seen:
                        seen.add(rel)
                        found.append((p, rel))
    if with_lessons:
        d = ROOT / LESSONS_DIR
        if d.is_dir():
            for p in sorted(d.rglob("*")):
                if not p.is_file() or SKIP_NAMES.search(p.name):
                    continue
                if p.suffix.lower() not in (".pdf", ".pptx", ".ppt", ".docx", ".txt", ".json"):
                    continue
                rel = p.relative_to(ROOT).as_posix()
                if rel not in seen:
                    seen.add(rel)
                    found.append((p, rel))
    return found


def human(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n/1:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} GB"


def do_list(quiet: bool = False) -> int:
    rows, missing = [], []
    for rel, desc in DATA_FILES:
        p = ROOT / rel
        (rows if p.is_file() else missing).append((rel, desc, p))
    print(f"ALKIFAH_APP = {ROOT}")
    print(f"نسخة التطبيق: {app_version()}   |   جهاز: {socket.gethostname()}")
    print(f"\nموجود ({len(rows)}):")
    total = 0
    for rel, desc, p in rows:
        size = p.stat().st_size
        total += size
        print(f"   {human(size):>9}  {rel:52s}  {desc}")
    if missing:
        print(f"\nلسه متعملش ({len(missing)} — عادي، دي بتتنقض أول ما تستخدميها):")
        for rel, desc, _p in missing:
            print(f"   {'-':>9}  {rel:52s}  {desc}")
    for rel_dir, pattern, desc in DATA_GLOBS:
        d = ROOT / rel_dir
        files = [f for f in sorted(d.rglob(pattern)) if f.is_file()] if d.is_dir() else []
        total += sum(f.stat().st_size for f in files)
        print(f"\n{desc}: {len(files)} ملف في {rel_dir}")
    ld = ROOT / LESSONS_DIR
    if ld.is_dir():
        nf = sum(1 for f in ld.rglob("*") if f.is_file())
        print(f"ملفات الدروس في {LESSONS_DIR}: {nf} ملف (بتدخل بس مع --with-lessons)")
    if not quiet:
        print(f"\nالحجم التقريبي لنسخة البيانات لوحدها: {human(total)}")
    return 0


def declared_drive_paths() -> list[str]:
    """Folder paths the app has mapped to Google Drive, even if they do not exist
    right now (old laptop, external disk unplugged)."""
    out: list[str] = []
    for cand in (APP_DIR / "drive_routes.json",):
        try:
            data = json.loads(cand.read_text(encoding="utf-8"))
        except Exception:
            continue

        def walk(node) -> None:
            if isinstance(node, dict):
                for k, v in node.items():
                    if isinstance(v, str) and re.search(r"(?i)local|path|folder|dir", str(k)):
                        if v.strip():
                            out.append(v.strip())
                    else:
                        walk(v)
            elif isinstance(node, list):
                for v in node:
                    walk(v)

        walk(data)
    return out


def drive_targets() -> tuple[list[Path], list[str]]:
    """(usable folders, declared-but-missing). Reuses the upload tool's own reader so
    the mapping is read exactly the way the app reads it."""
    ok: list[Path] = []
    try:
        sys.path.insert(0, str(APP_DIR))
        import alkifah_upload as up
        cfg = {"term_folder": ""}
        try:
            import pack
            cfg = pack.load_config()
        except Exception:
            pass
        ok = up.drive_folders(cfg, up.load_settings())
    except Exception:
        ok = []
    missing = [d for d in declared_drive_paths() if d not in {str(p) for p in ok}]
    return ok, missing


def do_backup(with_lessons: bool, to_drive: bool, quiet: bool, keep: int,
              drive_to: str | None = None) -> int:
    files = collect(with_lessons)
    if not files:
        print("[X] مفيش أي ملف بيانات ياتحفظ — التطبيق لسه ما اشتغلش أصلاً؟")
        print(f"    اتأكد إن المسار ده مظبوط: {ROOT}")
        return 1
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    tag = "full" if with_lessons else "data"
    out = BACKUP_DIR / f"alkifah_{tag}_backup_{stamp}.zip"
    manifest = {"created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "app_root": str(ROOT), "app_version": app_version(),
                "host": socket.gethostname(), "with_lessons": with_lessons,
                "files": []}
    total = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for p, rel in files:
            z.write(p, rel)
            size = p.stat().st_size
            total += size
            manifest["files"].append({"path": rel, "bytes": size, "sha256": sha256(p)})
        z.writestr("MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=1))
    print(f"[OK] اتحفظت {len(files)} ملفات ({human(total)}) في:")
    print(f"     {out}")
    if keep:
        prune(keep)
    if to_drive:
        if drive_to:
            targets, _ = [Path(drive_to)], []
        else:
            targets, missing = drive_targets()
        if not targets:
            if missing:
                print("[!] الفولدر المسجّل للدرايف مش موجود على الجهاز دلوقتي:")
                for m in missing[:3]:
                    print(f"      {m}")
                print("      النسخة اتحفظت في backups بس. لو الفولدر لو على ديسك خارجي وصلّيه وأعدي.")
            else:
                print("[!] معرفش فولدر الدرايف المتزامن — حدديه مرة واحدة:")
                print('     python alkifah_upload.py --drive-folder "D:\\Google Drive\\Alkifah"')
        for t in targets:
            try:
                t.mkdir(parents=True, exist_ok=True)
                dst = t / out.name
                shutil.copy2(out, dst)
                print(f"[OK] نسخة على الدرايف: {dst}")
            except Exception as e:
                print(f"[!] النسخ لـ {t} فشل: {e}")
    if not quiet:
        print("     ارجعّيها في أي وقت بـ:  python alkifah_backup.py --restore \"<الملف>\" --yes")
        warn_if_public(out)
    return 0


def warn_if_public(out: Path) -> None:
    """A backup holds .appkey + encrypted secrets + Drive tokens. Warn if it sits in a
    shared folder (Google Drive 'shared with anyone', Dropbox public, Desktop sync...)."""
    low = str(out).lower()
    risky = [k for k in ("shared", "public", "inbox", "downloads") if k in low]
    if "drive" in low and not risky:
        print("     [ملاحظة] النسخة دي فيها مفتاح التشفير مع الملفات المشفّرة — لو فولدر")
        print("     الدرايف ده مشار مع حد تاني، انقلي النسخة لبرّه الفولدر المشارك أو")
        print("     ل USB. الفولدر الشخصي لحالك يكفي.")
    elif risky:
        print(f"     [!] انتي حافظة النسخة في مكان مشارك ({', '.join(risky)}) —")
        print("     انقليها لمكان خاص، لأنها بتفتح حسابك لو وقعِت في إيد غلط.")


def prune(keep: int) -> None:
    try:
        olds = sorted(BACKUP_DIR.glob("alkifah_*_backup_*.zip"))
        for p in olds[:-keep] if keep else []:
            p.unlink()
            print(f"[OK] مسحت نسخة قديمة قديمة عشان ميتقلّش الفولدر: {p.name}")
    except Exception:
        pass


def do_verify(zip_path: str) -> int:
    z = Path(zip_path)
    if not z.is_file():
        print(f"[X] ملقتش الملف: {z}")
        return 1
    with zipfile.ZipFile(z) as zf:
        try:
            man = json.loads(zf.read("MANIFEST.json").decode("utf-8"))
        except Exception:
            print("[!] مفيش MANIFEST.json جوه النسخة — هاتأكد من الملفات اللي موجودة بس")
            man = {"files": [{"path": n} for n in zf.namelist() if n != "MANIFEST.json"]}
        bad = 0
        for row in man["files"]:
            rel = row["path"]
            try:
                data = zf.read(rel)
            except KeyError:
                print(f"   [X] ناقص من النسخة: {rel}")
                bad += 1
                continue
            got = hashlib.sha256(data).hexdigest()
            want = row.get("sha256")
            if want and got != want:
                print(f"   [X] بايظ (اتغيّر): {rel}")
                bad += 1
        print(f"{'[OK] النسخة سليمة' if not bad else '[X] في مشاكل'} — "
              f"{len(man['files'])} ملف، {bad} بايظ  |  تاريخ النسخة: {man.get('created','?')}"
              f"  |  نسخة التطبيق: {man.get('app_version','?')}")
    return 1 if bad else 0


def safe_extract_path(zf_name: str, dest: Path) -> Path | None:
    """Refuse anything that tries to escape ALKIFAH_APP (zip-slip guard)."""
    target = (dest / zf_name).resolve()
    try:
        target.relative_to(dest.resolve())
    except ValueError:
        return None
    return target


def do_restore(zip_path: str, yes: bool) -> int:
    z = Path(zip_path)
    if not z.is_file():
        newest = latest()
        if newest:
            print(f"[i] أقصدِ على الأرجح: {newest}")
            z = Path(newest)
        else:
            print(f"[X] ملقتش نسخة في {BACKUP_DIR}")
            return 1
    if not yes:
        print("[X] الاسترجاع بيكتب فوق ملفاتك الحالية. لو متأكدي اعملي:")
        print(f'     python alkifah_backup.py --restore "{z}" --yes')
        print("     (الأفضل تقفلي التطبيق الأول، وبعدين تعيدي فتحيه)")
        return 2
    pre = BACKUP_DIR / f"before_restore_{datetime.now():%Y-%m-%d_%H%M%S}.zip"
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    files = collect(True)
    if files:
        with zipfile.ZipFile(pre, "w", zipfile.ZIP_DEFLATED) as zo:
            for p, rel in files:
                zo.write(p, rel)
        print(f"[OK] عملت نسخة احتياطية لوضعك الحالي الأول: {pre.name}")
    done, skipped = 0, []
    with zipfile.ZipFile(z) as zf:
        for name in zf.namelist():
            if name == "MANIFEST.json" or name.endswith("/"):
                continue
            target = safe_extract_path(name, ROOT)
            if target is None:
                skipped.append(name)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(name) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            done += 1
            print(f"   رجّعت: {name}")
    print(f"\n[OK] {done} ملف رجعوا مكانه" + (f" — تم تجاهل {skipped}" if skipped else ""))
    print("     قفّلي التطبيق وافتحيه تاني عشان يقرأ الملفات الجديدة.")
    return 0


def latest() -> str | None:
    if not BACKUP_DIR.is_dir():
        return None
    c = sorted(BACKUP_DIR.glob("alkifah_*backup*.zip"))
    return str(c[-1]) if c else None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true", help="اعرض ملفاتك ومكانها")
    ap.add_argument("--backup", action="store_true", help="احفظ كل حاجة في zip")
    ap.add_argument("--with-lessons", action="store_true", help="حفظ ملفات الدروس كمان (أكبر)")
    ap.add_argument("--drive", action="store_true", help="ارمي نسخة في فولدر الدرايف المتزامن")
    ap.add_argument("--drive-to", metavar="DIR", help="مكان محدد للنسخة (بدل الفولدر المسجّل)")
    ap.add_argument("--verify", metavar="ZIP", help="اتأكدي إن النسخة السلامة")
    ap.add_argument("--restore", metavar="ZIP", help="ارجّعي من نسخة (لاب جديد/بعد حدف)")
    ap.add_argument("--yes", action="store_true", help="موافقة على الكتابة فوق الملفات")
    ap.add_argument("--latest", action="store_true", help="أحدث نسخة موجودة")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--keep", type=int, default=12, help="عدد النسخ اللي تتساب (12)")
    a = ap.parse_args()

    if not (ROOT / "Alkifah_LMS_App").is_dir():
        print(f"[X] مش لاقي فولدر Alkifah_LMS_App جنب {ROOT.name} —")
        print("    لازم الملف ده يفضل جوه Alkifah_LMS_App\\app زي ما هو.")
        return 2

    if a.latest:
        print(latest() or f"(مفيش نسخ في {BACKUP_DIR})")
        return 0
    if a.verify:
        return do_verify(a.verify)
    if a.restore:
        return do_restore(a.restore, a.yes)
    if a.list:
        return do_list(a.quiet)
    return do_backup(a.with_lessons, a.drive or bool(a.drive_to), a.quiet,
                     max(0, a.keep), a.drive_to)


if __name__ == "__main__":
    sys.exit(main())
