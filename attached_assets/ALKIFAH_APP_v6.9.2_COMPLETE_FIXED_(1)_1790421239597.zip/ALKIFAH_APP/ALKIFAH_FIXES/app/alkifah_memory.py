#!/usr/bin/env python3
# -*- coding: utf-8 -*-
r"""
alkifah_memory.py — يصلّح ذاكرة «ارفعنا إيه» بعد ما تمسحي حاجة من على المنصة.

ليه الملف ده أصلًا: التطبيق بيعرف إن الدرس «مرفوع بالفعل» من ملف واحد صغير:
scripts/uploaded_log.json.  المشكلة إن الملف ده ميعرفش إنك مسحتي المادة من الموقع —
فبيرفض يرفعها تاني، ولما تجبريه يعمل نسخة تانية باسم مختلف.  الأداة دي بتعمل العكس
بالظبط: بتفتح صفحة Materials، بتقرأ العناوين اللي موجودة فعلًا، وأي حاجة في المذكره
ملقاش هناك بتتشال من المذكره — فالرفع العادي بيرجعها بنفس الاسم بالضبط، ومن غير «(2)».

فين الصفحة؟  في أكاديميات كتير صفحة Materials اللي من القائمة العلوية بيبان فيها فاضي
(مفلترة على كورس/ترم معيّن)، والمادة نفسها بتلاقيها داخل Course List -> Tab=Materials.
عشان كده الأداة دي بتقرأ الاتنين: لو الصفحة الأولى طلعت فاضية، بتلف على لينكات المواد
اللي في كل كورس وبتجمع الأسماء من كل واحدة.

الأمان (ده الأهم):
  • أي صفحة فشل قراءتها = مفيش تغيير خالص في المذكره (مش بنحزر).
  • لو مفيش ولا عنوان اتقرا = مفيش تغيير خالص.
  • عنوان له أي شبه على المنصة (مسافات/شرطات/اسم الملف/امتداد pdf) = بيتساب.
  • نسخة من المذكره القديمة بتتحفظ قبل أي تغيير: uploaded_log.json.before-memory-fix-<وقت>
  • كل اللي اتعمل بيتكتب في scripts\LMS_MEMORY_log.txt — ابعتي الملف ده لو حاجة ما رجعتش.

    python alkifah_memory.py --show      بيطبع اللي على المنصة دلوقتي (للتأكيد بس)
    python alkifah_memory.py            يعمل التصحيح ويطبع اللي اتشال

ساعات الشغل بتاعة التطبيق بتنادي repair() من هنا مباشرة، فسلوك السطر التاني ده هو
نفس اللي بيحصل لوحده كل ما تدوسي زرار الرفع في التطبيق.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from pathlib import Path
from datetime import datetime

TIMEOUT_MS = int(os.environ.get("LMS_MEMORY_TIMEOUT_MS") or 60000)
MAX_PAGES = int(os.environ.get("LMS_MEMORY_PAGES") or 40)
MAX_COURSES = int(os.environ.get("LMS_MEMORY_COURSES") or 14)

# the Materials table on the LMS: column 1 is the title (same reading the uploader uses)
ROWS_JS = """() => {
    const t = document.querySelector('table');
    if (!t) return null;
    return Array.from(t.querySelectorAll('tbody tr')).map(r => {
        const c = r.querySelectorAll('td');
        return c.length > 1 ? c[1].innerText.replace(/\\s+/g, ' ').trim() : '';
    }).filter(Boolean);
}"""

NEXT_JS = """() => {
    const next = Array.from(document.querySelectorAll('a'))
        .find(a => a.innerText.trim().toLowerCase() === 'next');
    if (next && !next.closest('li').classList.contains('disabled')) {
        next.click();
        return true;
    }
    const active = document.querySelector('.pagination .active');
    if (active) {
        const el = active.nextElementSibling;
        if (el) { (el.querySelector('a') || el).click(); return true; }
    }
    return false;
}"""

_log_lines: list[str] = []


def log(msg: str, log_path: Path | None = None) -> None:
    """Nothing in this tool may fail silently - every read is written down."""
    line = "%s  %s" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
    print("      " + msg)
    _log_lines.append(line)
    if log_path is None:
        return
    try:
        f = Path(log_path).parent / "LMS_MEMORY_log.txt"
        old = f.read_text(encoding="utf-8", errors="replace").splitlines()[-160:] if f.exists() else []
        f.write_text("\n".join((old + [line])[-180:]), encoding="utf-8")
    except Exception:
        pass


def log_line(msg, log_path=None):
    log(msg, log_path)


def norm(t) -> str:
    """'Week 5 - Session 02 - Classifying Living Things P2' and
    'Week5_Session02_Classifying_Living_Things_P2.pdf' have to count as the SAME thing."""
    s = re.sub(r"(?i)\.(pdf|pptx?|docx?)$", "", str(t))
    s = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "", s.lower())
    return s


def _abs(url: str, base_url: str) -> str:
    u = str(url or "").strip()
    if not u or u.startswith("javascript:") or u.startswith("mailto:"):
        return ""
    if u.startswith("http://") or u.startswith("https://"):
        return u
    if u.startswith("/"):
        return base_url.rstrip("/") + u
    return base_url.rstrip("/") + "/" + u


def start_urls(base_url: str) -> list:
    """Where to look first. LMS_MATERIALS_URLS (in the upload bat or the environment)
    overrides it - semicolon separated - so a different academy can point this
    somewhere else without touching code."""
    ov = str(os.environ.get("LMS_MATERIALS_URLS") or "").strip()
    if ov:
        return [_abs(x, base_url) for x in ov.split(";") if x.strip()][:MAX_COURSES]
    return [base_url.rstrip("/") + "/CourseManagement/Materials"]


def course_links(page, base_url: str) -> list:
    """Every 'Materials' link on the page - that is how the course tabs are reached
    when the top-level Materials page is filtered and shows nothing."""
    found = []
    try:
        for a in page.query_selector_all("a[href]") or []:
            try:
                href = a.get_attribute("href") or ""
            except Exception:
                continue
            u = _abs(href, base_url)
            if u and "material" in u.lower() and u not in found:
                found.append(u)
    except Exception:
        pass
    return found[:MAX_COURSES]


def read_url(page, url: str):
    """One Materials list, all its pages. Returns (titles, ok) - ok is False when the
    page could not be read at all, which must stop any pruning."""
    titles = set()
    ok = True
    try:
        page.goto(url, wait_until="domcontentloaded", timeout=TIMEOUT_MS)
    except Exception:
        return titles, False
    for _ in range(max(1, MAX_PAGES)):
        try:
            page.wait_for_selector("table", timeout=12000)
            got = page.evaluate(ROWS_JS)
        except Exception:
            return titles, False
        if got is None:                      # no table on this page at all
            return titles, False
        titles.update(str(x).strip() for x in got if str(x).strip())
        try:
            more = page.evaluate(NEXT_JS)
        except Exception:
            more = False
        if not more:
            break
        try:
            page.wait_for_load_state("domcontentloaded")
            page.wait_for_timeout(1200)
        except Exception:
            break
    return titles, ok


def live_titles(page, base_url: str, note=None):
    """Everything the platform really has, from the top-level page AND from each course's
    Materials tab if that page came back empty. Returns (titles, ok)."""
    def say(msg):
        if note:
            note(msg)

    urls = start_urls(base_url)
    titles = set()
    ok = True
    for url in urls:
        got, good = read_url(page, url)
        say("read %d title(s) from %s%s" % (len(got), url, "" if good else "  (could not be read)"))
        titles.update(got)
        ok = ok and good
    if not titles and ok:
        # the top-level page was empty - and the course tabs are where the material lives
        links = []
        try:
            page.goto(urls[0], wait_until="domcontentloaded", timeout=TIMEOUT_MS)
            links = course_links(page, base_url)
        except Exception:
            links = []
        links = [u for u in links if u not in urls]
        if links:
            say("the top page was empty - trying %d course Materials tab(s)" % len(links))
            for url in links:
                got, good = read_url(page, url)
                say("read %d title(s) from %s%s" % (len(got), url, "" if good else "  (could not be read)"))
                titles.update(got)
                ok = ok and good
        else:
            say("no Materials links found on the page either")
    return (titles if ok and titles else set()), ok


def decide(log: dict, live) -> list:
    """Which remembered titles are NOT on the platform anymore.

    Matching is forgiving on purpose: the log keeps the display title
    ('Week 5 - Session 02 - Classifying Living Things P2') while the platform may show
    the file name ('Week5_Session02_Classifying...pdf'). Anything that looks present is
    kept, because a wrong drop would upload a duplicate."""
    if not live:
        return []
    have = [norm(x) for x in live if norm(x)]
    out = []
    for t in list(log or {}):
        k = norm(t)
        if not k:
            continue
        if not any(k == h or k in h or h in k for h in have):
            out.append(t)
    return out


def _login(page, base_url: str, username: str, password: str, login_fn=None) -> None:
    """The app's own login when it is handed to us (same page, same boxes, same LMS).
    Only a standalone run falls back to filling the boxes here."""
    if login_fn is not None:
        login_fn(page)
        return
    sel_user = ["input[name='Input.Email']", "#Input_Email", "input[name='Email']",
                "#Email", "input[type='email']"]
    sel_pass = ["input[name='Input.Password']", "#passwordInput", "#Input_Password",
                "#Password", "input[type='password']"]
    page.goto(base_url.rstrip("/") + "/Identity/Account/LogIn",
              wait_until="domcontentloaded", timeout=TIMEOUT_MS)
    for s in sel_user:
        try:
            page.fill(s, username)
            break
        except Exception:
            continue
    else:
        raise RuntimeError("login box not found")
    for s in sel_pass:
        try:
            page.fill(s, password)
            break
        except Exception:
            continue
    clicked = False
    for sel in ("button[type='submit']", "button:has-text('Log in')", "input[type='submit']"):
        try:
            page.click(sel, timeout=5000)
            clicked = True
            break
        except Exception:
            continue
    if not clicked:
        try:
            page.press("input[type='password']", "Enter")
        except Exception:
            pass
    try:
        page.wait_for_url(lambda u: "login" not in u.lower(), timeout=20000)
    except Exception:
        pass
    if "login" in (page.url or "").lower():
        raise RuntimeError("the platform did not accept the login")


def repair(log: dict, log_path: Path, base_url: str, username: str, password: str,
           login_fn=None):
    """Returns (dropped_titles, note). Mutates `log`; the caller saves it."""
    if not isinstance(log, dict) or not log:
        return [], "nothing was remembered, so there was nothing to check"
    os.environ.setdefault("LMS_USERNAME", username or "")
    os.environ.setdefault("LMS_PASSWORD", password or "")
    try:
        from playwright.sync_api import sync_playwright
    except Exception as e:
        return [], "playwright not available (%s) - the log was left as it is." % type(e).__name__
    live = None
    ok = False
    try:
        with sync_playwright() as pw:
            br = pw.chromium.launch(headless=True)
            try:
                page = br.new_context(locale="en-US").new_page()
                _login(page, base_url, username, password, login_fn)
                live, ok = live_titles(page, base_url,
                                      note=lambda m: log_line(m, log_path))
            finally:
                br.close()
    except (Exception, SystemExit) as e:
        # SystemExit on purpose: the app's login() ends the process when it cannot get in,
        # and a failed memory check must never be the reason an upload did not run.
        return [], ("the platform could not be reached (%s) - the log was left as it is."
                    % (getattr(e, "code", None) or type(e).__name__))
    if not ok or not live:
        return [], ("the Materials list could not be read in full - the log was left exactly "
                    "as it is (that is the safe way: a wrong guess would make a duplicate).")
    dropped = decide(log, live)
    if not dropped:
        return [], "memory check: all %d remembered item(s) are still on the platform." % len(log)
    try:
        if log_path and Path(log_path).exists():
            Path(log_path).with_name(
                Path(log_path).name + ".before-memory-fix-"
                + datetime.now().strftime("%Y%m%d-%H%M%S")).write_bytes(
                Path(log_path).read_bytes())
    except Exception:
        pass
    return dropped, "read %d title(s) from the platform." % len(live)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--show", action="store_true", help="print what is on the platform")
    a = ap.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    try:
        import pack
        cfg = pack.load_config()
        sd = pack.scripts_dir(cfg)
    except Exception:
        cfg = {}
        sd = Path(__file__).resolve().parent.parent / "scripts"
    base = str(cfg.get("base_url") or "https://lms.alkifah.edu.sa")
    user = os.environ.get("LMS_USERNAME") or str(cfg.get("lms_user") or "")
    pw = os.environ.get("LMS_PASSWORD") or ""
    if not pw:
        try:
            import profiles
            prof = profiles.active()
            if prof:
                env = profiles.env_for(prof) or {}
                user = env.get("LMS_USERNAME") or user
                pw = env.get("LMS_PASSWORD") or ""
        except Exception:
            pass
    log_path = Path(sd) / "uploaded_log.json"
    log = {}
    try:
        log = json.loads(log_path.read_text(encoding="utf-8"))
    except Exception:
        pass
    if a.show:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            br = p.chromium.launch(headless=True)
            page = br.new_context(locale="en-US").new_page()
            _login(page, base, user, pw)
            live, ok = live_titles(page, base, note=lambda m: log_line(m, log_path))
            br.close()
        print("على المنصة دلوقتي (%s عنوان):" % (len(live) if live else "0 -تعذر القراءة"))
        for t in sorted(live or []):
            print("   - " + t)
        return 0 if live else 1
    dropped, note = repair(log, log_path, base, user, pw) if log else ([], "nothing remembered")
    print(note)
    if dropped:
        for t in dropped:
            log.pop(t, None)
        log_path.write_text(json.dumps(log, indent=2, ensure_ascii=False), encoding="utf-8")
        print("اتشال من المذكره (هرجعهم الرفع العادي بنفس الاسم):")
        for t in dropped:
            print("   - " + str(t))
    return 0


if __name__ == "__main__":
    sys.exit(main())
