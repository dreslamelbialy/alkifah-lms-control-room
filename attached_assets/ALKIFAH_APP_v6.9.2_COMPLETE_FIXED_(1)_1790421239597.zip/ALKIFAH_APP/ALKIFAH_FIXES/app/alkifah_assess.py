#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alkifah_assess.py — ينشئ التقييم/الواجب على المنصة من غير ما تدوري على الزرار.

بيعمل بالظبط اللي التطبيق بيعمله (بينادي نفس سكربتات البرنامج)، بس بخطوة واحدة
وشباك بيبان فيه اللي بيحصل:

    python alkifah_assess.py                 بيطبع الدول/الواجبات المحفوظة ويختاري رقم
    python alkifah_assess.py --list          list بس (من غير ما يسأل)
    python alkifah_assess.py --dry           يشوف هيعمل إيه ومينفعش حاجة
    python alkifah_assess.py --name "Week 1 - Session 03 - Cell Cycle assessment"
    python alkifah_assess.py --show          يفتح المتصفح قدامك (أفضل أول مرة)

كل سطر بيطلع بيتحفظ في ASSESS_now_log.txt جنب البرنامج، عشان لو وقفت حاجة
تبعتي الملف ده بدل ما توصفي المشكلة.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent          # .../Alkifah_LMS_App/app
ROOT = APP_DIR.parent                                # .../Alkifah_LMS_App
sys.path.insert(0, str(APP_DIR))
LOG = ROOT.parent / "ASSESS_now_log.txt"
LINES: list[str] = []


def say(t: str = "") -> None:
    print(t)
    LINES.append(t)


def flush_log() -> None:
    try:
        LOG.write_text("ASSESS_NOW - %s\n%s\n"
                       % (datetime.now().strftime("%Y-%m-%d %H:%M"), "\n".join(LINES)),
                       encoding="utf-8")
        print("(اللي فوق كله اتحفظ في: %s)" % LOG)
    except Exception:
        pass


def specs() -> list:
    try:
        import pack
        cfg = pack.load_config()
        d = Path(cfg.get("specs_dir") or (ROOT / "specs"))
    except Exception:
        d = ROOT / "specs"
    out = []
    for f in sorted(d.glob("*.json")):
        if "_TEMPLATE" in f.name.upper():
            continue
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        out.append({"file": f, "title": str(data.get("title") or f.stem),
                    "n": len(data.get("questions") or []),
                    "type": str(data.get("type") or "Assessment"),
                    "sheet": bool(str(data.get("sheet_path") or "").strip())})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--name", default=None)
    ap.add_argument("--resume", default=None, metavar="EXAM_ID")
    a = ap.parse_args()

    items = specs()
    if not items:
        say("[X] مفيش أي تقييم محفوظ لسه.")
        say("    في التطبيق: اعملي توليد أسئلة وادوسي «حفظ الملف»، وارجعي هنا.")
        flush_log()
        return 2
    say("التقييمات المحفوظة عندك في %s:" % (ROOT / "specs"))
    for i, it in enumerate(items, 1):
        extra = " (شيت مرفوع)" if it["sheet"] else " (الشيت هيتعمل بالـ AI)"
        say("   %2d. %s — %d أسئلة — %s%s" % (i, it["title"], it["n"], it["type"], extra))
    if a.list:
        flush_log()
        return 0

    pick = None
    if a.name:
        want = a.name.strip().casefold()
        for it in items:
            if it["title"].strip().casefold() == want or want in it["title"].casefold() \
               or want in it["file"].stem.casefold():
                pick = it
                break
        if pick is None:
            say('[X] مفيش تقييم بهذا الاسم: "%s"' % a.name)
            flush_log()
            return 2
    else:
        if not sys.stdin or not sys.stdin.isatty():
            say("")
            say("    (مفيش شباك للمحادثة - هاشتغل على الأول. ولو عايزة غيريه: "
                 "python alkifah_assess.py --name \"عنوان التقييم\")")
            pick = items[0]
        else:
            try:
                ans = input("رقم التقييم اللي عايزة ترفعيه (Enter = الأول): ").strip()
            except Exception:
                ans = ""
            if ans.isdigit() and 1 <= int(ans) <= len(items):
                pick = items[int(ans) - 1]
            else:
                pick = items[0]

    say("")
    say("المختار: %s" % pick["title"])
    try:
        import pack
        cfg = pack.load_config()
        built = pack.build_command(cfg, "assessment", "run",
                                   {"spec": str(pick["file"]), "dry_run": bool(a.dry),
                                    "show": bool(a.show), "resume": a.resume or ""})
    except Exception as e:
        say("[X] مقدرتش أجهّز الأمر (%s)" % e)
        flush_log()
        return 1
    argv = built.get("argv") or []
    if built.get("error"):
        say("[X] " + str(built["error"]))
        flush_log()
        return 2
    if a.dry:
        say("    الأمر اللي هيتنفذ: " + " ".join(str(x) for x in argv))
        say("    (dry — مفيش حاجة اتبعتت للموقع)")
        flush_log()
        return 0
    if not argv:
        say("[X] مفيش أمر اتبنى — افتحي التطبيق وشغّلي الزرار من هناك.")
        flush_log()
        return 1
    creds = {}
    try:
        import profiles
        prof = profiles.active()
        if prof:
            creds = {k: v for k, v in (profiles.env_for(prof) or {}).items() if v}
    except Exception as e:
        say("[!] مقدرتش أقرا الحساب المحفوظ (%s)" % e)
    if not creds.get("LMS_PASSWORD"):
        say("[X] مفيش باسورد المحفظ في التطبيق.")
        say("    افتحي التطبيق -> الحسابات -> اعملي حفظ، وارجعي هنا.")
        flush_log()
        return 3
    say("")
    say("    بشتغل على المنصة دلوقتي — متقفلش الشباك اللي هيفتح...")
    env = dict(os.environ)
    env.update({k: str(v) for k, v in (built.get("env") or {}).items()})
    env.update(creds)
    r = subprocess.run(argv, env=env, cwd=str(ROOT))
    say("")
    if r.returncode == 0:
        say("[OK] خلص. راجعيه على المنصة وشوفى وقت النشر والقفل.")
    else:
        say("[!] وقف برقم %s — لو الموقع غيّر صفحة، جربي من التطبيق أو ابعتيلي الملف ده."
            % r.returncode)
    flush_log()
    return r.returncode


if __name__ == "__main__":
    sys.exit(main())
