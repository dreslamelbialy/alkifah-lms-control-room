#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
alkifah_bot.py — فحص سريع لبوت تيليجرام اللي في التطبيق (مفيش حاجة بتفشلة بالهدوء).

البوت في برنامجكم شغال جوه التطبيق نفسه: التطبيق هو اللي بيسحب الأوامر من تيليجرام،
فلما التطبيق مقفول البوت بيبقى صمّان — وده أكتر سبب للـ «بعت /start ومفيش رد».
الأداة دي بتأكدلك من ده بالنقاط:

    python alkifah_bot.py            نظرة واحدة: التوكن سليم؟ البوت رد؟ ربطك اتسجل؟
    python alkifah_bot.py --link      يسجل رقم محادثتك في التطبيق لو لقاها (الحل الشائع)
    python alkifah_bot.py --link 123456789   يسجل رقم معين انتى كتبيه
    python alkifah_bot.py --peek      بيطبع آخر أوامر بعتيها للبوت (للتأكد إنه بيشوفك)

التوكن مقروء من ملف التطبيق المشفر (profiles) — متطبعش أبداً، بيتعرض مقنّع كده 123456:AAH••••
أي حاجة بتتعمل في bot.json ياخدوا نسخة منه الأول باسم bot.json.befor-bot-fix-التاريخ.
كل سطر بيطلع في الشباك بيتحفظ في BOT_CHECK_log.txt عشان تبعتيه لو احتجتى مساعدة.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(APP_DIR))
BOT_FILE = APP_DIR / "bot.json"
LOG = APP_DIR.parent.parent / "BOT_CHECK_log.txt" if APP_DIR.parent.name == "Alkifah_LMS_App" \
    else APP_DIR / "BOT_CHECK_log.txt"
API = (os.environ.get("TELEGRAM_API") or "https://api.telegram.org").rstrip("/")
_LINES: list[str] = []


def say(msg: str = "") -> None:
    print(msg)
    _LINES.append(msg)


def mask(tok: str) -> str:
    tok = str(tok or "")
    if len(tok) < 8:
        return "(قصير)"
    return tok[:6] + ":" + "•" * 4 if ":" in tok else tok[:4] + "••••"


def api(token: str, method: str, params: dict | None = None, timeout: float = 12.0) -> dict:
    """One POST to the Bot API. POST (never GET) so nothing lands in a proxy log."""
    url = f"{API}/bot{token}/{method}"
    data = ("&".join(f"{k}={v}" for k, v in (params or {}).items())).encode()
    req = urllib.request.Request(url, data=data,
                                 headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8") or "{}")


def load_bot() -> dict:
    try:
        return json.loads(BOT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}


def real_token(data: dict) -> str:
    blob = data.get("token")
    if not blob:
        return ""
    if isinstance(blob, str):
        return blob.strip()                      # some copies keep it in plain text
    try:
        import profiles
        return str(profiles.decrypt(blob) or "").strip()
    except Exception:
        return ""


def newest_chat(updates: list) -> tuple[str, str]:
    """(chat_id, last text) from the newest update that came from a person."""
    best_id, best_txt = "", ""
    for up in updates or []:
        msg = up.get("message") or up.get("my_chat_member") or {}
        chat = msg.get("chat") or {}
        if chat.get("id"):
            best_id = str(chat["id"])
            best_txt = str(msg.get("text") or up.get("message_id") or "")
    return best_id, best_txt


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--link", nargs="?", const="AUTO", default=None, metavar="CHAT_ID",
                    help="save the chat id in the app so the bot answers you")
    ap.add_argument("--peek", action="store_true", help="show the last commands you sent")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    res = {"token_ok": False, "chat_id": "", "linked": False, "updates": 0, "verdict": ""}
    data = load_bot()
    if not BOT_FILE.exists() or not data:
        say("[!] التطبيق لسه مفيهوش توكن للبوت.")
        say("    افتحي التطبيق -> كارت البوت (تيليجرام) والصقي التوكن اللي جاي من @BotFather،")
        say("    دوسي حفظ، وارجعي للأداة دي تاني.")
        res["verdict"] = "no token saved"
        return finish(res, a)

    token = real_token(data)
    if not token:
        say("[!] التوكن موجود في الملف بس مش اتقري (مفتاح الجهاز اتغير؟).")
        say("    افتحي كارت البوت في التطبيق، امسحي التوكن، والصقيه تاني، واحفظي.")
        res["verdict"] = "token unreadable"
        return finish(res, a)

    say(f"التوكن: {mask(token)}  (بنتأكد منه عند تيليجرام...)")
    try:
        me = api(token, "getMe")
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", "replace")[:200]
        except Exception:
            pass
        say(f"[X] تيليجرام رفض التوكن (HTTP {e.code}). {body}")
        say("    انسخي التوكن من @BotFather كله من غير مسافات زائدة، واحفظي في التطبيق.")
        res["verdict"] = f"token rejected {e.code}"
        return finish(res, a)
    except Exception as e:
        say(f"[X] مفيش وصول لـ api.telegram.org ({type(e).__name__}: {str(e)[:120]})")
        say("    جربي إنترنت تاني ( بيانات موبايل / شبكة البيت ): شبكة المدرسة أو الدولة")
        say("    أحيانًا بتقفل تيليجرام. التطبيق نفسه بيفضل شغال من غير البوت.")
        res["verdict"] = "network blocked"
        return finish(res, a)

    if not me.get("ok"):
        say("[X] تيليجرام قال: " + str(me.get("description") or me)[:180])
        res["verdict"] = "getMe not ok"
        return finish(res, a)
    u = (me.get("result") or {})
    say(f"[OK] التوكن سليم. البوت: @{u.get('username', '?')} — «{u.get('first_name', '')}»")
    res["token_ok"] = True

    updates: list = []
    try:
        got = api(token, "getUpdates", {"timeout": 0, "limit": 20})
        updates = got.get("result") or []
        res["updates"] = len(updates)
    except Exception as e:
        say("(مقدرتش أقرأ آخر الرسائل: " + str(e)[:100] + ")")

    chat, last_txt = newest_chat(updates)
    linked = str(data.get("chat_id") or "").strip()
    res["chat_id"] = linked

    if a.peek:
        if not updates:
            say("[!] مفيش أي رسالة واصلة للبوت خالص — افتحي المحادثة في تيليجرام ودوسي /start.")
        for up in updates[-6:]:
            m = up.get("message") or {}
            c = m.get("chat") or {}
            say(f"   {up.get('update_id')}: {c.get('first_name') or c.get('username') or '?'} "
                f"({c.get('id')}) -> {m.get('text') or ''}")
        res["verdict"] = "peeked"
        return finish(res, a)

    if a.link is not None:
        want = chat if a.link == "AUTO" else str(a.link).strip()
        if not want:
            say("[X] ملقتش محادثة أعرف رقمها. اعملي /start في تيليجرام الأول،")
            say("    أو اكتبي الرقم:  python alkifah_bot.py --link 123456789")
            res["verdict"] = "no chat to link"
            return finish(res, a)
        shutil.copy2(BOT_FILE, BOT_FILE.with_name(
            BOT_FILE.name + ".before-bot-fix-" + datetime.now().strftime("%Y%m%d-%H%M%S")))
        data["chat_id"] = str(want)
        data["enabled"] = True
        data["saved_at"] = datetime.now().isoformat(timespec="seconds")
        BOT_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        say(f"[OK] ربطنا المحادثة {want} بالتطبيق (bot.json) — النسخة القديمة اتحفظت.")
        say("     قفلي التطبيق وافتحيه، وابعثي /status في تيليجرام: المفروض يرد.")
        res["linked"] = True
        res["verdict"] = "linked"
        return finish(res, a)

    if not linked and chat:
        say("[!] البوت بيشوفك (آخر حاجة وصلته: " + (last_txt or "رسالة") + ") بس التطبيق "
            "مش مسجل رقم محادثتك — ده بالظبط سبب إن الأوامر متتنفذش.")
        say("    الحل في سطر واحد:  python alkifah_bot.py --link")
        res["verdict"] = "chat not linked"
        return finish(res, a)
    if not linked:
        say("[!] مفيش محادثة مربوطة ولا أي رسالة وصلت للبوت.")
        say("    افتحي التطبيق (لازم يكون مفتوح لأن البوت شغال جواه)، ادوسي في تيليجرام /start،")
        say("    وارجعي شغلي الأداة دي.")
        res["verdict"] = "nothing linked, no updates"
        return finish(res, a)

    say(f"[OK] المحادثة مربوطة: {linked}")
    say("     لو الأوامر بردو متتنفذش: التطبيق لازم يكون مفتوح (البوت شغال جواه)،")
    say("     وشغّليه من 1-START-APP.bat، وابعثي /status. لو رد، تمام.")
    res["linked"] = True
    res["verdict"] = "ready"
    return finish(res, a)


def finish(res: dict, a) -> int:
    if a.json:
        print(json.dumps(res, ensure_ascii=False))
    say("")
    say("خلاصة: " + res.get("verdict", ""))
    try:
        LOG.write_text("\n".join(_LINES) + "\n", encoding="utf-8")
        print("(كل اللي فوق اتحفظ في: %s)" % LOG)
    except Exception:
        pass
    v = res.get("verdict", "")
    return 0 if v in ("ready", "linked") else (1 if v in ("network blocked",) else 2)


if __name__ == "__main__":
    sys.exit(main())
