@echo off
rem ============================================================
rem  FREE_AI.bat  -  double-click it once.
rem  Sets up a FREE AI that runs inside this laptop: no account,
rem  no card, no key, and no internet needed after the download.
rem
rem  All the work is done by alkifah_ai_setup.py, which prints every
rem  step AND writes FREE_AI_log.txt - so this window can never close
rem  on you without leaving a trace to read.
rem ============================================================
title Alkifah - free AI setup
set "TOOL=%~dp0Alkifah_LMS_App\app\alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0..\app\alkifah_ai_setup.py"

set "PY=python"
where python >nul 2>&1 || set "PY=py"
%PY% -c "print(1)" >nul 2>&1
if errorlevel 1 goto :nopy

echo.
echo  Working... keep this window open. The download step takes 5-15 minutes once.
echo  Everything is also saved to FREE_AI_log.txt in the ALKIFAH_APP folder,
echo  so if this window ever closes early, open that file and read the last lines.
echo.
%PY% "%TOOL%" --setup
if errorlevel 1 (
  echo.
  echo  [!] the setup stopped early - the reason is printed above and in FREE_AI_log.txt
)
echo.
echo  ------------------------------------------------------------
echo  If you saw  RESULT: ready  above - start the app with 1-START-APP.bat
echo  and press the Generate Questions button. You do NOT have to open Ollama.
echo  To look again later without changing anything:  AI_STATUS.bat
echo  ------------------------------------------------------------
echo.
pause
exit /b 0

:nopy
echo.
echo  [X] Python is not installed on this laptop, so the setup cannot run.
echo      Install it once from  https://www.python.org/downloads/windows/
echo      and TICK the box "Add python.exe to PATH" during the install,
echo      then double-click this file again.
echo      (the Alkifah app needs Python too, so this is needed anyway)
echo.
pause
exit /b 1
