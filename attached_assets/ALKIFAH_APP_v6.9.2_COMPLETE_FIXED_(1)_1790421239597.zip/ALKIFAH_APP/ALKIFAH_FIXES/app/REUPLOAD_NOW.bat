@echo off
rem ============================================================
rem  REUPLOAD_NOW.bat - send things to the platform AGAIN
rem  Use it when you deleted a material or a lesson on the platform,
rem  or when a class needs the same file back.
rem  It picks from the list the app already remembers. Names do NOT change,
rem  nothing is deleted, and your lesson files are not touched.
rem ============================================================
title Alkifah - upload again
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

if not exist "Alkifah_LMS_App\app\alkifah_upload.py" (
  echo [X] The upload helper is not installed yet.
  echo     Run ALKIFAH_FIXES\INSTALL_FIXES.bat once, then try again.
  pause & exit /b 1
)

echo.
echo  This lists what the app believes is already on the platform,
echo  and uploads what you choose - the SAME file, the SAME name.
echo.
%PY% "Alkifah_LMS_App\app\alkifah_upload.py" --reupload --all
echo.
echo  Finished (or cancelled). The short report is in
echo  Alkifah_LMS_App\app\upload_flow_report.txt
echo.
pause
