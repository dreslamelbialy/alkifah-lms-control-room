#!/usr/bin/env python3
r"""
alkifah_title.py — اسم التقييم اللي بيوافق المنصة، ومساعدات صغيرة لخطوة «إنشاء على المنصة».

ليه الملف ده: التطبيق بيبعت للتقييم ملف (spec) فيه العنوان. لما الخانة دي بتفضل فاضية في
الواجهة، المنصة بترفض الحفظ («العنوان مطلوب») والرسالة اللي بتظهر للتطبيق بتكون «فشل»
بس. من دلوقتي العنوان بيتبني لوحده من اسم الدرس بنفس النظام اللي انتِ عايزاه:

        Week 5 - Session 02 - Classifying Living Things - Assessment
        (رقم الأسبوع  ←  اسم الدرس  ←  كلمة Assessment)

العنوان ثابت: نفس الدرس = نفس الاسم في كل مرة (مفيش أرقام متزايدة ولا «(2)» ولا تاريخ)،
ولو كان طويل أوي بيتقص بحذر لحد ما يوصل 100 حرف لأن الخانة في المنصة محدودة.

كمان فيه تلات مساعدات بتخلي خطوة الحفظ تتعافى بدل ما ترمي «فشل»:
   • form_errors(page)        : بيقرا كلام المنصة نفسه («The Title field is required» …)
   • find_exam_id(page, title): بيدوّر على الامتحان بالاسم في Electronic Assessments —
     فلو الحفظ نجح والصفحة ما قربلتش، مبنعملش نسخة تانية.
   • run_log(...)             : كل محاولة (نجحت أو فشلت) بتتكتب في
     scripts\ASSESS_run_log.txt — الملف اللي تبعتيه لو حاجة كملت فاشلة.
"""
from __future__ import annotations

import json
import re
import time
from datetime import datetime
from pathlib import Path

MAX_TITLE = 100
SMALL = {"of", "the", "and", "in", "on", "to", "for", "a", "an", "vs", "with"}
KEEP = {"p", "q", "ch", "atp", "dna", "rna", "n3", "o2", "co2", "h2o", "pdf", "mcq"}


def _clean_words(stem: str) -> str:
    """'Classifying_Living_things-P2' -> 'Classifying Living Things P2'."""
    stem = re.sub(r"(?i)\.(pdf|pptx?|docx?|md|txt|json)$", "", str(stem or "").strip())
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    out = []
    for i, w in enumerate(stem.split(" ")):
        if not w:
            continue
        if re.search(r"[A-Z]", w[1:]) or w in ("I", "II", "III", "IV", "V"):
            out.append(w)                              # ATP, P2, DNA... left as written
        elif w.lower() in SMALL and i:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:].lower())
    return " ".join(out)


def _week_session(text: str) -> tuple[str, str]:
    t = str(text or "")
    wk = re.search(r"(?i)\bw(?:ee)?k[\s_\-]*(\d{1,2})(?!\d)", t)
    ss = re.search(r"(?i)s(?:ess|ession)?[\s_\-]*(\d{1,3})(?!\d)", t)
    return (wk.group(1) if wk else "", ss.group(1) if ss else "")


def _from_path(path) -> str:
    """First Term/Week 5/Session 02/Classifying_Living_Things.pptx  ->  the long name.
    Works with a real file, with a folder that has no Session, and with a name that only
    has the numbers written in it (Week1_Session03_Cell_Cycle.pdf)."""
    p = Path(str(path or ""))
    if not str(p):
        return ""
    parts = [x for x in p.parts]
    names = [Path(x).stem for x in parts]
    week = session = ""
    for n in names:
        w, s = _week_session(n)
        week = week or w
        session = session or s
    stem = _clean_words(p.stem)
    # the folder names are already part of the lesson name the academy uses: keep the
    # numbers, drop them from the middle so nothing is said twice
    stem_wo = re.sub(r"(?i)^\s*w(?:ee)?k\s*\d+[^\w]*", "", stem)
    stem_wo = re.sub(r"(?i)^\s*s(?:ess|ession)?\s*\d+[^\w]*", "", stem_wo).strip(" -_")
    bits = []
    if week:
        bits.append("Week " + week)
    if session:
        bits.append("Session " + session)
    if stem_wo:
        # a trailing "assessment" in the file name is the KIND, not the lesson -
        # title_for() adds the canonical kind back in its own wording
        stem_wo = re.sub(r"(?i)\s*[-\u2013]?\s*assessment$", "", stem_wo).strip(" -\u2013")
    if stem_wo:
        bits.append(_clean_words(stem_wo))
    return " - ".join(bits)


def newest_lesson(scripts_dir) -> str:
    """The last thing uploaded is the lesson she is working on (the app keeps its own
    list, so this needs no extra typing)."""
    try:
        log = json.loads((Path(scripts_dir) / "uploaded_log.json").read_text(encoding="utf-8"))
        dated = sorted((str(v or ""), str(t)) for t, v in (log or {}).items())
        if dated:
            return dated[-1][1]
    except Exception:
        pass
    return ""


def lesson_hint(spec=None, spec_path=None, scripts_dir=None) -> str:
    """The lesson, in the words the platform already uses for it. In this order:
    1) an explicit lesson file in the spec (lesson_path / source_pdf / ...)
    2) the app's own upload log - the platform's own record of the material's name
    3) the spec file's name (the app names spec files after the lesson)"""
    spec = spec if isinstance(spec, dict) else {}
    for k in ("lesson_path", "lesson", "source_pdf", "source", "file", "path",
              "pptx", "pdf", "materials_path"):
        v = str(spec.get(k) or "").strip()
        if v:
            got = _from_path(v)
            if got:
                return got
    if scripts_dir:
        got = _from_path(newest_lesson(scripts_dir))
        if got:
            return got
    if spec_path:
        return _from_path(spec_path)
    return ""


def title_for(spec=None, spec_path=None, scripts_dir=None, kind: str = "assessment") -> str:
    """The unified platform name: '<Week N - Session M - lesson> assessment' (or
    '... homework'). The SAME name every time for the same lesson, never longer than
    the Title box allows. The convention is the one the platform already shows for
    the material, so files, log and platform carry the same words."""
    hint = lesson_hint(spec, spec_path, scripts_dir)
    if not hint:
        return ""
    kind = str(kind or "assessment").strip() or "assessment"
    tail = "" if hint.lower().endswith(kind.lower()) else " " + kind
    name = hint + tail
    if len(name) <= MAX_TITLE:
        return name
    wk, ss = _week_session(hint)
    head = (["Week " + wk] if wk else []) + (["Session " + ss] if ss else [])
    rest = hint
    for _num in (wk, ss):
        if _num:
            rest = re.sub(r"(?i)\b(?:week|sess(?:ion)?)\s*" + re.escape(_num) +
                          r"\b[\s\-\u2013]*", "", rest, count=1)
    words = [w for w in " ".join(rest.split()).split(" ") if w and
             w.lower() not in ("week", "session")]
    room = MAX_TITLE - len(" - ".join(head)) - len(tail) - 4
    while words and sum(len(w) + 1 for w in words) > max(8, room):
        words.pop()
    out = " - ".join([x for x in (head + [" ".join(words)]) if x])
    return (out + tail)[:MAX_TITLE].strip(" -")


# ------------------------------------------------------------- the page-level helpers
def form_errors(page) -> list:
    """Whatever the platform itself said about the form. This is what turns a bare
    'failed' into something a person can fix."""
    out = []
    sels = [".validation-summary-errors li", ".field-validation-error",
            "[data-valmsg-for] .field-validation-error", ".text-danger",
            ".alert-danger li", ".toast .message"]
    for sel in sels:
        try:
            for el in page.locator(sel).all():
                try:
                    t = " ".join((el.inner_text(timeout=2500) or "").split())
                except Exception:
                    continue
                if t and t not in out and len(t) < 240:
                    out.append(t)
        except Exception:
            continue
    if not out:
        try:
            body = " ".join((page.inner_text("body", timeout=4000) or "").split())
            m = re.search(r"(?i)(required|must be|invalid|already exists|not valid|"
                          r"مطلوب|يجب|غير صالح|موجود)", body)
            if m:
                s = max(0, m.start() - 90)
                out.append(body[s:m.end() + 130])
        except Exception:
            pass
    return out[:6]


def find_exam_id(page, base_url: str, title: str, max_pages: int = 8) -> str:
    """Search 'Electronic Assessments' (Assessments/Exams/TeacherIndex) for this exact
    title. Used after an unclear save: if the exam is there, nothing must be created
    again. Returns the exam id, or '' when it is not there / the page could not be read."""
    want = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "", str(title or "").lower())
    if not want:
        return ""
    try:
        page.goto(base_url.rstrip("/") + "/Assessments/Exams/TeacherIndex",
                  wait_until="domcontentloaded", timeout=45000)
        for _ in range(max(1, max_pages)):
            got = page.evaluate("""() => {
                const rows = Array.from(document.querySelectorAll('table tbody tr'));
                return rows.map(r => {
                    const a = Array.from(r.querySelectorAll('a'))
                        .map(x => x.getAttribute('href') || '')
                        .find(h => /Exams\\/(Details|Edit|AssignToClass)/i.test(h)) || '';
                    const m = a.match(/(?:Id|examId)=([A-Za-z0-9\\-]+)|(?:Details|Edit)\\/([A-Za-z0-9\\-]+)/i);
                    return {t: (r.innerText || '').replace(/\\s+/g, ' ').trim(),
                            id: m ? (m[1] || m[2] || '') : ''};
                });
            }""")
            for row in (got or []):
                have = re.sub(r"[^a-z0-9\u0600-\u06ff]+", "", str(row.get("t") or "").lower())
                if have and (want in have or have in want):
                    return str(row.get("id") or "") or "FOUND"
            try:
                moved = page.evaluate("""() => {
                    const next = Array.from(document.querySelectorAll('a'))
                        .find(a => a.innerText.trim().toLowerCase() === 'next');
                    if (next && !next.closest('li').classList.contains('disabled')) {
                        next.click(); return true;
                    }
                    return false;
                }""")
            except Exception:
                moved = False
            if not moved:
                break
            try:
                page.wait_for_load_state("domcontentloaded")
                page.wait_for_timeout(900)
            except Exception:
                break
    except Exception:
        return ""
    return ""


def fill_missing_dates(page, minutes_ahead: int = 3, close_days: int = 14) -> list:
    """Some exam forms ask for an open/close date on the create page itself. Only fields
    that are there and EMPTY are touched - filling what the platform already set would be
    worse than doing nothing."""
    done = []
    start = (datetime.now()).replace(microsecond=0)
    vals = {
        "ExamStartDate": (start.replace(minute=start.minute + minutes_ahead)
                          if minutes_ahead else start),
        "ExamEndDate": datetime.fromtimestamp(
            time.time() + max(1, close_days) * 86400).replace(microsecond=0),
    }
    for name, value in vals.items():
        for sel in ("#%s" % name, "input[name='%s']" % name):
            try:
                box = page.locator(sel)
                if box.count() == 0:
                    continue
                if (box.first.input_value(timeout=2500) or "").strip():
                    break
                box.first.fill(value.strftime("%Y-%m-%dT%H:%M"), timeout=4000)
                done.append("%s = %s" % (name, value.strftime("%Y-%m-%d %H:%M")))
                break
            except Exception:
                continue
    return done


def run_log(scripts_dir, lines) -> str:
    """Append this run to scripts\\ASSESS_run_log.txt (nothing may fail silently)."""
    text = "\n".join(["%s  ---- create on the platform ----" % time.strftime("%Y-%m-%d %H:%M:%S")]
                     + [str(x) for x in lines if str(x).strip()])
    path = ""
    try:
        d = Path(scripts_dir)
        if d.exists():
            path = str(d / "ASSESS_run_log.txt")
            old = Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if Path(path).exists() else []
            Path(path).write_text("\n".join((old[-400:] + [text]))[-1200:], encoding="utf-8")
    except Exception:
        pass
    return path
