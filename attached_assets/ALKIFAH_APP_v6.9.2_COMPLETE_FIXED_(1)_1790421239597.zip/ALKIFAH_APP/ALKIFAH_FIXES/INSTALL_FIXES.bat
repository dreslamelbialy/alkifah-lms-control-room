@echo off
rem ============================================================
rem  ALKIFAH_FIXES - double-click this file once.
rem  ASCII only on purpose (batch files + Arabic do not mix).
rem ============================================================
cd /d "%~dp0"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

echo.
echo  ============================================================
echo   ALKIFAH_FIXES - 4 things:
echo     1. AI button works (free, local model - no card, no key)
echo     2. AI file list: only lessons already on the LMS
echo     3. homework maker: lesson - printable sheet + model answer
echo     4. smooth upload: Google Drive first, then the LMS
rem        (and the app stops answering to the whole school network)
echo   Every changed file is backed up first as file.bak-DATE.
echo   Undo everything:  python apply_fixes.py --revert
echo  ============================================================
echo.

%PY% -c "print(1)" >nul 2>&1
if errorlevel 1 (
  echo [X] Python is not installed. Install it from python.org, tick "Add to PATH",
  echo     then run this file again.
  pause & exit /b 1
)

echo Applying...
rem  no --root on purpose: the installer finds the ALKIFAH_APP folder itself, so it
rem  works whether ALKIFAH_FIXES is inside ALKIFAH_APP, next to it, or nested twice.
%PY% "%~dp0apply_fixes.py"
if errorlevel 1 (
  echo.
  echo [X] The fixes were NOT applied - see the message above.
  echo     Nothing was changed: that error comes BEFORE any file is touched.
  pause & exit /b 1
)

echo.
echo  ------------------------------------------------------------
echo   Next step (one double-click, 5-15 min, free):
echo       FREE_AI.bat  - in the ALKIFAH_APP folder (the installer just put it there;
echo       the exact path is printed above). From the ALKIFAH_FIXES folder it is "..\FREE_AI.bat"
echo   It installs Ollama, downloads one model sized to this laptop, and points
echo   the app at it. No account, no card, works offline afterwards.
echo.
echo   Unsure if the AI is ready?  AI_STATUS.bat (in the same folder) only LOOKS -
echo   it changes nothing and prints the 4 states, and it is safe to run any time.
echo.
echo   Uploads:   double-click UPLOAD_NOW.bat in the ALKIFAH_APP folder
echo              (Drive mirror first, then the LMS upload - nothing twice).
echo.
echo   Please also read SECURITY_FIXES.txt next to this file - 10 minutes,
echo   and it closes the open door on the shared Drive.
echo  ------------------------------------------------------------
echo.
pause
