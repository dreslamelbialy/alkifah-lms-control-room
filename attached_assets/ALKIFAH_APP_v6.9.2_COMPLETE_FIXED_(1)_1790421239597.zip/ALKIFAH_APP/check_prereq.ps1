﻿# Alkifah App - prerequisites check (GUI messages, Arabic renders correctly)
# NOTE: UTF-8 WITH BOM required
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$ok = $true

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    $r = [System.Windows.Forms.MessageBox]::Show(
        "برنامج Node.js مش متسطب على الجهاز ده وهو أساس التطبيق.`n`nالخطوات:`n1) نزّل نسخة LTS من موقع nodejs.org`n2) ثبتها (Next .. Next عادي)`n3) شغّل ملف التشغيل تاني`n`nهل أفتحلك صفحة التحميل دلوقتي؟",
        "محتاجين Node.js أولاً",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Information)
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process "https://nodejs.org/" }
    $ok = $false
}

if (-not ((Get-Command python -ErrorAction SilentlyContinue) -or (Get-Command py -ErrorAction SilentlyContinue))) {
    $r = [System.Windows.Forms.MessageBox]::Show(
        "برنامج Python مش متسطب — محتاجينه عشان أوامر الأتمتة والتقييمات.`n`nمهم جدًا: أثناء التسطيب علّم على خيار «Add Python to PATH».`n`nهل أفتحلك صفحة التحميل دلوقتي؟",
        "محتاجين Python كمان",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Information)
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { Start-Process "https://www.python.org/downloads/" }
    $ok = $false
}

# ---------------- v6.6: first-run data migration ----------------
# Fresh "start here" install with no teacher account? Pull the account, the
# upload history and the schedules from an older ALKIFAH_APP on this computer,
# so the teacher does NOT have to save the email/password from scratch.
try {
    $here = Split-Path -Parent $MyInvocation.MyCommand.Path
    $appData = Join-Path $here "Alkifah_LMS_App\app"
    $scriptsData = Join-Path $here "Alkifah_LMS_App\scripts"
    $needAccount = -not ((Test-Path (Join-Path $appData "profiles.json")) -or
                         (Test-Path (Join-Path $appData "secrets.json")))
    if ($needAccount) {
        $roots = @((Join-Path $here ".."), $env:USERPROFILE)
        $roots += @("Desktop", "Downloads", "Documents", "OneDrive\Desktop", "OneDrive\Documents") |
            ForEach-Object { Join-Path $env:USERPROFILE $_ }
        $hereFull = [System.IO.Path]::GetFullPath($here).TrimEnd("\")
        $oldApp = $null
        foreach ($root in $roots) {
            if ($oldApp) { break }
            foreach ($name in @("Alkifah_LMS_WebApp", "ALKIFAH_APP")) {
                $cand = Join-Path $root $name
                try { $candFull = [System.IO.Path]::GetFullPath($cand).TrimEnd("\") } catch { continue }
                if ($candFull -ieq $hereFull) { continue }
                if ($candFull.StartsWith($hereFull + "\")) { continue }
                if ($hereFull.StartsWith($candFull + "\")) { continue }
                if (Test-Path (Join-Path $cand "Alkifah_LMS_App\app\profiles.json")) {
                    $oldApp = $cand
                    break
                }
            }
        }
        if ($oldApp) {
            $oldAppData = Join-Path $oldApp "Alkifah_LMS_App\app"
            $oldScripts = Join-Path $oldApp "Alkifah_LMS_App\scripts"
            New-Item -ItemType Directory -Force -Path $appData | Out-Null
            New-Item -ItemType Directory -Force -Path $scriptsData | Out-Null
            foreach ($f in @("profiles.json", "secrets.json", ".appkey", "config.json", "schedules.json", "bot.json", "drive_routes.json", "drive_client.json", "drive_token.json")) {
                $src = Join-Path $oldAppData $f
                $dstF = Join-Path $appData $f
                if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dstF)) {
                    Copy-Item -LiteralPath $src -Destination $dstF -Force
                }
            }
            foreach ($f in @("uploaded_log.json", "booklet_log.json")) {
                $src = Join-Path $oldScripts $f
                $dstF = Join-Path $scriptsData $f
                if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dstF)) {
                    Copy-Item -LiteralPath $src -Destination $dstF -Force
                }
            }
            [System.Windows.Forms.MessageBox]::Show(
                "لقينا تطبيق الكفاح القديم على الجهاز ونقلنا منه حسابك وسجل الرفع والمواعيد للنسخة دي.`n`nمش محتاج تكتب الإيميل وكلمة السر تاني — كل حاجة جاهزة.",
                "اتنقلت بياناتك",
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
        }
    }
} catch {
    # migration is best-effort; never block the app from starting
}

if ($ok) { exit 0 } else { exit 1 }
