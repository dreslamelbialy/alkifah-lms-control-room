@echo off
chcp 65001 >nul 2>&1
title Alkifah LMS Studio v6.9.2 (Modern Edition)
cd /d "%~dp0"

if not exist "Alkifah_LMS_App\app\webapi.py" (
  echo.
  echo ======================================================================
  echo [!] خطأ مهم جدا: لم يتم فك ضغط الملف بالكامل (Extract All)
  echo ======================================================================
  echo الحل الصحيح:
  echo 1. اضغط كليك يمين على ملف الـ ZIP واختر Extract All / استخراج الكل
  echo 2. افتح المجلد الأصفر المستخرج وشغل منه: 1-START-APP.bat
  echo ======================================================================
  pause
  exit /b 1
)

echo [0/3] Stopping any old background version on port 3000...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr /C:":3000" ^| findstr /C:"LISTENING"') do (
  taskkill /F /PID %%a >nul 2>&1
)

set "LMS_PACK_DIR=%~dp0Alkifah_LMS_App"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

echo [1/3] Checking Python libraries...
%PY% -m pip install -r "Alkifah_LMS_App\requirements.txt" --quiet --disable-pip-version-check
%PY% -m pip install -r "Alkifah_LMS_App\app\requirements-app.txt" --quiet --disable-pip-version-check

echo [2/3] Starting AI Gateway on port 8799...
netstat -ano | findstr /C:":8799" | findstr /C:"LISTENING" >nul 2>&1
if errorlevel 1 (
  start "Alkifah AI Gateway" /min %PY% "%~dp0Alkifah_LMS_App\app\ai_gateway.py"
  timeout /t 1 /nobreak >nul
)

echo [3/3] Starting Modern Alkifah App (with Teacher Islam Elbeali profile pre-loaded)...
start "" /min cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:3000"

set "HOSTNAME=127.0.0.1"
cd /d "%~dp0webapp"
node server.js
pause
