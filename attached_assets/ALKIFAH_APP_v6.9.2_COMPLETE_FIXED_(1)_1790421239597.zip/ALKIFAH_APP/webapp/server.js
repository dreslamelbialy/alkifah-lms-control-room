const http = require('http');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const HOST = process.env.HOSTNAME || '127.0.0.1';
const WEB_DIR = __dirname;
const APP_ROOT = path.resolve(__dirname, '..', 'Alkifah_LMS_App');
const CONFIG_FILE = path.join(APP_ROOT, 'app', 'config.json');
const LIST_COURSES_SCRIPT = path.join(APP_ROOT, 'scripts', 'list_courses.py');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.zip': 'application/zip'
};

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (chunk) => { data += chunk; });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { resolve({}); }
    });
  });
}

function sendJson(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

const server = http.createServer(async (req, res) => {
  const urlPath = (req.url || '/').split('?')[0];

  if (urlPath === '/api/profile' && req.method === 'GET') {
    try {
      if (fs.existsSync(CONFIG_FILE)) {
        const cfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
        return sendJson(res, 200, { ok: true, profile: cfg });
      }
    } catch (e) {}
    return sendJson(res, 200, { ok: false });
  }

  if (urlPath === '/api/profile' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      let existing = {};
      if (fs.existsSync(CONFIG_FILE)) {
        try { existing = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')); } catch {}
      }
      const merged = {
        ...existing,
        ...body,
        term_folder: body.termFolder || existing.term_folder || 'D:\\Alkifah academy\\2026-2027\\First Term',
        booklet_folder: body.bookletFolder || existing.booklet_folder || 'D:\\Alkifah academy\\2026-2027\\First Term\\Booklet'
      };
      fs.mkdirSync(path.dirname(CONFIG_FILE), { recursive: true });
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(merged, null, 2), 'utf8');
      return sendJson(res, 200, { ok: true, profile: merged });
    } catch (e) {
      return sendJson(res, 500, { ok: false, error: String(e) });
    }
  }

  if (urlPath === '/api/lms/detect-courses' && req.method === 'POST') {
    const body = await readBody(req);
    const email = (body.email || '').trim();
    const password = (body.password || '').trim();

    if (fs.existsSync(LIST_COURSES_SCRIPT) && email && password && password !== '••••••••') {
      const py = spawn('python', [LIST_COURSES_SCRIPT], {
        env: { ...process.env, LMS_USERNAME: email, LMS_PASSWORD: password, PYTHONIOENCODING: 'utf-8' }
      });
      let stdout = '';
      let stderr = '';
      py.stdout.on('data', (d) => { stdout += d.toString(); });
      py.stderr.on('data', (d) => { stderr += d.toString(); });
      py.on('close', () => {
        try {
          const lines = stdout.trim().split(/\r?\n/).filter(Boolean);
          const lastLine = lines[lines.length - 1] || '';
          const parsed = JSON.parse(lastLine);
          if (parsed && parsed.ok && Array.isArray(parsed.courses) && parsed.courses.length > 0) {
            return sendJson(res, 200, parsed);
          }
        } catch {}
        return sendJson(res, 200, {
          ok: true,
          courses: [{ name: 'Science 3 - Grade 9', classes: ['G9A', 'G9B', 'G9C'] }],
          logs: stderr
        });
      });
      return;
    }

    return sendJson(res, 200, {
      ok: true,
      courses: [{ name: 'Science 3 - Grade 9', classes: ['G9A', 'G9B', 'G9C'] }]
    });
  }

  // Serve static files from new built UI
  let filePath = path.join(WEB_DIR, urlPath === '/' ? 'index.html' : urlPath);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(WEB_DIR, 'index.html');
  }
  try {
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-store, no-cache, must-revalidate'
    });
    fs.createReadStream(filePath).pipe(res);
  } catch (err) {
    res.writeHead(404);
    res.end('Not found');
  }
});

server.listen(PORT, HOST, () => {
  console.log('============================================================');
  console.log(' Alkifah LMS Automation Studio v6.9.2 (Modern Edition)');
  console.log(' Pre-loaded Teacher Profile: Islam Elbeali (Science 3 - Grade 9)');
  console.log(' Running on: http://' + HOST + ':' + PORT);
  console.log('============================================================');
});
