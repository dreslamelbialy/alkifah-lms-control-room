@echo off
title Alkifah - Update
rem launches the graphical updater (Arabic renders correctly in the GUI)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update_app.ps1"
if errorlevel 1 pause
