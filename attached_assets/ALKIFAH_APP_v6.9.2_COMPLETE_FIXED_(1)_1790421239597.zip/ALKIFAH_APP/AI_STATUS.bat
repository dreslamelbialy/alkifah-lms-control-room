@echo off
rem ============================================================
rem  AI_STATUS.bat  -  only LOOKS, changes nothing.
rem  Tells you in 4 lines: is Ollama installed, is it running,
rem  is a model downloaded, and what the app is pointed at.
rem  Safe to double-click as many times as you want.
rem ============================================================
title Alkifah - AI status (nothing is changed)
set "TOOL=%~dp0Alkifah_LMS_App\app\alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0alkifah_ai_setup.py"
if not exist "%TOOL%" set "TOOL=%~dp0..\app\alkifah_ai_setup.py"

set "PY=python"
where python >nul 2>&1 || set "PY=py"

%PY% "%TOOL%" --status
echo.
echo  Same text is saved in FREE_AI_log.txt (in the ALKIFAH_APP folder).
echo  Not ready yet? Double-click FREE_AI.bat once and let it finish.
echo.
pause
