﻿# Alkifah App - Auto Updater (GUI + v6.9 -Auto console mode)
# NOTE: this file MUST be saved as UTF-8 WITH BOM (PowerShell 5.1 rule)
# v6.6 fixes:
#   * Self-target bug: the finder compared UNRESOLVED paths, so a candidate like
#     "ALKIFAH_APP\..\ALKIFAH_APP" (== the update package itself) passed the
#     guard and robocopy then copied the package onto itself (code 16). Every
#     candidate is now resolved with [IO.Path]::GetFullPath before comparing.
#   * robocopy failures now retry once after killing the app again, and the
#     error message shows the exact source/destination.
#   * Data migration: when the target app has no teacher account yet, the
#     updater copies profiles / secrets / logs / schedules from an older
#     installation - a fresh "start here" no longer loses the account.
# v6.9:
#   * -Auto mode: the web app launches the updater with the target pre-filled
#     and NO extra button to press. The console window shows every step in
#     Arabic, writes update_log.txt + update_status.json next to the app
#     (the web UI reads them live), and restarts the app by itself.
#   * This fixes "the app said the updater window opened but nothing opened":
#     spawn failures are now reported by the web app, and even if the window
#     is missed the update itself never waits for a click any more.
param([string]$AppDir = "", [switch]$Auto)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:appdir = $null
$script:busy = $false
$script:guiLog = $null
$script:lastError = ""

# ---------------- shared helpers ----------------
function Resolve-Full([string]$p) {
    try { return [System.IO.Path]::GetFullPath($p).TrimEnd("\") } catch { return $p }
}

function Test-ValidApp([string]$path) {
    return ($path -and
        (Test-Path (Join-Path $path "webapp\server.js")) -and
        (Test-Path (Join-Path $path "Alkifah_LMS_App\app\webapi.py")))
}

function Test-AppMissing([string]$path) {
    $missing = @()
    if (-not (Test-Path (Join-Path $path "webapp\server.js"))) { $missing += "فولدر webapp" }
    if (-not (Test-Path (Join-Path $path "Alkifah_LMS_App\app\webapi.py"))) { $missing += "فولدر Alkifah_LMS_App" }
    return ($missing -join " و ")
}

function Find-NearApp {
    $start = Join-Path $here ".."
    $maxDepth = 3
    $hereFull = Resolve-Full $here
    $queue = New-Object System.Collections.Queue
    $startItem = Get-Item -LiteralPath $start -ErrorAction SilentlyContinue
    if (-not $startItem) { return $null }
    $queue.Enqueue(@($startItem, 0))
    while ($queue.Count -gt 0) {
        $item = $queue.Dequeue()
        $dir = $item[0]; $depth = [int]$item[1]
        if (-not $dir) { continue }
        foreach ($sub in @(Get-ChildItem -Path $dir.FullName -Directory -ErrorAction SilentlyContinue)) {
            $subFull = Resolve-Full $sub.FullName
            if ($subFull -ieq $hereFull) { continue }
            if ($subFull.StartsWith($hereFull + "\", [System.StringComparison]::OrdinalIgnoreCase)) { continue }
            if (Test-ValidApp $sub.FullName) { return $sub.FullName }
            if ($depth -lt $maxDepth -and
                $sub.Name -ine "node_modules" -and $sub.Name -ine "webapp" -and
                $sub.Name -ine ".next" -and $sub.Name -ine "Alkifah_LMS_App") {
                $queue.Enqueue(@($sub, ($depth + 1)))
            }
        }
    }
    return $null
}

function Find-AppDir {
    $names = @("Alkifah_LMS_WebApp", "ALKIFAH_APP")
    $roots = @((Join-Path $here ".."), $env:USERPROFILE)
    $roots += @("Desktop", "Downloads", "Documents", "OneDrive\Desktop", "OneDrive\Documents") |
        ForEach-Object { Join-Path $env:USERPROFILE $_ }
    $hereFull = Resolve-Full $here
    foreach ($root in $roots) {
        foreach ($name in $names) {
            $cand = Join-Path $root $name
            if (-not (Test-ValidApp $cand)) { continue }
            $candFull = Resolve-Full $cand
            if ($candFull -ieq $hereFull) { continue }
            if ($candFull.StartsWith($hereFull + "\", [System.StringComparison]::OrdinalIgnoreCase)) { continue }
            if ($hereFull.StartsWith($candFull + "\", [System.StringComparison]::OrdinalIgnoreCase)) { continue }
            return $cand
        }
    }
    $near = Find-NearApp
    if ($near) { return $near }
    return $null
}

function Stop-App {
    try {
        Get-NetTCPConnection -LocalPort 3000 -ErrorAction SilentlyContinue |
            ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    } catch { }
    Get-Process -Name "node" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
}

function Restore-Backup([string]$dst) {
    if (Test-Path (Join-Path $dst "webapp")) {
        Remove-Item (Join-Path $dst "webapp") -Recurse -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path (Join-Path $dst "webapp_OLD_BACKUP")) {
        Rename-Item (Join-Path $dst "webapp_OLD_BACKUP") "webapp" -ErrorAction SilentlyContinue
    }
}

function Copy-IfMissing([string]$src, [string]$dst) {
    if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dst)) {
        try {
            Copy-Item -LiteralPath $src -Destination $dst -Force
            return $true
        } catch { }
    }
    return $false
}

# status + log files live NEXT TO THE APP so the web UI can read them live
$script:statusPath = Join-Path $here "update_status.json"
$script:logPath = Join-Path $here "update_log.txt"

function Set-Paths-For([string]$dst) {
    $script:statusPath = Join-Path $dst "update_status.json"
    $script:logPath = Join-Path $dst "update_log.txt"
}

function Set-Status([string]$state, [string]$message) {
    try {
        $obj = [ordered]@{ state = $state; message = $message; ts = (Get-Date -Format "yyyy-MM-dd HH:mm:ss") }
        $json = ConvertTo-Json -InputObject $obj -Compress
        [IO.File]::WriteAllText($script:statusPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
}

function Log([string]$msg) {
    try {
        [IO.File]::AppendAllText($script:logPath, $msg + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
    } catch { }
    if ($script:guiLog) {
        $script:guiLog.AppendText($msg + [Environment]::NewLine)
        $script:guiLog.SelectionStart = $script:guiLog.Text.Length
        $script:guiLog.ScrollToCaret()
        $script:guiLog.Refresh()
        [System.Windows.Forms.Application]::DoEvents()
    } else {
        Write-Host $msg
    }
}

function Migrate-OldData([string]$dst) {
    $appData = Join-Path $dst "Alkifah_LMS_App\app"
    $scriptsData = Join-Path $dst "Alkifah_LMS_App\scripts"
    if ((Test-Path (Join-Path $appData "profiles.json")) -or
        (Test-Path (Join-Path $appData "secrets.json"))) {
        return
    }
    $old = Find-AppDir
    if (-not $old) { return }
    if ((Resolve-Full $old) -ieq (Resolve-Full $dst)) { return }
    Log "لقينا تطبيق قديم على الجهاز — بننقل منه حسابك وبياناتك..."
    $moved = 0
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\profiles.json") (Join-Path $appData "profiles.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\secrets.json") (Join-Path $appData "secrets.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\.appkey") (Join-Path $appData ".appkey")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\config.json") (Join-Path $appData "config.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\schedules.json") (Join-Path $appData "schedules.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\bot.json") (Join-Path $appData "bot.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\drive_routes.json") (Join-Path $appData "drive_routes.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\drive_client.json") (Join-Path $appData "drive_client.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\app\drive_token.json") (Join-Path $appData "drive_token.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\scripts\uploaded_log.json") (Join-Path $scriptsData "uploaded_log.json")
    $moved += Copy-IfMissing (Join-Path $old "Alkifah_LMS_App\scripts\booklet_log.json") (Join-Path $scriptsData "booklet_log.json")
    if ($moved -gt 0) {
        Log "   تم نقل الحساب وسجل الرفع ($moved ملف) — مش محتاج تكتب أي حاجة من الأول."
    } else {
        Log "   مفيش بيانات قابلة للنقل في التطبيق القديم."
    }
}

function Start-TheApp([string]$dst) {
    foreach ($n in @("1-START-APP.bat", "START_WEBAPP.bat")) {
        $bat = Join-Path $dst $n
        if (Test-Path $bat) {
            Start-Process -FilePath $bat -WorkingDirectory $dst
            return $true
        }
    }
    return $false
}

function Install-QuestionLibs {
    $py = $null
    if (Get-Command python -ErrorAction SilentlyContinue) { $py = "python" }
    elseif (Get-Command py -ErrorAction SilentlyContinue) { $py = "py" }
    if ($py) {
        Log "بتثبت مكتبات توليد الأسئلة... (محتاجة نت، ممكن تاخد دقيقة)"
        $argList = @("-m", "pip", "install", "--disable-pip-version-check", "python-pptx", "pymupdf")
        if ($py -eq "py") { $argList = @("-3") + $argList }
        $out = & $py @argList 2>&1
        if ($LASTEXITCODE -eq 0) {
            Log "   المكتبات اتبنت تمام."
        } else {
            Log "   حصلت مشكلة في تثبيت المكتبات — مش مشكلة كبيرة،"
            Log "   زر توليد الأسئلة من PowerPoint هيتصلح لما تتثبت بعدين."
        }
    } else {
        Log "   Python مش موجود — عدّينا الخطوة دي."
    }
}

# ---------------- the update itself (shared by GUI and -Auto) ----------------
function Run-Update([string]$dst, [bool]$installLibs) {
    try {
        Set-Paths-For $dst
        Set-Status "running" "بدأ التحديث — بيقفل التطبيق ويجهّز النسخة الاحتياطية..."
        Log "بدأنا..."
        $srcWeb = Join-Path $here "webapp"
        if (-not (Test-Path (Join-Path $srcWeb "server.js"))) {
            throw "حزمة التحديث ناقصة فولدر webapp جوه: $here"
        }

        Log "[1/5] بيقفل التطبيق لو شغال..."
        Set-Status "running" "[1/5] بيقفل التطبيق لو شغال..."
        Stop-App

        Log "[2/5] بيعمل نسخة احتياطية من الواجهة القديمة..."
        Set-Status "running" "[2/5] بيعمل نسخة احتياطية من الواجهة القديمة..."
        $backup = Join-Path $dst "webapp_OLD_BACKUP"
        if (Test-Path $backup) { Remove-Item $backup -Recurse -Force }
        if (Test-Path (Join-Path $dst "webapp")) {
            Rename-Item (Join-Path $dst "webapp") "webapp_OLD_BACKUP"
        }

        Log "[3/5] بيتحدث واجهة الويب... (ثواني وبيخلص)"
        Set-Status "running" "[3/5] بيتحدث واجهة الويب..."
        $dstWeb = Join-Path $dst "webapp"
        $copyOk = $false
        foreach ($attempt in 1..2) {
            & robocopy $srcWeb $dstWeb /E /NFL /NDL /NJH /NJS /NP /R:3 /W:3 | Out-Null
            $rc = $LASTEXITCODE
            if ($rc -lt 8) { $copyOk = $true; break }
            Log "   محاولة نسخ $attempt فشلت (robocopy code $rc) — بجرب تاني بعد ما نقفل التطبيق تاني..."
            Stop-App
            Start-Sleep -Seconds 3
        }
        if (-not $copyOk) {
            throw ("نسخ الملفات الجديدة فشل (robocopy code $LASTEXITCODE).`nالمصدر: $srcWeb`nالوجهة: $dstWeb`n`nاقفل أي برنامج ممكن يفتح ملفات التطبيق (ومنهم التطبيق نفسه) وجرّب تاني.")
        }
        if (-not (Test-Path (Join-Path $dst "webapp\server.js"))) { throw "server.js missing after copy" }

        Log "[4/5] بيتحدث محرك الأتمتة (تسريع الرفع + الجريادات + نماذج الإجابة)..."
        Set-Status "running" "[4/5] بيتحدث محرك الأتمتة..."
        Copy-Item (Join-Path $here "Alkifah_LMS_App\scripts\*") (Join-Path $dst "Alkifah_LMS_App\scripts\") -Recurse -Force
        Copy-Item (Join-Path $here "Alkifah_LMS_App\app\pack.py") (Join-Path $dst "Alkifah_LMS_App\app\pack.py") -Force
        Copy-Item (Join-Path $here "Alkifah_LMS_App\app\webapi.py") (Join-Path $dst "Alkifah_LMS_App\app\webapi.py") -Force
        Copy-Item (Join-Path $here "Alkifah_LMS_App\app\profiles.py") (Join-Path $dst "Alkifah_LMS_App\app\profiles.py") -Force -ErrorAction SilentlyContinue
        Copy-Item (Join-Path $here "Alkifah_LMS_App\app\requirements-app.txt") (Join-Path $dst "Alkifah_LMS_App\app\requirements-app.txt") -Force
        if (-not (Test-Path (Join-Path $dst "Alkifah_LMS_App\scripts\upload_materials.py"))) { throw "pack scripts copy failed" }

        Log "[5/5] بيتأكد إن حسابك وبياناتك موجودين..."
        Set-Status "running" "[5/5] بيتأكد إن حسابك وبياناتك موجودين..."
        Migrate-OldData $dst

        if ($installLibs) { Install-QuestionLibs }

        Log ""
        Log "التحديث خلص بنجاح."
        Log "النسخة القديمة محفوظة جنب التطبيق باسم webapp_OLD_BACKUP —"
        Log "لو كل حاجة شغالة تقدر تمسحها براحتك."
        Log "بياناتك وحسابك المحفوظ ماتلمسوش خالص."
        Set-Status "done" "التحديث خلص بنجاح — التطبيق بيرجع يشتغل لوحده دلوقتي."
        return $true
    } catch {
        $script:lastError = $_.Exception.Message
        Log ""
        Log ("حصلت مشكلة: " + $script:lastError)
        Log "برجّع النسخة القديمة..."
        Restore-Backup $dst
        Log "رجعت النسخة القديمة والتطبيق زي ما كان."
        Set-Status "error" ("حصلت مشكلة والنسخة القديمة رجعت زي ما كانت: " + $script:lastError)
        return $false
    }
}

# ---------------- -Auto: launched by the web app ----------------
if ($Auto) {
    try {
        [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
        $null = & chcp 65001
    } catch { }
    Write-Host "=============================================="
    Write-Host "   الكفاح — التحديث التلقائي (v6.9)"
    Write-Host "   سيب النافذة دي مفتوحة لحد ما تخلص لوحدها"
    Write-Host "=============================================="
    $dst = $null
    if (Test-ValidApp $AppDir) { $dst = $AppDir }
    if (-not $dst) { $dst = Find-AppDir }
    if (-not $dst) {
        Set-Status "error" "مقدرناش نلاقي فولدر التطبيق — شغّل 2-UPDATE-APP.bat واختار الفولدر بنفسك."
        Write-Host "مش لاقي فولدر التطبيق — اقفل النافذة دي وشغّل 2-UPDATE-APP.bat واختار الفولدر بنفسك."
        Read-Host "اضغط Enter للإغلاق"
        exit 1
    }
    Write-Host "التطبيق: $dst"
    $ok = Run-Update $dst $true
    if ($ok) {
        Write-Host "بيرجّع يشغّل التطبيق دلوقتي..."
        Start-TheApp $dst | Out-Null
        Write-Host "خلصنا — التطبيق هيفتح لوحده في نافذة جديدة. تقدر تقفل النافذة دي."
        Start-Sleep -Seconds 3
        exit 0
    } else {
        Write-Host ""
        Write-Host "التحديث متمّش — النسخة القديمة رجعت زي ما كانت."
        Start-TheApp $dst | Out-Null
        Read-Host "اضغط Enter للإغلاق"
        exit 1
    }
}

# ---------------- GUI (2-UPDATE-APP.bat manual path) ----------------
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$form = New-Object System.Windows.Forms.Form
$form.Text = "الكفاح - التحديث التلقائي"
$form.Size = New-Object System.Drawing.Size(700, 580)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.RightToLeft = "Yes"

$title = New-Object System.Windows.Forms.Label
$title.Text = "تحديث تطبيق الكفاح"
$title.Font = New-Object System.Drawing.Font("Segoe UI", 17, [System.Drawing.FontStyle]::Bold)
$title.ForeColor = [System.Drawing.Color]::FromArgb(4, 108, 78)
$title.Location = New-Object System.Drawing.Point(20, 12)
$title.Size = New-Object System.Drawing.Point(650, 34)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "دوس «ابدأ التحديث» وهو اللي هيعمل كل حاجة لوحده: يدور على التطبيق، يعمل نسخة احتياطية، يحدّث الملفات، وبياناتك وحسابك ماتلمسوش."
$sub.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$sub.Location = New-Object System.Drawing.Point(20, 48)
$sub.Size = New-Object System.Drawing.Point(650, 40)

$lblApp = New-Object System.Windows.Forms.Label
$lblApp.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$lblApp.Location = New-Object System.Drawing.Point(20, 94)
$lblApp.Size = New-Object System.Drawing.Point(650, 24)

$log = New-Object System.Windows.Forms.RichTextBox
$log.ReadOnly = $true
$log.BackColor = [System.Drawing.Color]::FromArgb(246, 250, 248)
$log.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$log.Location = New-Object System.Drawing.Point(20, 124)
$log.Size = New-Object System.Drawing.Point(650, 300)
$script:guiLog = $log

$chkLibs = New-Object System.Windows.Forms.CheckBox
$chkLibs.Text = "تثبيت مكتبات توليد الأسئلة (python-pptx و pymupdf) عشان الملفات PowerPoint والـ Word"
$chkLibs.Checked = $true
$chkLibs.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
$chkLibs.Location = New-Object System.Drawing.Point(20, 432)
$chkLibs.Size = New-Object System.Drawing.Point(650, 26)

$btnStart = New-Object System.Windows.Forms.Button
$btnStart.Text = "ابدأ التحديث"
$btnStart.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$btnStart.BackColor = [System.Drawing.Color]::FromArgb(5, 150, 105)
$btnStart.ForeColor = [System.Drawing.Color]::White
$btnStart.FlatStyle = "Flat"
$btnStart.Location = New-Object System.Drawing.Point(20, 472)
$btnStart.Size = New-Object System.Drawing.Point(200, 44)

$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "اختار فولدر التطبيق..."
$btnBrowse.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$btnBrowse.Location = New-Object System.Drawing.Point(236, 474)
$btnBrowse.Size = New-Object System.Drawing.Point(200, 40)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = "إغلاق"
$btnClose.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$btnClose.Location = New-Object System.Drawing.Point(452, 474)
$btnClose.Size = New-Object System.Drawing.Point(120, 40)

$form.Controls.AddRange(@($title, $sub, $lblApp, $log, $chkLibs, $btnStart, $btnBrowse, $btnClose))

function Set-AppDir([string]$path) {
    $script:appdir = $path
    $lblApp.Text = "التطبيق: $path"
    $lblApp.ForeColor = [System.Drawing.Color]::FromArgb(4, 108, 78)
    $btnStart.Enabled = $true
}

$btnBrowse.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "اختار فولدر التطبيق نفسه (اللي جواه webapp و Alkifah_LMS_App) — أو فولدر الحزمة اللي فكيتها"
    if ($dlg.ShowDialog() -eq "OK") {
        $picked = $dlg.SelectedPath
        if (Test-ValidApp $picked) {
            Set-AppDir $picked
        } else {
            $child = Get-ChildItem -Path $picked -Directory -ErrorAction SilentlyContinue |
                Where-Object { Test-ValidApp $_.FullName } | Select-Object -First 1
            if ($child) {
                Set-AppDir $child.FullName
                Log "اخترت فولدر الحزمة — استخدمنا فولدر التطبيق اللي جواه: $($child.FullName)"
            } else {
                $missing = Test-AppMissing $picked
                [System.Windows.Forms.MessageBox]::Show(
                    "الفولدر ده مش فولدر التطبيق.`n`nالناقص فيه: $missing`n`nلازم يكون جواه فولدر webapp وفولدر Alkifah_LMS_App.`nلو فكيت حزمة التحديث دلفر، ادخل جوه الفولدر واختار ALKIFAH_APP.",
                    "مش فولدر التطبيق",
                    [System.Windows.Forms.MessageBoxButtons]::OK,
                    [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null
            }
        }
    }
})

$btnStart.Add_Click({
    if ($script:busy) { return }
    $dst = $script:appdir
    if (-not $dst) { return }
    $script:busy = $true
    $btnStart.Enabled = $false
    $btnBrowse.Enabled = $false
    $chkLibs.Enabled = $false
    $ok = Run-Update $dst ([bool]$chkLibs.Checked)
    if ($ok) {
        $r = [System.Windows.Forms.MessageBox]::Show(
            "التحديث خلص بنجاح.`n`nتشغّل التطبيق دلوقتي؟",
            "خلصنا",
            [System.Windows.Forms.MessageBoxButtons]::YesNo,
            [System.Windows.Forms.MessageBoxIcon]::Question)
        if ($r -eq "Yes") { Start-TheApp $dst | Out-Null }
        $form.Close()
    } else {
        [System.Windows.Forms.MessageBox]::Show(
            "حصلت مشكلة والنسخة القديمة رجعت زي ما كانت.`n`n$($script:lastError)`n`nاقفل التطبيق لو مفتوح وجرّب تاني، ولو اتكررت المشكلة ابعت صورة من النافذة دي.",
            "مشكلة في التحديث",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
        $btnStart.Enabled = $true
        $btnBrowse.Enabled = $true
        $chkLibs.Enabled = $true
    }
    $script:busy = $false
})

$btnClose.Add_Click({ $form.Close() })

# ---------------- startup ----------------
$btnStart.Enabled = $false
$found = $null
if (Test-ValidApp $AppDir) {
    $found = $AppDir
}
if (-not $found) { $found = Find-AppDir }
if ($found) {
    Set-AppDir $found
} else {
    $lblApp.Text = "مش لاقي فولدر التطبيق لوحدي — دوس «اختار فولدر التطبيق» واختاره بنفسك"
    $lblApp.ForeColor = [System.Drawing.Color]::FromArgb(180, 120, 0)
}
[void]$form.ShowDialog()
