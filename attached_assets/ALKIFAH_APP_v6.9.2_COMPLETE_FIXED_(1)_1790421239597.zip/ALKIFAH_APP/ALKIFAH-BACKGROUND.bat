@echo off
rem Alkifah App - BACKGROUND server (v6.6)
rem Launched hidden at Windows login by ALKIFAH_BACKGROUND.vbs (Startup folder)
rem or run by hand. It starts the automation server with NO browser and NO
rem visible window, so the scheduled auto-uploads fire even before the teacher
rem clicks anything. Opening 1-START-APP.bat while this runs simply opens the
rem browser to the same app.
title Alkifah Background
cd /d "%~dp0"

if not exist "webapp\server.js" exit /b 1
if not exist "Alkifah_LMS_App\app\webapi.py" exit /b 1

set "LMS_PACK_DIR=%~dp0Alkifah_LMS_App"
set "PY=python"
where python >nul 2>&1 || set "PY=py"

rem first-run libraries (quiet; skipped fast when already installed)
%PY% -m pip install -r "Alkifah_LMS_App\requirements.txt" --quiet --disable-pip-version-check >nul 2>&1
%PY% -m pip install -r "Alkifah_LMS_App\app\requirements-app.txt" --quiet --disable-pip-version-check >nul 2>&1
%PY% -m playwright install chromium >nul 2>&1

rem === ALKIFAH-AI-GATEWAY (added by ALKIFAH_FIXES) ===
netstat -ano | findstr /C:":8799" | findstr /C:"LISTENING" >nul 2>&1
if errorlevel 1 (
  echo starting the AI gateway...
  start "Alkifah AI Gateway" /min %PY% "%~dp0Alkifah_LMS_App\app\ai_gateway.py"
  timeout /t 2 /nobreak >nul
)
rem === end ALKIFAH-AI-GATEWAY ===
rem AL-KIFAH-LOCALHOST: app reachable from this laptop only
set "HOSTNAME=127.0.0.1"
cd /d "%~dp0webapp"
node server.js
exit /b 0
